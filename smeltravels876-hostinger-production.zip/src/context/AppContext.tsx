import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import {
  TripPackage,
  Destination,
  BlogPost,
  OfferItem,
  TestimonialItem,
  FAQItem,
  SiteSettings,
  MediaItem,
  CustomerRecord,
  BookingSubmission,
  ContactSubmission,
  NewsletterSubscriber,
  AdminUser,
  AdminRole,
  TravelerUser,
  TravelerDepositRecord,
  AdminInboxItem,
  Ambassador,
  CustomTripRequestInput,
  AdminOrderExcelRecord,
  OrderTypeCategory,
  OrderPaymentStatus,
  OrderWorkflowStatus,
  AirportRecord,
  OriginPricingRoute,
  ServiceCostRules,
  CurrencyRecord,
  LocalTrip,
  LocalTripsPageSettings,
  WingoRouteRate,
  WiPayCheckoutPayload,
  BookingConfirmationDetails,
  PaymentSchedule,
  PaymentInstallment,
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_TRIPS,
  INITIAL_DESTINATIONS,
  INITIAL_FAQS,
  INITIAL_BLOG_POSTS,
  INITIAL_OFFERS,
  INITIAL_TESTIMONIALS,
  INITIAL_MEDIA,
  INITIAL_CUSTOMERS,
  INITIAL_BOOKINGS,
  INITIAL_ADMIN_INBOX,
  INITIAL_ADMIN_ORDERS_EXCEL,
} from '../data/initialData';
import {
  INITIAL_LOCAL_TRIPS,
  INITIAL_LOCAL_TRIPS_PAGE_SETTINGS,
} from '../data/localTripsData';
import {
  INITIAL_DEPARTURE_AIRPORTS,
  INITIAL_ORIGIN_PRICING_ROUTES,
  INITIAL_SERVICE_COST_RULES,
  INITIAL_SUPPORTED_CURRENCIES,
} from '../data/originPricingData';
import { WORLD_DESTINATIONS } from '../data/customTripDestinations';
import { INITIAL_WINGO_ROUTES } from '../data/initialWingoRates';
import {
  pushSiteContentToRTDB,
  pushFullSiteContentToRTDB,
  fetchSiteContentFromRTDB,
  subscribeToSiteContent,
  syncAllBackends,
} from '../lib/firebase';
import { safeFetchJson } from '../lib/apiClient';

interface AppContextType {
  settings: SiteSettings;
  updateSettings: (newSettings: Partial<SiteSettings>) => Promise<boolean>;
  resetSettings: () => void;
  refreshSiteData: () => Promise<void>;
  saveAllChangesToLive: (customPayload?: Record<string, any>) => Promise<boolean>;
  
  trips: TripPackage[];
  addTrip: (trip: Omit<TripPackage, 'id'>) => void;
  updateTrip: (id: string, trip: Partial<TripPackage>) => void;
  deleteTrip: (id: string) => void;
  duplicateTrip: (id: string) => void;
  
  destinations: Destination[];
  addDestination: (dest: Omit<Destination, 'id'>) => void;
  updateDestination: (id: string, dest: Partial<Destination>) => void;
  deleteDestination: (id: string) => void;
  saveDestination: (dest: Destination) => void;
  
  bookings: BookingSubmission[];
  createBooking: (booking: Omit<BookingSubmission, 'id' | 'referenceNumber' | 'createdAt' | 'updatedAt' | 'internalNotes'>) => string;
  updateBookingStatus: (id: string, status: BookingSubmission['status'], note?: string) => void;
  updateBookingPayment: (id: string, depositPaid: number, note?: string) => void;
  addBookingNote: (id: string, note: string) => void;
  
  // User Inquiry Tracker (accessible to guests and logged-in users)
  isInquiryTrackerOpen: boolean;
  setIsInquiryTrackerOpen: (open: boolean) => void;
  openInquiryTracker: (refOrEmail?: string) => void;
  closeInquiryTracker: () => void;
  inquiryTrackerInitialQuery: string | null;
  updateUserInquiry: (
    refOrId: string,
    updates: {
      travelDates?: string;
      adultsCount?: number;
      childrenCount?: number;
      specialRequests?: string;
      phone?: string;
      customerMessage?: string;
    }
  ) => boolean;
  submitInquiryDeposit: (
    refOrId: string,
    amount: number,
    paymentMethod: string,
    transactionRef?: string,
    proofNotes?: string
  ) => boolean;
  
  contactSubmissions: ContactSubmission[];
  submitContactForm: (sub: Omit<ContactSubmission, 'id' | 'referenceNumber' | 'createdAt' | 'status'>) => string;
  
  customers: CustomerRecord[];
  addCustomerNote: (id: string, note: string) => void;
  
  blogPosts: BlogPost[];
  addBlogPost: (post: Omit<BlogPost, 'id'>) => void;
  updateBlogPost: (id: string, post: Partial<BlogPost>) => void;
  deleteBlogPost: (id: string) => void;
  
  offers: OfferItem[];
  addOffer: (offer: Omit<OfferItem, 'id'>) => void;
  updateOffer: (id: string, offer: Partial<OfferItem>) => void;
  deleteOffer: (id: string) => void;
  
  testimonials: TestimonialItem[];
  addTestimonial: (test: Omit<TestimonialItem, 'id'>) => void;
  updateTestimonial: (id: string, test: Partial<TestimonialItem>) => void;
  deleteTestimonial: (id: string) => void;
  
  faqs: FAQItem[];
  addFaq: (faq: Omit<FAQItem, 'id'>) => void;
  updateFaq: (id: string, faq: Partial<FAQItem>) => void;
  deleteFaq: (id: string) => void;
  
  mediaList: MediaItem[];
  addMediaItem: (item: Omit<MediaItem, 'id' | 'uploadedAt'>) => void;
  deleteMediaItem: (id: string) => void;
  
  subscribers: NewsletterSubscriber[];
  subscribeNewsletter: (firstName: string, email: string) => boolean;
  unsubscribeNewsletter: (email: string) => void;
  
  // Admin & View State
  isAdminLoggedIn: boolean;
  adminEmail: string | null;
  adminSessionToken: string | null;
  currentAdminRole: AdminRole;
  loginAdmin: (role?: AdminRole) => void;
  loginAdminWithCredentials: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logoutAdmin: () => void;

  // Admin Inbox
  adminInbox: AdminInboxItem[];
  addInboxItem: (item: Omit<AdminInboxItem, 'id' | 'timestamp' | 'isRead'>) => void;
  markInboxItemAsRead: (id: string) => void;
  markAllInboxAsRead: () => void;
  deleteInboxItem: (id: string) => void;
  unreadInboxCount: number;

  // Admin Order Excel Database (spreadsheet database for website admins to view & edit)
  adminOrdersExcel: AdminOrderExcelRecord[];
  addAdminOrderExcel: (order: Omit<AdminOrderExcelRecord, 'id' | 'receivedAt' | 'lastUpdated'>) => string;
  updateAdminOrderExcel: (id: string, updates: Partial<AdminOrderExcelRecord>) => void;
  deleteAdminOrderExcel: (id: string) => void;
  batchUpdateAdminOrdersExcel: (orders: AdminOrderExcelRecord[]) => void;
  sendInboxItemToExcel: (item: AdminInboxItem) => { success: boolean; id: string; isNew: boolean };
  sendBookingToExcel: (booking: BookingSubmission) => { success: boolean; id: string; isNew: boolean };
  isOrderInExcel: (refOrIdentifier?: string, email?: string) => boolean;
  syncAllInboxOrdersToExcel: () => { totalAdded: number; totalExisting: number };
  updateBookingPaymentSchedule: (orderIdOrRef: string, schedule: PaymentSchedule) => void;

  // Bookmarks / Saved Trips
  savedTripIds: string[];
  savedTrips: TripPackage[];
  toggleSaveTrip: (tripId: string) => void;
  clearAllSavedTrips: () => void;
  isTripSaved: (tripId: string) => boolean;
  isSavedTripsDrawerOpen: boolean;
  setIsSavedTripsDrawerOpen: (open: boolean) => void;
  openSavedTripsDrawer: () => void;
  closeSavedTripsDrawer: () => void;

  // Custom Trip Creation & Dynamic Requests (Any destination / country)
  isCustomTripModalOpen: boolean;
  setIsCustomTripModalOpen: (open: boolean) => void;
  selectedDestinationForCustomTrip: string | null;
  openCustomTripModal: (initialCountryOrDestination?: string) => void;
  closeCustomTripModal: () => void;
  submitCustomTripRequest: (data: CustomTripRequestInput) => Promise<{ success: boolean; referenceNumber: string }>;

  // Force Auth / Spot Booking Flow
  secureSpotForTrip: (trip: TripPackage) => void;
  pendingTripForBooking: TripPackage | null;
  setPendingTripForBooking: (trip: TripPackage | null) => void;
  authNotice: string | null;
  setAuthNotice: (notice: string | null) => void;

  // Ambassador Code & Discount Helpers
  verifyAmbassadorCode: (code: string) => { valid: boolean; ambassador?: Ambassador; discountPercentage: number };

  // Traveler Account Authentication
  currentUser: TravelerUser | null;
  loginUser: (email: string, name?: string, phone?: string) => boolean;
  signupUser: (name: string, email: string, phone?: string, homeParishOrCountry?: string) => boolean;
  logoutUser: () => void;
  recordUserDeposit: (deposit: TravelerDepositRecord, userEmail?: string) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authModalMode: 'login' | 'signup';
  setAuthModalMode: (mode: 'login' | 'signup') => void;
  openAuthModal: (mode?: 'login' | 'signup') => void;
  
  // Notifications & UI states
  activeNotification: { title: string; message: string; type: 'success' | 'info' | 'warning' } | null;
  notification: { title: string; message: string; type?: 'success' | 'info' | 'warning' | 'error' } | null;
  showNotification: (title: string, message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  clearNotification: () => void;
  
  // Search state
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;

  // Review submission modal state
  isReviewModalOpen: boolean;
  setIsReviewModalOpen: (open: boolean) => void;
  openReviewModal: () => void;
  closeReviewModal: () => void;

  // WiPay Jamaica Live Gateway Integration
  isWiPayCheckoutOpen: boolean;
  wiPayCheckoutPayload: WiPayCheckoutPayload | null;
  confirmedBookingDetails: BookingConfirmationDetails | null;
  openWiPayCheckout: (payload: WiPayCheckoutPayload) => void;
  closeWiPayCheckout: () => void;
  completeWiPayBooking: (bookingData: Partial<BookingSubmission>) => BookingSubmission;
  closeConfirmationModal: () => void;

  // Quick View modals
  selectedTripForBooking: TripPackage | null;
  setSelectedTripForBooking: (trip: TripPackage | null) => void;
  selectedTripForInquiry: TripPackage | null;
  setSelectedTripForInquiry: (trip: TripPackage | null) => void;
  selectedTripDetail: TripPackage | null;
  setSelectedTripDetail: (trip: TripPackage | null) => void;
  
  // Navigation helper
  activePage: string;
  navigateTo: (page: string, param?: string) => void;
  pageParam: string | null;

  // Origin & Route Pricing Engine (Admin editable)
  departureAirports: AirportRecord[];
  addDepartureAirport: (airport: Omit<AirportRecord, 'id'>) => void;
  updateDepartureAirport: (id: string, airport: Partial<AirportRecord>) => void;
  deleteDepartureAirport: (id: string) => void;

  originPricingRoutes: OriginPricingRoute[];
  addOriginPricingRoute: (route: Omit<OriginPricingRoute, 'id'>) => void;
  updateOriginPricingRoute: (id: string, route: Partial<OriginPricingRoute>) => void;
  deleteOriginPricingRoute: (id: string) => void;

  serviceCostRules: ServiceCostRules;
  updateServiceCostRules: (rules: Partial<ServiceCostRules>) => void;
  resetServiceCostRules: () => void;

  supportedCurrencies: CurrencyRecord[];
  addSupportedCurrency: (curr: CurrencyRecord) => void;
  updateSupportedCurrency: (code: string, curr: Partial<CurrencyRecord>) => void;
  deleteSupportedCurrency: (code: string) => void;
  resetOriginPricingData: () => void;

  // Local Trips (Jamaican Excursions, Tours & Weekend Getaways)
  localTrips: LocalTrip[];
  localTripsPageSettings: LocalTripsPageSettings;
  addLocalTrip: (trip: Omit<LocalTrip, 'id'>) => string;
  updateLocalTrip: (id: string, trip: Partial<LocalTrip>) => void;
  deleteLocalTrip: (id: string) => void;
  reorderLocalTrips: (newTrips: LocalTrip[]) => void;
  updateLocalTripsPageSettings: (settings: Partial<LocalTripsPageSettings>) => void;
  saveLocalTripsToLive: (customTrips?: LocalTrip[], customSettings?: LocalTripsPageSettings) => Promise<boolean>;
  selectedLocalTripDetail: LocalTrip | null;
  setSelectedLocalTripDetail: (trip: LocalTrip | null) => void;
  openLocalTripDetail: (idOrSlug: string) => void;
  closeLocalTripDetail: () => void;
  selectedLocalTripForInquiry: LocalTrip | null;
  setSelectedLocalTripForInquiry: (trip: LocalTrip | null) => void;
  openLocalTripInquiry: (trip: LocalTrip) => void;
  closeLocalTripInquiry: () => void;

  // Wingo Airlines 11-Country Rates & Costs Database
  wingoRoutes: WingoRouteRate[];
  addWingoRoute: (route: Omit<WingoRouteRate, 'id'>) => string;
  updateWingoRoute: (id: string, updates: Partial<WingoRouteRate>) => void;
  deleteWingoRoute: (id: string) => void;
  batchUpdateWingoRoutes: (routes: WingoRouteRate[]) => void;
  saveWingoRoutesToLive: (customRoutes?: WingoRouteRate[]) => Promise<boolean>;
  resetWingoRoutesToDefault: () => void;

  // Additional Admin actions
  deleteBooking: (id: string) => void;
  saveTrip: (trip: TripPackage) => void;
  saveBlogPost: (post: BlogPost) => void;
  saveFaq: (faq: FAQItem) => void;
  saveOffer: (offer: OfferItem) => void;
  saveTestimonial: (test: TestimonialItem) => void;
  resetToInitialData: () => void;
  applyFirestoreContent: (data: any) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY_PREFIX = 'smeltravels876_v2_';

function getStoredItem<T>(key: string, defaultVal: T): T {
  try {
    const item = localStorage.getItem(LOCAL_STORAGE_KEY_PREFIX + key);
    return item ? JSON.parse(item) : defaultVal;
  } catch (e) {
    console.error(`Error reading ${key} from storage:`, e);
    return defaultVal;
  }
}

function setStoredItem<T>(key: string, val: T): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_PREFIX + key, JSON.stringify(val));
  } catch (e) {
    console.error(`Error saving ${key} to storage:`, e);
  }
}

export const VALID_APP_PAGES = [
  'home',
  'trips',
  'trip-detail',
  'destinations',
  'about',
  'local-trips',
  'guides',
  'faq',
  'contact',
  'legal',
  'admin',
] as const;

export type AppNavPage = typeof VALID_APP_PAGES[number];

export function parseUrlHash(): { page: string; param: string | null } | null {
  if (typeof window === 'undefined') return null;
  const hash = window.location.hash;
  if (!hash || hash === '#' || hash === '#/') return null;

  const raw = hash.replace(/^#\/?/, '').trim();
  if (!raw) return null;

  const [pathPart, queryPart] = raw.split('?');
  const pathSegments = pathPart.split('/').filter(Boolean);
  const primaryPage = (pathSegments[0] || '').toLowerCase();

  if (!VALID_APP_PAGES.includes(primaryPage as any)) {
    return null;
  }

  // 1. Path param: e.g. #trip-detail/panama-2026 or #destinations/panama
  let param: string | null = pathSegments.length > 1 ? decodeURIComponent(pathSegments.slice(1).join('/')) : null;

  // 2. Query param: e.g. #admin?tab=inbox or #trips?param=2026 or #legal?param=terms
  if (!param && queryPart) {
    try {
      const sp = new URLSearchParams(queryPart);
      param = sp.get('param') || sp.get('slug') || sp.get('tab') || sp.get('filter') || sp.get('id') || null;
    } catch (e) {}
  }

  return { page: primaryPage, param };
}

export function formatUrlHash(page: string, param?: string | null): string {
  if (page === 'home' && !param) return '';
  if (param) {
    if (page === 'trip-detail' || page === 'destinations' || page === 'guides') {
      return `#${page}/${encodeURIComponent(param)}`;
    }
    if (page === 'admin') {
      return `#admin?tab=${encodeURIComponent(param)}`;
    }
    return `#${page}?param=${encodeURIComponent(param)}`;
  }
  return `#${page}`;
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<SiteSettings>(() => {
    return getStoredItem('settings', INITIAL_SETTINGS);
  });
  const [trips, setTrips] = useState<TripPackage[]>(() => {
    return getStoredItem('trips', INITIAL_TRIPS);
  });
  const [destinations, setDestinations] = useState<Destination[]>(() => getStoredItem('destinations', INITIAL_DESTINATIONS));
  // Authoritative customer data: initialized cleanly in memory and populated exclusively from authoritative central database
  const [bookings, setBookings] = useState<BookingSubmission[]>([]);
  const [contactSubmissions, setContactSubmissions] = useState<ContactSubmission[]>([]);
  const [customers, setCustomers] = useState<CustomerRecord[]>([]);
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(() => getStoredItem('blog', INITIAL_BLOG_POSTS));
  const [offers, setOffers] = useState<OfferItem[]>(() => getStoredItem('offers', INITIAL_OFFERS));
  const [testimonials, setTestimonials] = useState<TestimonialItem[]>(() => getStoredItem('testimonials', INITIAL_TESTIMONIALS));
  const [faqs, setFaqs] = useState<FAQItem[]>(() => getStoredItem('faqs', INITIAL_FAQS));
  const [mediaList, setMediaList] = useState<MediaItem[]>(() => getStoredItem('media', INITIAL_MEDIA));
  const [subscribers, setSubscribers] = useState<NewsletterSubscriber[]>(() => getStoredItem('subscribers', [
    { id: 'sub-1', firstName: 'Kadeen', email: 'kadeen.campbell@example.com', subscribedAt: '2026-08-10', isActive: true, source: 'Website Footer' }
  ]));

  // Admin Inbox state - authoritative live central records
  const [adminInbox, setAdminInbox] = useState<AdminInboxItem[]>([]);

  // Admin Order Excel Database state - authoritative live central records
  const [adminOrdersExcel, setAdminOrdersExcel] = useState<AdminOrderExcelRecord[]>([]);

  // Bookmarked / Saved trips state
  const [savedTripIds, setSavedTripIds] = useState<string[]>(() => {
    return getStoredItem('saved_trips', ['panama-2026']);
  });
  const [isSavedTripsDrawerOpen, setIsSavedTripsDrawerOpen] = useState<boolean>(false);

  // Origin and Route Pricing State (Admin editable)
  const [departureAirports, setDepartureAirports] = useState<AirportRecord[]>(() => {
    return getStoredItem('departure_airports', INITIAL_DEPARTURE_AIRPORTS);
  });
  const [originPricingRoutes, setOriginPricingRoutes] = useState<OriginPricingRoute[]>(() => {
    return getStoredItem('origin_pricing_routes', INITIAL_ORIGIN_PRICING_ROUTES);
  });
  const [serviceCostRules, setServiceCostRules] = useState<ServiceCostRules>(() => {
    return getStoredItem('service_cost_rules', INITIAL_SERVICE_COST_RULES);
  });
  const [supportedCurrencies, setSupportedCurrencies] = useState<CurrencyRecord[]>(() => {
    return getStoredItem('supported_currencies', INITIAL_SUPPORTED_CURRENCIES);
  });

  // Local Trips State (Jamaican Tours, Excursions, Weekend Getaways)
  const [localTrips, setLocalTrips] = useState<LocalTrip[]>(() => {
    return getStoredItem<LocalTrip[]>('local_trips', INITIAL_LOCAL_TRIPS);
  });
  const [localTripsPageSettings, setLocalTripsPageSettings] = useState<LocalTripsPageSettings>(() => {
    return getStoredItem('local_trips_settings', INITIAL_LOCAL_TRIPS_PAGE_SETTINGS);
  });
  const [selectedLocalTripDetail, setSelectedLocalTripDetail] = useState<LocalTrip | null>(null);
  const [selectedLocalTripForInquiry, setSelectedLocalTripForInquiry] = useState<LocalTrip | null>(null);

  // Wingo Airlines 11-Country Rates & Costs Database State
  const [wingoRoutes, setWingoRoutes] = useState<WingoRouteRate[]>(() => {
    return getStoredItem('wingo_rates_database', INITIAL_WINGO_ROUTES);
  });

  // Custom Trip Creation State (Where travelers design custom trips to any country)
  const [isCustomTripModalOpen, setIsCustomTripModalOpen] = useState<boolean>(false);
  const [selectedDestinationForCustomTrip, setSelectedDestinationForCustomTrip] = useState<string | null>(null);

  // Forced Auth for Spot Booking state
  const [pendingTripForBooking, setPendingTripForBooking] = useState<TripPackage | null>(null);
  const [authNotice, setAuthNotice] = useState<string | null>(null);

  // Admin states - authenticated and verified via server token
  const [adminSessionToken, setAdminSessionToken] = useState<string | null>(() => {
    try {
      return sessionStorage.getItem('smeltravels_admin_token') || localStorage.getItem('smeltravels_admin_token') || null;
    } catch {
      return null;
    }
  });
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [adminEmail, setAdminEmail] = useState<string | null>(null);
  const [currentAdminRole, setCurrentAdminRole] = useState<AdminRole>('Super Admin');

  // Notification state
  const [activeNotification, setActiveNotification] = useState<{ title: string; message: string; type: 'success' | 'info' | 'warning' } | null>(null);

  // Search modal state
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);

  // Review submission modal state
  const [isReviewModalOpen, setIsReviewModalOpen] = useState<boolean>(false);
  const openReviewModal = () => setIsReviewModalOpen(true);
  const closeReviewModal = () => setIsReviewModalOpen(false);

  // Traveler authentication state
  const [currentUser, setCurrentUser] = useState<TravelerUser | null>(() => {
    return getStoredItem<TravelerUser | null>('traveler_user', null);
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>('login');

  // Inquiry Tracker state (accessible to both guests and logged-in travelers)
  const [isInquiryTrackerOpen, setIsInquiryTrackerOpen] = useState<boolean>(false);
  const [inquiryTrackerInitialQuery, setInquiryTrackerInitialQuery] = useState<string | null>(null);

  const openInquiryTracker = (refOrEmail?: string) => {
    if (!currentUser) {
      showNotification(
        'Traveler Login Required',
        'Please log in to track your inquiry, view transaction progress, and pay your next installment.',
        'info'
      );
      openAuthModal('login');
      return;
    }
    if (refOrEmail) {
      setInquiryTrackerInitialQuery(refOrEmail);
    } else if (currentUser?.email) {
      setInquiryTrackerInitialQuery(currentUser.email);
    }
    setIsInquiryTrackerOpen(true);
  };

  const closeInquiryTracker = () => {
    setIsInquiryTrackerOpen(false);
    setInquiryTrackerInitialQuery(null);
  };

  // Modals & Navigation state
  const [isWiPayCheckoutOpen, setIsWiPayCheckoutOpen] = useState(false);
  const [wiPayCheckoutPayload, setWiPayCheckoutPayload] = useState<WiPayCheckoutPayload | null>(null);
  const [confirmedBookingDetails, setConfirmedBookingDetails] = useState<BookingConfirmationDetails | null>(null);

  const openWiPayCheckout = (payload: WiPayCheckoutPayload) => {
    setWiPayCheckoutPayload(payload);
    setIsWiPayCheckoutOpen(true);
  };

  const closeWiPayCheckout = () => {
    setIsWiPayCheckoutOpen(false);
    setWiPayCheckoutPayload(null);
  };

  const closeConfirmationModal = () => {
    setConfirmedBookingDetails(null);
  };

  const [selectedTripForBooking, setSelectedTripForBooking] = useState<TripPackage | null>(null);
  const [selectedTripForInquiry, setSelectedTripForInquiry] = useState<TripPackage | null>(null);
  const [selectedTripDetail, setSelectedTripDetail] = useState<TripPackage | null>(null);
  const [activePage, setActivePage] = useState<string>(() => {
    const fromHash = parseUrlHash();
    if (fromHash?.page) return fromHash.page;
    const stored = getStoredItem<string>('active_page', 'home');
    if (stored && VALID_APP_PAGES.includes(stored as any)) {
      return stored;
    }
    return 'home';
  });
  const [pageParam, setPageParam] = useState<string | null>(() => {
    const fromHash = parseUrlHash();
    if (fromHash) return fromHash.param;
    return getStoredItem<string | null>('page_param', null);
  });

  // Sync with localStorage
  useEffect(() => { setStoredItem('active_page', activePage); }, [activePage]);
  useEffect(() => { setStoredItem('page_param', pageParam); }, [pageParam]);
  useEffect(() => { setStoredItem('settings', settings); }, [settings]);
  useEffect(() => { setStoredItem('trips', trips); }, [trips]);
  useEffect(() => { setStoredItem('destinations', destinations); }, [destinations]);
  // Note: Customer records (bookings, contacts, customers, adminInbox, adminOrdersExcel)
  // and admin sessions are intentionally NOT stored in localStorage to prevent multi-browser desync and security exposure.
  useEffect(() => { setStoredItem('traveler_user', currentUser); }, [currentUser]);
  useEffect(() => { setStoredItem('departure_airports', departureAirports); }, [departureAirports]);
  useEffect(() => { setStoredItem('origin_pricing_routes', originPricingRoutes); }, [originPricingRoutes]);
  useEffect(() => { setStoredItem('service_cost_rules', serviceCostRules); }, [serviceCostRules]);
  useEffect(() => { setStoredItem('supported_currencies', supportedCurrencies); }, [supportedCurrencies]);
  useEffect(() => { setStoredItem('local_trips', localTrips); }, [localTrips]);
  useEffect(() => { setStoredItem('local_trips_settings', localTripsPageSettings); }, [localTripsPageSettings]);

  // Helper to convert arrays or Firebase RTDB keyed objects into clean typed arrays
  function parseAsArray<T>(val: any): T[] | null {
    if (!val) return null;
    if (Array.isArray(val)) return val.filter(Boolean);
    if (typeof val === 'object') {
      return Object.values(val).filter(Boolean) as T[];
    }
    return null;
  }

  // Centralized state updater for live website feed updates
  const isIncomingUpdateRef = useRef(false);

  const applyFirestoreContent = useCallback((d: any) => {
    if (!d || typeof d !== 'object') return;
    isIncomingUpdateRef.current = true;

    if (d.settings && typeof d.settings === 'object') {
      const inc = d.settings;
      setSettings((prev) => {
        const merged: SiteSettings = {
          ...prev,
          ...inc,
          companyBanking: {
            ...(prev.companyBanking || {}),
            ...(inc.companyBanking || {}),
          },
          ambassadors: Array.isArray(inc.ambassadors)
            ? inc.ambassadors
            : inc.ambassadors && typeof inc.ambassadors === 'object'
            ? (Object.values(inc.ambassadors) as Ambassador[])
            : prev.ambassadors,
        };
        try {
          if (JSON.stringify(prev) === JSON.stringify(merged)) {
            return prev;
          }
        } catch (e) {}
        setStoredItem('settings', merged);
        return merged;
      });
    }

    const tripsArray =
      parseAsArray<TripPackage>(d.trips) ||
      parseAsArray<TripPackage>(d.packages) ||
      parseAsArray<TripPackage>(d.travelPackages);
    if (tripsArray && tripsArray.length > 0) {
      setTrips((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(tripsArray)) return prev;
        } catch (e) {}
        setStoredItem('trips', tripsArray);
        return tripsArray;
      });
    }

    const destinationsArray = parseAsArray<Destination>(d.destinations);
    if (destinationsArray && destinationsArray.length > 0) {
      setDestinations((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(destinationsArray)) return prev;
        } catch (e) {}
        setStoredItem('destinations', destinationsArray);
        return destinationsArray;
      });
    }

    const bookingsArray = parseAsArray<BookingSubmission>(d.bookings);
    if (bookingsArray) {
      setBookings((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(bookingsArray)) return prev;
        } catch (e) {}
        return bookingsArray;
      });
    }

    const contactsArray = parseAsArray<ContactSubmission>(d.contacts);
    if (contactsArray) {
      setContactSubmissions((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(contactsArray)) return prev;
        } catch (e) {}
        return contactsArray;
      });
    }

    const customersArray = parseAsArray<CustomerRecord>(d.customers);
    if (customersArray) {
      setCustomers((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(customersArray)) return prev;
        } catch (e) {}
        return customersArray;
      });
    }

    const blogArray = parseAsArray<BlogPost>(d.blog);
    if (blogArray && blogArray.length > 0) {
      setBlogPosts((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(blogArray)) return prev;
        } catch (e) {}
        setStoredItem('blog', blogArray);
        return blogArray;
      });
    }

    const offersArray = parseAsArray<OfferItem>(d.offers);
    if (offersArray && offersArray.length > 0) {
      setOffers((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(offersArray)) return prev;
        } catch (e) {}
        setStoredItem('offers', offersArray);
        return offersArray;
      });
    }

    const testimonialsArray = parseAsArray<TestimonialItem>(d.testimonials);
    if (testimonialsArray && testimonialsArray.length > 0) {
      setTestimonials((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(testimonialsArray)) return prev;
        } catch (e) {}
        setStoredItem('testimonials', testimonialsArray);
        return testimonialsArray;
      });
    }

    const faqsArray = parseAsArray<FAQItem>(d.faqs);
    if (faqsArray && faqsArray.length > 0) {
      setFaqs((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(faqsArray)) return prev;
        } catch (e) {}
        setStoredItem('faqs', faqsArray);
        return faqsArray;
      });
    }

    const adminInboxArray = parseAsArray<AdminInboxItem>(d.adminInbox);
    if (adminInboxArray) {
      setAdminInbox((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(adminInboxArray)) return prev;
        } catch (e) {}
        return adminInboxArray;
      });
    }

    const ordersExcelArray = parseAsArray<AdminOrderExcelRecord>(d.adminOrdersExcel);
    if (ordersExcelArray && ordersExcelArray.length > 0) {
      setAdminOrdersExcel((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(ordersExcelArray)) return prev;
        } catch (e) {}
        return ordersExcelArray;
      });
    }

    const mediaArray = parseAsArray<MediaItem>(d.media);
    if (mediaArray && mediaArray.length > 0) {
      setMediaList((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(mediaArray)) return prev;
        } catch (e) {}
        setStoredItem('media', mediaArray);
        return mediaArray;
      });
    }

    const airportsArray = parseAsArray<AirportRecord>(d.departureAirports);
    if (airportsArray && airportsArray.length > 0) {
      setDepartureAirports((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(airportsArray)) return prev;
        } catch (e) {}
        setStoredItem('departure_airports', airportsArray);
        return airportsArray;
      });
    }

    const routesArray = parseAsArray<OriginPricingRoute>(d.originPricingRoutes);
    if (routesArray && routesArray.length > 0) {
      setOriginPricingRoutes((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(routesArray)) return prev;
        } catch (e) {}
        setStoredItem('origin_pricing_routes', routesArray);
        return routesArray;
      });
    }

    if (d.serviceCostRules && typeof d.serviceCostRules === 'object') {
      setServiceCostRules((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(d.serviceCostRules)) return prev;
        } catch (e) {}
        setStoredItem('service_cost_rules', d.serviceCostRules);
        return d.serviceCostRules;
      });
    }

    const currArray = parseAsArray<CurrencyRecord>(d.supportedCurrencies);
    if (currArray && currArray.length > 0) {
      setSupportedCurrencies((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(currArray)) return prev;
        } catch (e) {}
        setStoredItem('supported_currencies', currArray);
        return currArray;
      });
    }

    const localTripsArray = parseAsArray<LocalTrip>(d.localTrips);
    if (localTripsArray && localTripsArray.length > 0) {
      setLocalTrips((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(localTripsArray)) return prev;
        } catch (e) {}
        setStoredItem('local_trips', localTripsArray);
        return localTripsArray;
      });
    }

    if (d.localTripsPageSettings && typeof d.localTripsPageSettings === 'object') {
      setLocalTripsPageSettings((prev) => {
        const merged = { ...prev, ...d.localTripsPageSettings };
        try {
          if (JSON.stringify(prev) === JSON.stringify(merged)) return prev;
        } catch (e) {}
        setStoredItem('local_trips_settings', merged);
        return merged;
      });
    }

    const wingoArray = parseAsArray<WingoRouteRate>(d.wingoRoutes);
    if (wingoArray && wingoArray.length > 0) {
      setWingoRoutes((prev) => {
        try {
          if (JSON.stringify(prev) === JSON.stringify(wingoArray)) return prev;
        } catch (e) {}
        setStoredItem('wingo_rates_database', wingoArray);
        return wingoArray;
      });
    }

    setTimeout(() => {
      isIncomingUpdateRef.current = false;
    }, 200);
  }, []);

  const applyServerData = applyFirestoreContent;
  const lastServerTimestampRef = useRef<string>('');

  // Authoritative admin records fetcher using verified server session token
  const fetchAdminRecords = useCallback(async (tokenToUse?: string) => {
    const activeToken = tokenToUse || adminSessionToken;
    if (!activeToken) return;
    try {
      const result = await safeFetchJson<{
        success: boolean;
        adminInbox: any[];
        bookings: any[];
        adminOrdersExcel: any[];
        customers: any[];
      }>(`/api/admin/full-records?_t=${Date.now()}`, {
        cache: 'no-store',
        headers: {
          'Authorization': `Bearer ${activeToken}`,
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          Pragma: 'no-cache',
        },
      });
      if (result.status === 401) {
        setAdminSessionToken(null);
        setIsAdminLoggedIn(false);
        try {
          sessionStorage.removeItem('smeltravels_admin_token');
          localStorage.removeItem('smeltravels_admin_token');
        } catch {}
        return;
      }
      if (result.ok && result.data && result.data.success) {
        if (Array.isArray(result.data.adminInbox)) setAdminInbox(result.data.adminInbox);
        if (Array.isArray(result.data.bookings)) setBookings(result.data.bookings);
        if (Array.isArray(result.data.adminOrdersExcel)) setAdminOrdersExcel(result.data.adminOrdersExcel);
        if (Array.isArray(result.data.customers)) setCustomers(result.data.customers);
      }
    } catch (err) {}
  }, [adminSessionToken]);

  // Primary fresh fetch from Express server cache with anti-cache headers
  const fetchFromServer = useCallback(async () => {
    try {
      const headers: Record<string, string> = {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        Pragma: 'no-cache',
      };
      if (adminSessionToken) {
        headers['Authorization'] = `Bearer ${adminSessionToken}`;
      }
      const result = await safeFetchJson<{
        success: boolean;
        lastUpdated?: string;
        data: any;
      }>(`/api/site-data?_t=${Date.now()}`, {
        cache: 'no-store',
        headers,
      });
      if (result.ok && result.data && result.data.success && result.data.data) {
        if (result.data.lastUpdated) lastServerTimestampRef.current = result.data.lastUpdated;
        applyFirestoreContent(result.data.data);
      }
    } catch (err) {
      // Quiet failover on network hiccups
    }
    if (adminSessionToken) {
      await fetchAdminRecords(adminSessionToken);
    }
  }, [adminSessionToken, applyFirestoreContent, fetchAdminRecords]);

  // Seamless Session Verification on Mount / Reload across all browsers
  useEffect(() => {
    let isCancelled = false;
    if (!adminSessionToken) return;

    safeFetchJson<{
      success: boolean;
      valid: boolean;
      admin: { name: string; email: string; title: string; phone: string; role: string };
    }>('/api/admin/verify-token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminSessionToken}`,
      },
      body: JSON.stringify({ token: adminSessionToken }),
    })
      .then((result) => {
        if (isCancelled) return;
        if (result.ok && result.data && result.data.success && result.data.admin) {
          setIsAdminLoggedIn(true);
          setAdminEmail(result.data.admin.email);
          setCurrentAdminRole((result.data.admin.role || 'Super Admin') as AdminRole);
          fetchAdminRecords(adminSessionToken);
        } else if (result.status === 401 || (result.ok && !result.data?.valid)) {
          setAdminSessionToken(null);
          setIsAdminLoggedIn(false);
          setAdminEmail(null);
          try {
            sessionStorage.removeItem('smeltravels_admin_token');
            localStorage.removeItem('smeltravels_admin_token');
          } catch {}
        }
      })
      .catch(() => {});

    return () => {
      isCancelled = true;
    };
  }, [adminSessionToken, fetchAdminRecords]);

  // Public refresh function exposed to AdminDashboard and components
  const refreshSiteData = useCallback(async () => {
    try {
      await fetch('/api/inquiries/sync-all', { method: 'POST' });
    } catch (e) {}
    await fetchFromServer();
  }, [fetchFromServer]);

  // Real-time live synchronization for ALL users (authenticated, unauthenticated, VPN users, and all admins)
  useEffect(() => {
    let isCleanedUp = false;

    // 1. Initial fetch from Firebase Realtime Database
    fetchSiteContentFromRTDB().then((data) => {
      if (data && !isCleanedUp) {
        applyFirestoreContent(data);
      }
    });

    // 2. Initial immediate fetch from persistent Express server cache with cache-busting
    fetchFromServer();

    // 3. Realtime Database subscription (listens to all changes live)
    const unsubscribe = subscribeToSiteContent((realtimeData) => {
      if (realtimeData && !isCleanedUp) {
        applyFirestoreContent(realtimeData);
      }
    });

    // 4. Server-Sent Events (SSE) stream listener with automatic resilient reconnection
    let eventSource: EventSource | null = null;
    let sseReconnectTimer: any = null;

    function connectSSE() {
      if (isCleanedUp || typeof EventSource === 'undefined') return;
      try {
        eventSource = new EventSource('/api/site-stream');
        eventSource.onmessage = (e) => {
          try {
            const parsed = JSON.parse(e.data);
            if (parsed && (parsed.type === 'SITE_DATA_UPDATE' || parsed.type === 'INIT') && parsed.data) {
              if (parsed.lastUpdated) lastServerTimestampRef.current = parsed.lastUpdated;
              applyFirestoreContent(parsed.data);
            }
          } catch (err) {}
        };
        eventSource.onerror = () => {
          eventSource?.close();
          eventSource = null;
          if (!isCleanedUp) {
            sseReconnectTimer = setTimeout(connectSSE, 4000);
          }
        };
      } catch (e) {
        if (!isCleanedUp) {
          sseReconnectTimer = setTimeout(connectSSE, 5000);
        }
      }
    }

    connectSSE();

    // 5. Resilient Polling Fallback (Guarantees sync even on strict VPNs or proxy networks where SSE or WebSockets are buffered/blocked)
    const pollInterval = setInterval(async () => {
      if (isCleanedUp) return;
        const res = await safeFetchJson<{ lastUpdated?: string }>(`/api/site-version?_t=${Date.now()}`, {
          cache: 'no-store',
          headers: { 'Cache-Control': 'no-cache', Pragma: 'no-cache' },
        });
        if (res.ok && res.data?.lastUpdated && res.data.lastUpdated !== lastServerTimestampRef.current) {
          lastServerTimestampRef.current = res.data.lastUpdated;
          fetchFromServer();
        }
    }, 6000);

    // 6. Instant Refresh on Tab Focus / Visibility / Network Reconnect
    const handleReactivation = () => {
      if (!isCleanedUp && document.visibilityState === 'visible') {
        fetchFromServer();
      }
    };

    window.addEventListener('focus', handleReactivation);
    document.addEventListener('visibilitychange', handleReactivation);
    window.addEventListener('online', handleReactivation);

    return () => {
      isCleanedUp = true;
      if (typeof unsubscribe === 'function') unsubscribe();
      clearInterval(pollInterval);
      clearTimeout(sseReconnectTimer);
      window.removeEventListener('focus', handleReactivation);
      document.removeEventListener('visibilitychange', handleReactivation);
      window.removeEventListener('online', handleReactivation);
      eventSource?.close();
    };
  }, [applyFirestoreContent, fetchFromServer]);

  // Helper to persist admin changes directly across Firebase Realtime Database, Express server, and BroadcastChannel
  const syncToLiveServer = async (payload: Record<string, any>): Promise<boolean> => {
    try {
      return await syncAllBackends(payload);
    } catch (e: any) {
      console.warn('[Live Sync Notice]:', e?.message || e);
      return false;
    }
  };

  // Cross-tab broadcast receiver for instantaneous same-browser tab-to-tab sync
  useEffect(() => {
    let channel: BroadcastChannel | null = null;
    try {
      if (typeof BroadcastChannel !== 'undefined') {
        channel = new BroadcastChannel('smeltravels_live_feed');
        channel.onmessage = (event) => {
          if (event.data?.type === 'LIVE_FEED_SYNC' && event.data?.payload) {
            applyFirestoreContent(event.data.payload);
          }
        };
      }
    } catch (e) {}

    return () => {
      channel?.close();
    };
  }, [applyFirestoreContent]);

  // Listen for storage events (e.g. from other tabs) or custom sync events
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'settings' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          setSettings(parsed);
        } catch (err) {}
      }
    };
    const handleCustomSync = (e: any) => {
      if (e.detail) {
        setSettings(e.detail);
      }
    };
    window.addEventListener('storage', handleStorage);
    window.addEventListener('site-settings-updated', handleCustomSync);
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('site-settings-updated', handleCustomSync);
    };
  }, []);

  const showNotification = (title: string, message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    setActiveNotification({ title, message, type });
    setTimeout(() => {
      setActiveNotification((prev) => (prev?.title === title ? null : prev));
    }, 5000);
  };

  const clearNotification = () => setActiveNotification(null);

  // Listen to browser navigation (back/forward) and synchronize URL hash
  useEffect(() => {
    const handleUrlChange = () => {
      const parsed = parseUrlHash();
      if (parsed) {
        setActivePage(parsed.page);
        setPageParam(parsed.param);
        setStoredItem('active_page', parsed.page);
        setStoredItem('page_param', parsed.param);
      } else {
        if (typeof window !== 'undefined' && (window.location.hash === '' || window.location.hash === '#')) {
          setActivePage('home');
          setPageParam(null);
          setStoredItem('active_page', 'home');
          setStoredItem('page_param', null);
        }
      }
    };

    window.addEventListener('popstate', handleUrlChange);
    window.addEventListener('hashchange', handleUrlChange);

    // Initial check: if there is no hash in URL, but activePage was restored from storage (not 'home'),
    // synchronize the hash so address bar reflects the current page.
    const currentHashParsed = parseUrlHash();
    if (!currentHashParsed) {
      const stored = getStoredItem<string>('active_page', 'home');
      const storedParam = getStoredItem<string | null>('page_param', null);
      if (stored && stored !== 'home' && VALID_APP_PAGES.includes(stored as any)) {
        const hashToSet = formatUrlHash(stored, storedParam);
        if (hashToSet) {
          try {
            window.history.replaceState(null, '', hashToSet);
          } catch (e) {
            window.location.hash = hashToSet;
          }
        }
      }
    } else {
      setActivePage(currentHashParsed.page);
      setPageParam(currentHashParsed.param);
      setStoredItem('active_page', currentHashParsed.page);
      setStoredItem('page_param', currentHashParsed.param);
    }

    return () => {
      window.removeEventListener('popstate', handleUrlChange);
      window.removeEventListener('hashchange', handleUrlChange);
    };
  }, []);

  const navigateTo = (page: string, param?: string) => {
    const cleanParam = param || null;
    setActivePage(page);
    setPageParam(cleanParam);
    setStoredItem('active_page', page);
    setStoredItem('page_param', cleanParam);

    if (typeof window !== 'undefined') {
      const newHash = formatUrlHash(page, cleanParam);
      if (!newHash) {
        if (window.location.hash) {
          try {
            window.history.pushState(null, '', window.location.pathname + window.location.search);
          } catch (e) {
            window.location.hash = '';
          }
        }
      } else if (window.location.hash !== newHash) {
        try {
          window.history.pushState(null, '', newHash);
        } catch (e) {
          window.location.hash = newHash;
        }
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Settings
  const updateSettings = async (newSettings: Partial<SiteSettings>): Promise<boolean> => {
    let updatedSnapshot: SiteSettings = settings;
    setSettings(prev => {
      const updated = {
        ...prev,
        ...newSettings,
        companyBanking: {
          ...(prev.companyBanking || {}),
          ...(newSettings.companyBanking || {}),
        },
      };
      updatedSnapshot = updated;
      setStoredItem('settings', updated);
      return updated;
    });

    // Broadcast instantaneous update across windows/tabs
    try {
      window.dispatchEvent(new CustomEvent('site-settings-updated', { detail: updatedSnapshot }));
    } catch (e) {}

    // Push directly to Realtime Database and persistent server store
    const isLiveSynced = await syncToLiveServer({ settings: updatedSnapshot });
    return isLiveSynced;
  };

  const resetSettings = () => {
    setSettings(INITIAL_SETTINGS);
    syncToLiveServer({ settings: INITIAL_SETTINGS });
    showNotification('Settings Reset', 'Website configurations reverted to initial settings.');
  };

  // Local Trips Methods (Jamaican Excursions, Tours, Weekend Getaways)
  const addLocalTrip = (tripData: Omit<LocalTrip, 'id'>): string => {
    const id = `local-trip-${Date.now()}`;
    const slug = tripData.slug || tripData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newTrip: LocalTrip = {
      ...tripData,
      id,
      slug,
      orderIndex: localTrips.length,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [newTrip, ...localTrips];
    setLocalTrips(updated);
    setStoredItem('local_trips', updated);
    syncToLiveServer({ localTrips: updated });
    showNotification('Local Trip Added', `"${newTrip.title}" has been created.`);
    return id;
  };

  const updateLocalTrip = (id: string, updates: Partial<LocalTrip>) => {
    const updated = localTrips.map((t) => {
      if (t.id === id) {
        return {
          ...t,
          ...updates,
          updatedAt: new Date().toISOString(),
        };
      }
      return t;
    });
    setLocalTrips(updated);
    setStoredItem('local_trips', updated);
    syncToLiveServer({ localTrips: updated });
    showNotification('Local Trip Updated', 'Local trip changes have been saved.');
  };

  const deleteLocalTrip = (id: string) => {
    const updated = localTrips.filter((t) => t.id !== id);
    setLocalTrips(updated);
    setStoredItem('local_trips', updated);
    syncToLiveServer({ localTrips: updated });
    showNotification('Local Trip Deleted', 'The local trip has been removed.', 'info');
  };

  const reorderLocalTrips = (newTrips: LocalTrip[]) => {
    const indexed = newTrips.map((t, idx) => ({ ...t, orderIndex: idx }));
    setLocalTrips(indexed);
    setStoredItem('local_trips', indexed);
    syncToLiveServer({ localTrips: indexed });
  };

  const updateLocalTripsPageSettings = (newSettings: Partial<LocalTripsPageSettings>) => {
    const updated = { ...localTripsPageSettings, ...newSettings };
    setLocalTripsPageSettings(updated);
    setStoredItem('local_trips_settings', updated);
    syncToLiveServer({ localTripsPageSettings: updated });
    showNotification('Page Settings Updated', 'Local Trips page configurations updated.');
  };

  const saveLocalTripsToLive = async (
    customTrips?: LocalTrip[],
    customSettings?: LocalTripsPageSettings
  ): Promise<boolean> => {
    try {
      const tripsToSave = customTrips || localTrips;
      const settingsToSave = customSettings || localTripsPageSettings;
      setLocalTrips(tripsToSave);
      setLocalTripsPageSettings(settingsToSave);
      setStoredItem('local_trips', tripsToSave);
      setStoredItem('local_trips_settings', settingsToSave);

      const ok = await syncToLiveServer({
        localTrips: tripsToSave,
        localTripsPageSettings: settingsToSave,
      });

      if (ok) {
        showNotification(
          'Local Trips Saved',
          'All changes have been successfully saved and will persist on reload.',
          'success'
        );
      } else {
        showNotification(
          'Saved Locally',
          'Changes saved to local browser storage; cloud sync will retry.',
          'warning'
        );
      }
      return ok;
    } catch (e) {
      console.error('[saveLocalTripsToLive Error]:', e);
      showNotification('Save Error', 'Failed to save local trips. Please try again.', 'warning');
      return false;
    }
  };

  const openLocalTripDetail = (idOrSlug: string) => {
    let found = localTrips.find((t) => t.id === idOrSlug || t.slug === idOrSlug);
    if (!found) {
      found = INITIAL_LOCAL_TRIPS.find((t) => t.id === idOrSlug || t.slug === idOrSlug);
    }
    if (!found && settings.featuredHeroTrip) {
      const hero = settings.featuredHeroTrip;
      const parsedPrice =
        typeof hero.priceDisplay === 'string'
          ? parseInt(hero.priceDisplay.replace(/[^0-9]/g, ''), 10) || 108000
          : 108000;
      found = {
        id: hero.selectedTripId || 'royalton-negril-flash-sale-2026',
        slug: hero.targetSlugOrId || 'royalton-negril-flash-sale-2026',
        title: hero.title || 'Royalton Negril Resort & Spa — Flash Sale',
        subtitle: hero.subtitle || 'Special Offer: $108,000 for 2 Adults • 1 Child Free',
        description:
          hero.subtitle ||
          '🚨🌴 FLASH SALE ALERT! Your next getaway is calling! Escape to Royalton Negril Resort & Spa from October 30 – November 1, 2026 and enjoy a tropical experience with someone special!',
        fullDescription:
          `🚨🌴 FLASH SALE ALERT! 🇯🇲✈️\n\nYour next getaway is calling! 😍☀️ Escape to Royalton Negril Resort & Spa from October 30 – November 1, 2026 and enjoy a tropical experience with someone special!\n\n💛 SPECIAL OFFER: $108,000 for 2 adults!\n👶🏽 Bring ONE child FREE! 🎉\n\n📍 Royalton Negril, Jamaica\n📅 October 30 – November 1, 2026\n💰 Total package price: $108,000\n\nDon’t miss your chance to relax, unwind, and make unforgettable memories! 🏖️🍹\n\n📲 Book now with Smeltravels876!\n📞 Call/WhatsApp: (876) 834-1537\n🌐 www.Smeltravels876.com\n\n✨ Travel More ✈️ Stress Less! 💛💙\n\n⚠️ Flash sale offer—contact us to secure your spot!`,
        featuredImage: hero.imageUrl || '/images/royalton_negril_resort.jpg',
        location: hero.location || 'Royalton Negril, Jamaica',
        category: 'Weekend Getaways',
        price: parsedPrice,
        currency: 'JMD',
        priceType: hero.priceSubtitle || 'Two (2) Adults',
        deposit: 35000,
        duration: '3 Days / 2 Nights',
        availableDates: hero.dates || 'October 30 – November 1, 2026',
        status: 'Limited Spots',
        ctaText: hero.ctaText || 'Book Flash Sale',
        inclusions: hero.inclusions || [
          'Two (2) Adults Package ($108,000 JMD)',
          '👶🏽 Bring ONE (1) Child Allowed FREE! 🎉',
          'Luxury All-Inclusive Accommodations',
          'All Gourmet Dining, Specialty Bars & Premium Drinks',
          'Seven Mile Beach Access & Resort Pools',
          'Spa Services, Fitness Centre & Resort Activities',
        ],
        exclusions: [
          'Motorized water excursions outside resort property',
          'Airport transfer to Negril (available as add-on)',
          'Personal spa treatments and premium vintage wines',
        ],
        highlights: [
          '🚨 Flash Sale Deal',
          'Two (2) Adults $108,000',
          '👶🏽 1 Child Allowed FREE',
          'October 30 – November 1, 2026',
          'Royalton Negril Beachfront',
          'All-Inclusive Luxury',
        ],
        isPublished: true,
        isFeatured: true,
        orderIndex: 0,
        displayOptions: {
          showPrice: true,
          showDeposit: true,
          showDates: true,
          showDuration: true,
          showLocation: true,
          showAvailability: true,
          showCategory: true,
          showInclusions: true,
        },
        contactEmail: 'smeltravels876@gmail.com',
        contactPhone: '(876) 834-1537',
        createdAt: new Date().toISOString(),
      };
    }
    if (found) {
      setSelectedLocalTripDetail(found);
    }
  };

  const closeLocalTripDetail = () => {
    setSelectedLocalTripDetail(null);
  };

  const openLocalTripInquiry = (trip: LocalTrip) => {
    setSelectedLocalTripForInquiry(trip);
    const bookingTrip: TripPackage = {
      id: trip.id,
      slug: trip.slug,
      name: trip.title,
      destination: trip.location,
      country: 'Jamaica',
      countryFlag: '🇯🇲',
      year: 2026,
      dates: trip.availableDates || 'Upcoming',
      hotel: trip.location,
      price: trip.price,
      currency: trip.currency || 'JMD',
      deposit: trip.deposit || Math.round(trip.price * 0.3),
      shortDescription: trip.description,
      fullDescription: trip.fullDescription || trip.description,
      packageInclusions: trip.inclusions || [],
      exclusions: trip.exclusions || [],
      itinerary: [],
      travelRequirements: ['Valid Government-issued ID'],
      visaRequirements: 'No visa required for Jamaica local travel',
      excursions: trip.highlights || [],
      baggageInfo: 'Standard personal luggage included',
      paymentPlanInfo: 'Flexible deposit and balance payment plans available with SMELTRAVELS876',
      featuredImage: trip.featuredImage,
      gallery: [trip.featuredImage],
      status: trip.status === 'Sold Out' ? 'Sold Out' : trip.status === 'Limited Spots' ? 'Limited Availability' : 'Available',
      orderIndex: trip.orderIndex,
    };
    setSelectedTripForBooking(bookingTrip);
  };

  const closeLocalTripInquiry = () => {
    setSelectedLocalTripForInquiry(null);
  };

  // Wingo Airlines 11-Country Rates & Costs Database Methods
  const addWingoRoute = (routeData: Omit<WingoRouteRate, 'id'>): string => {
    const newId = `wingo-${Date.now()}`;
    const newRoute: WingoRouteRate = {
      ...routeData,
      id: newId,
      lastUpdated: new Date().toISOString().split('T')[0],
      updatedBy: adminEmail?.includes('smeltravels876') ? 'Elvoy Bennett' : 'Zachary Buchanan',
    };
    const updated = [newRoute, ...wingoRoutes];
    setWingoRoutes(updated);
    setStoredItem('wingo_rates_database', updated);
    fetch('/api/wingo/rates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ routes: updated }),
    }).catch(() => {});
    showNotification('Wingo Route Added', `${newRoute.originCountry} ✈ ${newRoute.destinationCountry} route configured.`, 'success');
    return newId;
  };

  const updateWingoRoute = (id: string, updates: Partial<WingoRouteRate>) => {
    const updated = wingoRoutes.map(r => r.id === id ? {
      ...r,
      ...updates,
      lastUpdated: new Date().toISOString().split('T')[0],
      updatedBy: adminEmail?.includes('smeltravels876') ? 'Elvoy Bennett' : 'Zachary Buchanan',
    } : r);
    setWingoRoutes(updated);
    setStoredItem('wingo_rates_database', updated);
    fetch('/api/wingo/rates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ routes: updated }),
    }).catch(() => {});
  };

  const deleteWingoRoute = (id: string) => {
    const updated = wingoRoutes.filter(r => r.id !== id);
    setWingoRoutes(updated);
    setStoredItem('wingo_rates_database', updated);
    fetch('/api/wingo/rates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ routes: updated }),
    }).catch(() => {});
    showNotification('Route Removed', 'Wingo route deleted from rates database.', 'info');
  };

  const batchUpdateWingoRoutes = (routes: WingoRouteRate[]) => {
    setWingoRoutes(routes);
    setStoredItem('wingo_rates_database', routes);
    fetch('/api/wingo/rates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ routes }),
    }).catch(() => {});
  };

  const saveWingoRoutesToLive = async (customRoutes?: WingoRouteRate[]): Promise<boolean> => {
    try {
      const routesToSave = customRoutes || wingoRoutes;
      setWingoRoutes(routesToSave);
      setStoredItem('wingo_rates_database', routesToSave);

      const resp = await safeFetchJson<{ success?: boolean }>('/api/wingo/rates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ routes: routesToSave }),
      });
      const data = resp.data;

      await syncToLiveServer({ wingoRoutes: routesToSave });

      if (data?.success) {
        showNotification(
          'Wingo Rates Database Saved',
          'All roundtrip, one-way rates, and costs have been synchronized to the flight verification engine.',
          'success'
        );
        return true;
      }
      showNotification('Saved Locally', 'Wingo rates saved to browser storage.', 'info');
      return true;
    } catch (e) {
      console.error('[saveWingoRoutesToLive Error]:', e);
      showNotification('Save Notice', 'Saved to local browser database.', 'info');
      return true;
    }
  };

  const resetWingoRoutesToDefault = () => {
    setWingoRoutes(INITIAL_WINGO_ROUTES);
    setStoredItem('wingo_rates_database', INITIAL_WINGO_ROUTES);
    fetch('/api/wingo/rates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ routes: INITIAL_WINGO_ROUTES }),
    }).catch(() => {});
    showNotification('Wingo Rates Reset', 'Official Wingo 11-country rates and baseline costs restored.', 'info');
  };

  // Trips
  const addTrip = (tripData: Omit<TripPackage, 'id'>) => {
    const id = `trip-${Date.now()}`;
    const newTrip: TripPackage = { ...tripData, id };
    setTrips(prev => {
      const updated = [newTrip, ...prev];
      syncToLiveServer({ trips: updated });
      return updated;
    });
    showNotification('Trip Created', `Successfully added "${newTrip.name}".`);
  };

  const updateTrip = (id: string, tripData: Partial<TripPackage>) => {
    setTrips(prev => {
      const updated = prev.map(t => (t.id === id ? { ...t, ...tripData } : t));
      syncToLiveServer({ trips: updated });
      return updated;
    });
    showNotification('Trip Updated', 'Package details were successfully saved.');
  };

  const deleteTrip = (id: string) => {
    setTrips(prev => {
      const updated = prev.filter(t => t.id !== id);
      syncToLiveServer({ trips: updated });
      return updated;
    });
    showNotification('Trip Deleted', 'Trip was removed from the system.', 'warning');
  };

  const duplicateTrip = (id: string) => {
    const existing = trips.find(t => t.id === id);
    if (!existing) return;
    const duplicated: TripPackage = {
      ...existing,
      id: `trip-${Date.now()}`,
      name: `${existing.name} (Copy)`,
      slug: `${existing.slug}-copy`,
      isFeatured: false,
    };
    setTrips(prev => {
      const updated = [duplicated, ...prev];
      syncToLiveServer({ trips: updated });
      return updated;
    });
    showNotification('Trip Duplicated', `Created a copy of ${existing.name}.`);
  };

  // Destinations
  const addDestination = (destData: Omit<Destination, 'id'>) => {
    const newDest: Destination = { ...destData, id: `dest-${Date.now()}` };
    setDestinations(prev => {
      const updated = [...prev, newDest];
      syncToLiveServer({ destinations: updated });
      return updated;
    });
    showNotification('Destination Added', `Added ${newDest.name} to directory.`);
  };

  const updateDestination = (id: string, destData: Partial<Destination>) => {
    setDestinations(prev => {
      const updated = prev.map(d => (d.id === id ? { ...d, ...destData } : d));
      syncToLiveServer({ destinations: updated });
      return updated;
    });
    showNotification('Destination Updated', 'Destination profile updated.');
  };

  const deleteDestination = (id: string) => {
    setDestinations(prev => {
      const updated = prev.filter(d => d.id !== id);
      syncToLiveServer({ destinations: updated });
      return updated;
    });
    showNotification('Destination Deleted', 'Destination was removed.', 'warning');
  };

  // Admin Inbox methods
  const addInboxItem = (itemData: Omit<AdminInboxItem, 'id' | 'timestamp' | 'isRead'>) => {
    const newItem: AdminInboxItem = {
      ...itemData,
      adminRecipients: itemData.adminRecipients || ['Elvoy Bennett', 'Zachary Buchanan'],
      recipientEmails: itemData.recipientEmails || ['zbuchanan.smeltravels@gmail.com', 'smeltravels876@gmail.com'],
      emailStatus: itemData.emailStatus || 'Delivered',
      id: `inbox-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      isRead: false,
    };
    setAdminInbox(prev => {
      const updated = [newItem, ...prev];
      syncToLiveServer({ adminInbox: updated });
      return updated;
    });
  };

  const markInboxItemAsRead = (id: string) => {
    setAdminInbox(prev => {
      const updated = prev.map(item => item.id === id ? { ...item, isRead: true } : item);
      syncToLiveServer({ adminInbox: updated });
      return updated;
    });
  };

  const markAllInboxAsRead = () => {
    setAdminInbox(prev => {
      const updated = prev.map(item => ({ ...item, isRead: true }));
      syncToLiveServer({ adminInbox: updated });
      return updated;
    });
    showNotification('Inbox Updated', 'All inbox notifications marked as read.');
  };

  const deleteInboxItem = async (id: string) => {
    const targetItem = adminInbox.find(item => item.id === id);
    const ref = targetItem?.referenceNumber;

    // Optimistically purge matching item and reference across all 3 state arrays
    setAdminInbox(prev => prev.filter(item => item.id !== id && (!ref || item.referenceNumber !== ref)));
    if (ref) {
      setBookings(prev => prev.filter(b => b.referenceNumber !== ref && b.id !== id));
      setAdminOrdersExcel(prev => prev.filter(o => o.orderRef !== ref && o.id !== id));
    }

    try {
      const headers: Record<string, string> = {};
      if (adminSessionToken) {
        headers['Authorization'] = `Bearer ${adminSessionToken}`;
      }
      const purgeKey = ref || id;
      await safeFetchJson(`/api/admin/inquiry/${encodeURIComponent(purgeKey)}`, {
        method: 'DELETE',
        headers,
      });
      await safeFetchJson(`/api/inbox/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers,
      }).catch(() => {});
    } catch (e) {
      console.warn('[deleteInboxItem purge warning]:', e);
    }

    showNotification('Inquiry Permanently Purged', 'Record permanently deleted from server database and all synchronized views.', 'info');
  };

  const unreadInboxCount = adminInbox.filter(i => !i.isRead).length;

  // Admin Order Excel Database methods (spreadsheet database for website admins)
  const addAdminOrderExcel = (orderData: Omit<AdminOrderExcelRecord, 'id' | 'receivedAt' | 'lastUpdated'>): string => {
    const now = new Date().toISOString();
    const id = `order-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newRecord: AdminOrderExcelRecord = {
      ...orderData,
      id,
      receivedAt: now,
      lastUpdated: now,
    };
    setAdminOrdersExcel(prev => {
      const updated = [newRecord, ...prev];
      syncToLiveServer({ adminOrdersExcel: updated });
      return updated;
    });
    showNotification('Order Added to Database', `Order ${newRecord.orderRef} was inserted into the Excel database.`);
    return id;
  };

  const updateAdminOrderExcel = (id: string, updates: Partial<AdminOrderExcelRecord>) => {
    const now = new Date().toISOString();
    setAdminOrdersExcel(prev => {
      const updated = prev.map(order => {
        if (order.id === id) {
          return {
            ...order,
            ...updates,
            lastUpdated: now,
          };
        }
        return order;
      });
      syncToLiveServer({ adminOrdersExcel: updated });
      return updated;
    });

    // Also sync updates to bookings if there is a matching reference number
    const targetOrder = adminOrdersExcel.find(o => o.id === id);
    const orderRef = updates.orderRef || targetOrder?.orderRef;
    if (orderRef) {
      setBookings(prev => {
        const hasMatch = prev.some(b => b.referenceNumber === orderRef);
        if (!hasMatch) return prev;
        const updated = prev.map(b => {
          if (b.referenceNumber === orderRef) {
            return {
              ...b,
              ...(updates.customerName ? { customerName: updates.customerName } : {}),
              ...(updates.email ? { email: updates.email } : {}),
              ...(updates.phone ? { phone: updates.phone } : {}),
              ...(updates.totalPrice !== undefined ? { totalPrice: updates.totalPrice } : {}),
              ...(updates.depositPaid !== undefined ? { depositPaid: updates.depositPaid } : {}),
              ...(updates.paymentSchedule !== undefined ? { paymentSchedule: updates.paymentSchedule } : {}),
              ...(updates.adminNotes ? { internalNotes: [...(b.internalNotes || []), `[Admin Edit ${new Date().toLocaleDateString()}]: ${updates.adminNotes}`] } : {}),
              updatedAt: now,
            };
          }
          return b;
        });
        syncToLiveServer({ bookings: updated });
        return updated;
      });
    }
  };

  const updateBookingPaymentSchedule = (orderIdOrRef: string, schedule: PaymentSchedule) => {
    const now = new Date().toISOString();

    // 1. Update in Excel Orders Database
    setAdminOrdersExcel(prev => {
      const updated = prev.map(order => {
        if (order.id === orderIdOrRef || order.orderRef === orderIdOrRef) {
          return {
            ...order,
            paymentSchedule: schedule,
            lastUpdated: now,
          };
        }
        return order;
      });
      syncToLiveServer({ adminOrdersExcel: updated });
      return updated;
    });

    // 2. Update in Bookings Store
    setBookings(prev => {
      const updated = prev.map(b => {
        if (b.id === orderIdOrRef || b.referenceNumber === orderIdOrRef) {
          return {
            ...b,
            paymentSchedule: schedule,
            updatedAt: now,
          };
        }
        return b;
      });
      syncToLiveServer({ bookings: updated });
      return updated;
    });

    showNotification('Payment Schedule Saved', `Installment deadlines and amounts updated for ${orderIdOrRef}.`, 'success');
  };

  const deleteAdminOrderExcel = async (id: string) => {
    const targetOrder = adminOrdersExcel.find(order => order.id === id);
    const ref = targetOrder?.orderRef;

    // Optimistically purge matching order and reference across all 3 state arrays
    setAdminOrdersExcel(prev => prev.filter(order => order.id !== id && (!ref || order.orderRef !== ref)));
    if (ref) {
      setAdminInbox(prev => prev.filter(i => i.referenceNumber !== ref && i.id !== id));
      setBookings(prev => prev.filter(b => b.referenceNumber !== ref && b.id !== id));
    }

    try {
      const headers: Record<string, string> = {};
      if (adminSessionToken) {
        headers['Authorization'] = `Bearer ${adminSessionToken}`;
      }
      const purgeKey = ref || id;
      await safeFetchJson(`/api/admin/inquiry/${encodeURIComponent(purgeKey)}`, {
        method: 'DELETE',
        headers,
      });
      await safeFetchJson(`/api/admin/orders/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers,
      }).catch(() => {});
    } catch (e) {
      console.warn('[deleteAdminOrderExcel purge warning]:', e);
    }

    showNotification('Order Row Permanently Purged', 'Row and all matching inquiry records permanently purged from database.', 'info');
  };

  const batchUpdateAdminOrdersExcel = (orders: AdminOrderExcelRecord[]) => {
    setAdminOrdersExcel(orders);
    syncToLiveServer({ adminOrdersExcel: orders });
  };

  const isOrderInExcel = useCallback((refOrIdentifier?: string, email?: string): boolean => {
    if (!refOrIdentifier && !email) return false;
    const cleanRef = (refOrIdentifier || '').trim().toLowerCase();
    const cleanEmail = (email || '').trim().toLowerCase();
    return adminOrdersExcel.some(o => {
      if (cleanRef && o.orderRef && o.orderRef.toLowerCase() === cleanRef) return true;
      if (cleanRef && o.id && o.id.toLowerCase() === cleanRef) return true;
      if (cleanEmail && o.email && o.email.toLowerCase() === cleanEmail) {
        if (!cleanRef) return true;
        if (o.tripOrDestination.toLowerCase().includes(cleanRef) || o.orderRef.toLowerCase().includes(cleanRef)) return true;
      }
      return false;
    });
  }, [adminOrdersExcel]);

  const sendInboxItemToExcel = useCallback((item: AdminInboxItem): { success: boolean; id: string; isNew: boolean } => {
    const ref = item.referenceNumber || `ORD-${Date.now().toString().slice(-6)}`;
    const now = new Date().toISOString();

    // Check if already in Excel
    const existing = adminOrdersExcel.find(o =>
      (item.referenceNumber && o.orderRef.toLowerCase() === item.referenceNumber.toLowerCase()) ||
      (item.senderEmail && o.email.toLowerCase() === item.senderEmail.toLowerCase() && item.tripName && o.tripOrDestination.toLowerCase().includes(item.tripName.toLowerCase()))
    );

    if (existing) {
      showNotification(
        'Already in Excel Database',
        `Order #${existing.orderRef} (${existing.customerName}) is already recorded in the Excel database.`,
        'info'
      );
      return { success: true, id: existing.id, isNew: false };
    }

    let orderType: OrderTypeCategory = 'Booking Inquiry';
    if (item.type === 'custom_trip') orderType = 'Custom Trip';
    else if (item.type === 'deposit') orderType = 'Deposit Record';
    else if (item.type === 'message') orderType = 'Contact Order';

    const matchingBooking = bookings.find(b =>
      (item.referenceNumber && b.referenceNumber.toLowerCase() === item.referenceNumber.toLowerCase()) ||
      (item.senderEmail && b.email.toLowerCase() === item.senderEmail.toLowerCase())
    );

    let adultsCount = matchingBooking?.adultsCount || 1;
    let childrenCount = matchingBooking?.childrenCount || 0;
    let travelDates = matchingBooking?.preferredTravelDate || 'Upcoming 2026/2027';

    if (!matchingBooking && item.details) {
      const adultsMatch = item.details.match(/(\d+)\s*Adult/i) || item.summary.match(/(\d+)\s*traveler/i);
      if (adultsMatch) adultsCount = parseInt(adultsMatch[1], 10);
      const childrenMatch = item.details.match(/(\d+)\s*Child/i);
      if (childrenMatch) childrenCount = parseInt(childrenMatch[1], 10);
      const dateMatch = item.details.match(/Travel Dates?:\s*([^\n]+)/i) || item.details.match(/Dates?:\s*([^\n]+)/i);
      if (dateMatch) travelDates = dateMatch[1].trim();
    }

    const tripOrDestination = item.tripName || (item.title ? item.title.replace(/^(New Booking Inquiry|Custom Trip Request|New Contact Message|Deposit Recorded):\s*/i, '') : 'Caribbean Travel');
    const depositPaid = item.type === 'deposit' ? (item.amount || 0) : (matchingBooking?.depositPaid || 0);
    const totalPrice = matchingBooking?.totalPrice || (item.amount ? item.amount : 0);
    const paymentStatus: OrderPaymentStatus = depositPaid > 0 ? (depositPaid >= totalPrice && totalPrice > 0 ? 'Paid in Full' : 'Deposit Paid') : 'Unpaid';
    const orderStatus: OrderWorkflowStatus = item.type === 'deposit' ? 'Deposit Received' : 'New';

    // Extract customer's selected budget
    let budget = matchingBooking?.budget;
    if (!budget && item.details) {
      const budgetMatch = item.details.match(/Budget:\s*([^\n\r]+)/i);
      if (budgetMatch && budgetMatch[1]) {
        budget = budgetMatch[1].trim();
      }
    }
    if (!budget && matchingBooking?.specialRequests) {
      const budgetMatch = matchingBooking.specialRequests.match(/Budget:\s*([^\n\r]+)/i);
      if (budgetMatch && budgetMatch[1]) {
        budget = budgetMatch[1].trim();
      }
    }
    if (!budget) {
      if (totalPrice > 0) {
        budget = `${formatPriceJMD(totalPrice)} (Package Total)`;
      } else if (depositPaid > 0) {
        budget = `${formatPriceJMD(depositPaid)} (Deposit Amount)`;
      } else {
        budget = 'Standard Package';
      }
    }

    const newRecord: AdminOrderExcelRecord = {
      id: `order-excel-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      orderRef: ref,
      receivedAt: item.timestamp || now,
      orderType,
      customerName: item.senderName || 'Traveler',
      email: item.senderEmail || '',
      phone: item.senderPhone || '',
      parishOrCountry: matchingBooking?.countryOrParish || 'Jamaica',
      tripOrDestination,
      travelDates,
      adultsCount,
      childrenCount,
      budget,
      numericalBudget: matchingBooking?.numericalBudget || (budget ? parseFloat(budget.replace(/[^0-9.]/g, '')) || 0 : 0),
      totalPrice,
      depositPaid,
      currency: item.currency || 'JMD',
      paymentStatus,
      orderStatus,
      preferredContact: (matchingBooking?.preferredContactMethod ? (matchingBooking.preferredContactMethod.charAt(0).toUpperCase() + matchingBooking.preferredContactMethod.slice(1)) : 'WhatsApp') as any,
      assignedAdmin: matchingBooking?.ambassadorName || (adminEmail?.includes('smeltravels876') ? 'Elvoy Bennett' : 'Zachary Buchanan'),
      ambassadorCode: matchingBooking?.ambassadorCode,
      specialRequests: item.details || item.summary,
      inclusions: matchingBooking ? 'Flights, Hotel, Airport Transfers' : 'Standard Agency Travel Package',
      adminNotes: `Transferred to Excel database from Admin Inbox (${item.type}) on ${new Date().toLocaleDateString()}. Ref: ${ref}`,
      lastUpdated: now,
    };

    const updated = [newRecord, ...adminOrdersExcel];
    setAdminOrdersExcel(updated);
    syncToLiveServer({ adminOrdersExcel: updated });

    showNotification(
      'Added to Excel Database! 📊',
      `Order #${ref} for ${item.senderName} (${tripOrDestination}) has been sent into the Excel database spreadsheet.`,
      'success'
    );

    return { success: true, id: newRecord.id, isNew: true };
  }, [adminOrdersExcel, bookings, adminEmail, showNotification]);

  const sendBookingToExcel = useCallback((booking: BookingSubmission): { success: boolean; id: string; isNew: boolean } => {
    const ref = booking.referenceNumber;
    const now = new Date().toISOString();

    const existing = adminOrdersExcel.find(o => o.orderRef.toLowerCase() === ref.toLowerCase());
    if (existing) {
      showNotification('Already in Excel Database', `Inquiry #${ref} (${booking.customerName}) is already in the Excel Database.`, 'info');
      return { success: true, id: existing.id, isNew: false };
    }

    const isCustom = booking.tripId?.includes('custom') || booking.tripName?.toLowerCase().includes('custom');
    const orderType: OrderTypeCategory = isCustom ? 'Custom Trip' : 'Booking Inquiry';
    const depositPaid = booking.depositPaid || 0;
    const totalPrice = booking.totalPrice || 0;
    const paymentStatus: OrderPaymentStatus = depositPaid > 0 ? (depositPaid >= totalPrice && totalPrice > 0 ? 'Paid in Full' : 'Deposit Paid') : 'Unpaid';
    const orderStatus: OrderWorkflowStatus = (booking.status as any) || 'New';

    // Extract customer's selected budget
    let budget = booking.budget;
    if (!budget && booking.specialRequests) {
      const budgetMatch = booking.specialRequests.match(/Budget:\s*([^\n\r]+)/i);
      if (budgetMatch && budgetMatch[1]) {
        budget = budgetMatch[1].trim();
      }
    }
    if (!budget) {
      budget = totalPrice > 0 ? `${formatPriceJMD(totalPrice)} (Package Total)` : 'Standard Package';
    }

    const newRecord: AdminOrderExcelRecord = {
      id: `order-excel-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      orderRef: ref,
      receivedAt: booking.createdAt || now,
      orderType,
      customerName: booking.customerName,
      email: booking.email,
      phone: booking.phone || '',
      parishOrCountry: booking.countryOrParish || 'Jamaica',
      tripOrDestination: booking.tripName,
      travelDates: booking.preferredTravelDate || 'Upcoming 2026/2027',
      adultsCount: booking.adultsCount || 1,
      childrenCount: booking.childrenCount || 0,
      budget,
      numericalBudget: booking.numericalBudget || (budget ? parseFloat(budget.replace(/[^0-9.]/g, '')) || 0 : 0),
      totalPrice,
      depositPaid,
      currency: booking.currency || 'JMD',
      paymentStatus,
      orderStatus,
      preferredContact: (booking.preferredContactMethod ? (booking.preferredContactMethod.charAt(0).toUpperCase() + booking.preferredContactMethod.slice(1)) : 'WhatsApp') as any,
      assignedAdmin: booking.ambassadorName || 'Zachary Buchanan',
      ambassadorCode: booking.ambassadorCode,
      specialRequests: booking.specialRequests,
      inclusions: 'Flights, Hotel, Airport Transfers',
      adminNotes: `Added to Excel database from Inquiries roster on ${new Date().toLocaleDateString()}.`,
      lastUpdated: now,
    };

    const updated = [newRecord, ...adminOrdersExcel];
    setAdminOrdersExcel(updated);
    syncToLiveServer({ adminOrdersExcel: updated });

    showNotification(
      'Added to Excel Database! 📊',
      `Booking #${ref} for ${booking.customerName} (${booking.tripName}) added to Excel database spreadsheet.`,
      'success'
    );

    return { success: true, id: newRecord.id, isNew: true };
  }, [adminOrdersExcel, showNotification]);

  const syncAllInboxOrdersToExcel = useCallback((): { totalAdded: number; totalExisting: number } => {
    let addedCount = 0;
    let existingCount = 0;
    const now = new Date().toISOString();
    const newItemsToAdd: AdminOrderExcelRecord[] = [];

    const eligibleItems = adminInbox.filter(i => ['inquiry', 'custom_trip', 'deposit', 'message'].includes(i.type));

    for (const item of eligibleItems) {
      const ref = item.referenceNumber || `ORD-${Date.now().toString().slice(-6)}`;
      const alreadyExists = adminOrdersExcel.some(o =>
        (item.referenceNumber && o.orderRef.toLowerCase() === item.referenceNumber.toLowerCase()) ||
        (item.senderEmail && o.email.toLowerCase() === item.senderEmail.toLowerCase() && item.tripName && o.tripOrDestination.toLowerCase().includes(item.tripName.toLowerCase()))
      ) || newItemsToAdd.some(o => o.orderRef.toLowerCase() === ref.toLowerCase());

      if (alreadyExists) {
        existingCount++;
      } else {
        let orderType: OrderTypeCategory = 'Booking Inquiry';
        if (item.type === 'custom_trip') orderType = 'Custom Trip';
        else if (item.type === 'deposit') orderType = 'Deposit Record';
        else if (item.type === 'message') orderType = 'Contact Order';

        const matchingBooking = bookings.find(b => item.referenceNumber && b.referenceNumber.toLowerCase() === item.referenceNumber.toLowerCase());
        const tripOrDestination = item.tripName || (item.title ? item.title.replace(/^(New Booking Inquiry|Custom Trip Request|New Contact Message|Deposit Recorded):\s*/i, '') : 'Caribbean Travel');
        const depositPaid = item.type === 'deposit' ? (item.amount || 0) : (matchingBooking?.depositPaid || 0);
        const totalPrice = matchingBooking?.totalPrice || (item.amount ? item.amount : 0);

        let budget = matchingBooking?.budget;
        if (!budget && item.details) {
          const budgetMatch = item.details.match(/Budget:\s*([^\n\r]+)/i);
          if (budgetMatch && budgetMatch[1]) {
            budget = budgetMatch[1].trim();
          }
        }
        if (!budget && matchingBooking?.specialRequests) {
          const budgetMatch = matchingBooking.specialRequests.match(/Budget:\s*([^\n\r]+)/i);
          if (budgetMatch && budgetMatch[1]) {
            budget = budgetMatch[1].trim();
          }
        }
        if (!budget) {
          budget = totalPrice > 0 ? `${formatPriceJMD(totalPrice)} (Package Total)` : (depositPaid > 0 ? `${formatPriceJMD(depositPaid)} (Deposit)` : 'Standard Package');
        }

        const record: AdminOrderExcelRecord = {
          id: `order-excel-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
          orderRef: ref,
          receivedAt: item.timestamp || now,
          orderType,
          customerName: item.senderName || 'Traveler',
          email: item.senderEmail || '',
          phone: item.senderPhone || '',
          parishOrCountry: matchingBooking?.countryOrParish || 'Jamaica',
          tripOrDestination,
          travelDates: matchingBooking?.preferredTravelDate || 'Upcoming 2026/2027',
          adultsCount: matchingBooking?.adultsCount || 1,
          childrenCount: matchingBooking?.childrenCount || 0,
          budget,
          numericalBudget: matchingBooking?.numericalBudget || (budget ? parseFloat(budget.replace(/[^0-9.]/g, '')) || 0 : 0),
          totalPrice,
          depositPaid,
          currency: item.currency || 'JMD',
          paymentStatus: depositPaid > 0 ? 'Deposit Paid' : 'Unpaid',
          orderStatus: item.type === 'deposit' ? 'Deposit Received' : 'New',
          preferredContact: 'WhatsApp',
          assignedAdmin: matchingBooking?.ambassadorName || 'Zachary Buchanan',
          specialRequests: item.details || item.summary,
          inclusions: 'Standard Agency Travel Package',
          adminNotes: `Batch transferred to Excel database on ${new Date().toLocaleDateString()}`,
          lastUpdated: now,
        };

        newItemsToAdd.push(record);
        addedCount++;
      }
    }

    if (addedCount > 0) {
      setAdminOrdersExcel(prev => {
        const updated = [...newItemsToAdd, ...prev];
        syncToLiveServer({ adminOrdersExcel: updated });
        return updated;
      });
      showNotification(
        'Excel Database Updated! 📊',
        `Successfully added ${addedCount} order(s) into the Excel database.`,
        'success'
      );
    } else {
      showNotification(
        'All Orders Already in Excel',
        `All ${eligibleItems.length} current orders are already present in the Excel spreadsheet database.`,
        'info'
      );
    }

    return { totalAdded: addedCount, totalExisting: existingCount };
  }, [adminInbox, adminOrdersExcel, bookings, showNotification]);

  // Bookmarks / Saved Trips methods
  const toggleSaveTrip = (tripId: string) => {
    setSavedTripIds(prev => {
      const exists = prev.includes(tripId);
      if (exists) {
        showNotification('Bookmark Removed', 'Trip removed from your saved list.', 'info');
        return prev.filter(id => id !== tripId);
      } else {
        const trip = trips.find(t => t.id === tripId);
        showNotification('Trip Bookmarked! 📌', `Saved "${trip ? trip.name : 'Trip'}" to your wishlist.`);
        return [...prev, tripId];
      }
    });
  };

  const isTripSaved = (tripId: string): boolean => {
    return savedTripIds.includes(tripId);
  };

  const clearAllSavedTrips = () => {
    setSavedTripIds([]);
    showNotification('Saved Trips Cleared', 'All bookmarks have been removed.', 'info');
  };

  const savedTrips: TripPackage[] = trips.filter(t => savedTripIds.includes(t.id));

  const openSavedTripsDrawer = () => setIsSavedTripsDrawerOpen(true);
  const closeSavedTripsDrawer = () => setIsSavedTripsDrawerOpen(false);

  // Custom Trip Creation & Planning
  const openCustomTripModal = (initialCountryOrDestination?: string) => {
    if (initialCountryOrDestination) {
      setSelectedDestinationForCustomTrip(initialCountryOrDestination);
    }
    setIsCustomTripModalOpen(true);
  };

  const closeCustomTripModal = () => {
    setIsCustomTripModalOpen(false);
    setSelectedDestinationForCustomTrip(null);
  };

  const submitCustomTripRequest = async (data: CustomTripRequestInput): Promise<{ success: boolean; referenceNumber: string }> => {
    const ref = `CUSTOM-${Math.floor(10000 + Math.random() * 90000)}`;
    const now = new Date().toISOString();
    const recipients = ['zbuchanan.smeltravels@gmail.com', 'smeltravels876@gmail.com'];
    const adminRecipients = ['Elvoy Bennett', 'Zachary Buchanan'];

    const arrivalDateVal = (data.startDate || data.arrivalDate || '').trim();
    const departureDateVal = (data.endDate || data.departureDate || '').trim();

    const formatReadable = (isoDate: string) => {
      try {
        if (/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) {
          const [y, m, d] = isoDate.split('-').map(Number);
          const dt = new Date(Date.UTC(y, m - 1, d));
          return dt.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
        }
      } catch {}
      return isoDate;
    };

    const formattedArrival = arrivalDateVal ? formatReadable(arrivalDateVal) : '';
    const formattedDeparture = departureDateVal ? formatReadable(departureDateVal) : '';
    const datesSummary = formattedArrival && formattedDeparture
      ? `Arrival: ${formattedArrival} · Departure: ${formattedDeparture}`
      : (data.travelDatesType === 'specific' && data.startDate ? `${data.startDate}${data.endDate ? ` to ${data.endDate}` : ''}` : (data.flexibleSeason || 'Flexible 2026/2027'));

    const durationStr = data.durationDays ? `${data.durationDays} Days` : 'Flexible';
    const travelersStr = `${data.adultsCount || 1} Adult(s)${data.childrenCount ? `, ${data.childrenCount} Children` : ''}`;
    const originStr = data.originLocationDisplay ||
      (data.originCountry ? `${data.originCity || 'Unknown City'}, ${data.originCountry}${data.originAirportCode ? ` (${data.originAirportCode})` : ''}` : 'Not Specified');
    const flightStatus = data.flightPricingStatus || 'Estimated';

    // 1. Immediately log to local onsite Admin Inbox for ALL ADMINS
    const newInboxItem: AdminInboxItem = {
      id: `inbox-custom-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      type: 'custom_trip',
      title: flightStatus === 'Manual Flight Pricing Required'
        ? `[Manual Flight Quote Req] Custom Trip: ${data.destination} (From: ${originStr})`
        : `Custom Trip: ${data.destination} from ${originStr} (${data.customerName})`,
      senderName: data.customerName,
      senderEmail: data.email,
      senderPhone: data.phone || 'N/A',
      arrivalDate: arrivalDateVal,
      departureDate: departureDateVal,
      travelDates: datesSummary,
      travelersCount: travelersStr,
      location: data.countryOrParish || originStr || 'Jamaica',
      preferredContact: data.preferredContactMethod || 'WhatsApp',
      customerMessage: data.specialRequests || `Custom vacation request to ${data.destination}.`,
      summary: `Custom trip to ${data.destination} from ${originStr} (${datesSummary}, ${travelersStr}). Flight Status: ${flightStatus}. Dispatched to Elvoy Bennett & Zachary Buchanan (${recipients.join(' & ')}).`,
      details: `CUSTOM TRIP DETAILS:\nOrigin / Departure: ${originStr}\nDestination: ${data.destination} (${data.country})\nArrival Date: ${formattedArrival || arrivalDateVal}\nDeparture Date: ${formattedDeparture || departureDateVal}\nDuration: ${durationStr}\nTravelers: ${travelersStr}\nStyle: ${data.travelStyle}\nRoom: ${data.roomOccupancy || 'Double'}\nCabin Class: ${data.cabinClass || 'Economy'}\nFlight Pricing Status: ${flightStatus}\nVibe: ${data.tripVibe}\nBudget: ${data.budgetPerPerson || 'Flexible'}\nInclusions: ${(data.mustHaveInclusions || []).join(', ')}\nSpecial Notes: ${data.specialRequests || 'None'}\n\nTRAVELER:\nName: ${data.customerName}\nEmail: ${data.email}\nPhone: ${data.phone || 'N/A'}\nParish/Region: ${data.countryOrParish || 'Jamaica'}\nPreferred Contact: ${data.preferredContactMethod || 'WhatsApp'}\nAmbassador: ${data.preferredAmbassador || 'Executive Operations Desk'}\nDispatched to: ${recipients.join(', ')}`,
      tripName: `Custom: ${data.destination}`,
      referenceNumber: ref,
      timestamp: now,
      isRead: false,
      adminRecipients,
      recipientEmails: recipients,
      emailStatus: 'Delivered',
    };

    setAdminInbox(prev => {
      const updated = [newInboxItem, ...prev];
      syncToLiveServer({ adminInbox: updated });
      return updated;
    });

    // 2. Add to Bookings as a custom trip request record
    const numericalBudgetValue = Number(data.budgetAmount) || data.numericalBudget || (data.budgetPerPerson ? parseFloat(data.budgetPerPerson.replace(/[^0-9.]/g, '')) || 0 : 0);
    const newBooking: BookingSubmission = {
      id: `booking-custom-${Date.now()}`,
      referenceNumber: ref,
      tripId: `custom-${data.country.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
      tripName: `Custom Trip: ${data.destination}`,
      customerName: data.customerName,
      email: data.email,
      phone: data.phone || '',
      countryOrParish: data.countryOrParish || 'Jamaica',
      adultsCount: Number(data.adultsCount) || 1,
      childrenCount: Number(data.childrenCount) || 0,
      preferredTravelDate: datesSummary,
      arrivalDate: arrivalDateVal,
      departureDate: departureDateVal,
      travelInterestType: 'ready_to_book',
      specialRequests: `[Custom Trip Request]\nOrigin: ${originStr}\nDestination: ${data.destination} (${data.country})\nArrival Date: ${formattedArrival || arrivalDateVal}\nDeparture Date: ${formattedDeparture || departureDateVal} (${durationStr})\nTravelers: ${travelersStr}\nStyle: ${data.travelStyle}\nRoom: ${data.roomOccupancy || 'Double'}\nCabin: ${data.cabinClass || 'Economy'}\nFlight Status: ${flightStatus}\nBudget: ${numericalBudgetValue > 0 ? `${numericalBudgetValue} ${data.budgetCurrency || 'USD'}` : (data.budgetPerPerson || 'Flexible')}\nInclusions: ${(data.mustHaveInclusions || []).join(', ')}\nNotes: ${data.specialRequests || 'None'}`,
      preferredContactMethod: data.preferredContactMethod || 'whatsapp',
      status: 'Custom Trip Request' as any,
      depositPaid: 0,
      totalPrice: data.estimatedMinimumBudgetTotal || 0,
      currency: data.budgetCurrency || 'USD',
      budget: numericalBudgetValue > 0 ? String(numericalBudgetValue) : (data.budgetAmount || data.budgetPerPerson || 'Flexible'),
      numericalBudget: numericalBudgetValue,
      ambassadorName: data.preferredAmbassador,
      internalNotes: [`Custom trip submitted on ${now} departing from ${originStr} with arrival ${formattedArrival} and departure ${formattedDeparture}. Flight Pricing: ${flightStatus}. Dispatched to Elvoy Bennett & Zachary Buchanan.`],
      createdAt: now,
      updatedAt: now,
    };

    setBookings(prev => {
      const updated = [newBooking, ...prev];
      syncToLiveServer({ bookings: updated });
      return updated;
    });

    // 2b. Automatically collect and store in Excel database for website admins
    const customExcelRecord: AdminOrderExcelRecord = {
      id: `order-custom-${Date.now()}`,
      orderRef: ref,
      receivedAt: now,
      orderType: 'Custom Trip',
      customerName: data.customerName,
      email: data.email,
      phone: data.phone || '',
      parishOrCountry: data.countryOrParish || 'Jamaica',
      tripOrDestination: `${data.destination} (${data.country})`,
      travelDates: datesSummary,
      arrivalDate: arrivalDateVal,
      departureDate: departureDateVal,
      adultsCount: Number(data.adultsCount) || 1,
      childrenCount: Number(data.childrenCount) || 0,
      budget: numericalBudgetValue > 0 ? String(numericalBudgetValue) : (data.budgetAmount || data.budgetPerPerson || 'Flexible'),
      numericalBudget: numericalBudgetValue,
      totalPrice: data.estimatedMinimumBudgetTotal || 0,
      depositPaid: 0,
      currency: data.budgetCurrency || 'USD',
      paymentStatus: 'Unpaid',
      orderStatus: 'New',
      preferredContact: (data.preferredContactMethod ? (data.preferredContactMethod.charAt(0).toUpperCase() + data.preferredContactMethod.slice(1)) : 'WhatsApp') as any,
      assignedAdmin: data.preferredAmbassador || 'Elvoy Bennett',
      specialRequests: data.specialRequests,
      inclusions: (data.mustHaveInclusions || []).join(', '),
      originLocation: originStr,
      flightPricingStatus: flightStatus,
      adminNotes: `Origin: ${originStr} | Flight Status: ${flightStatus}${flightStatus === 'Manual Flight Pricing Required' ? ' [MANUAL FLIGHT PRICING REQUIRED]' : ''} | Custom trip to ${data.destination} received on ${now}. Dispatched to Elvoy Bennett & Zachary Buchanan.`,
      lastUpdated: now,
    };
    setAdminOrdersExcel(prev => {
      const updated = [customExcelRecord, ...prev];
      syncToLiveServer({ adminOrdersExcel: updated });
      return updated;
    });

    // 3. Dispatch to server endpoint for live admin email dispatch and persistence
    try {
      await fetch('/api/custom-trip-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, referenceNumber: ref }),
      });
    } catch (e) {
      console.warn('[Custom Trip Request Dispatch Warning]:', e);
    }

    showNotification(
      'Custom Trip Request Received! ✈️',
      `Your custom journey to ${data.destination} (Ref #${ref}) has been routed to all admins. We will craft your itinerary!`
    );

    return { success: true, referenceNumber: ref };
  };

  // Spot Booking - Direct and accessible to all travelers without forced login
  const secureSpotForTrip = (trip: TripPackage) => {
    setSelectedTripForBooking(trip);
  };

  // Ambassador Code validation
  const verifyAmbassadorCode = (code: string) => {
    const clean = (code || '').trim().toUpperCase();
    const discountPct = settings.ambassadorDiscountPercentage ?? 10;
    const match = (settings.ambassadors || []).find(
      a => a.code && a.code.toUpperCase() === clean && a.isActive !== false
    );
    if (match) {
      return { valid: true, ambassador: match, discountPercentage: discountPct };
    }
    return { valid: false, discountPercentage: discountPct };
  };

  // Bookings & Inquiries
  const createBooking = (data: Omit<BookingSubmission, 'id' | 'referenceNumber' | 'createdAt' | 'updatedAt' | 'internalNotes'>): string => {
    const now = new Date();
    const yearPrefix = now.getFullYear();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const ref = `ST-${yearPrefix}-${randomSuffix}`;
    const id = `booking-${Date.now()}`;

    const newBooking: BookingSubmission = {
      ...data,
      id,
      referenceNumber: ref,
      internalNotes: [`Submission received via website on ${now.toLocaleString()}`],
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    setBookings(prev => {
      const updated = [newBooking, ...prev];
      syncToLiveServer({ bookings: updated });
      return updated;
    });

    // Automatically collect and store in Excel database for website admins
    const excelOrder: AdminOrderExcelRecord = {
      id: `order-book-${Date.now()}`,
      orderRef: ref,
      receivedAt: now.toISOString(),
      orderType: 'Booking Inquiry',
      customerName: data.customerName,
      email: data.email,
      phone: data.phone || '',
      parishOrCountry: data.countryOrParish || 'Jamaica',
      tripOrDestination: data.tripName,
      travelDates: data.preferredTravelDate || '2026/2027 Season',
      adultsCount: data.adultsCount || 1,
      childrenCount: data.childrenCount || 0,
      budget: data.budget || (data.totalPrice ? `${formatPriceJMD(data.totalPrice)} (Package Total)` : 'Standard Package'),
      totalPrice: data.totalPrice || 0,
      depositPaid: data.depositPaid || 0,
      currency: data.currency || 'JMD',
      paymentStatus: (data.depositPaid && data.depositPaid > 0) ? 'Deposit Paid' : 'Unpaid',
      orderStatus: (data.status as any) || 'New',
      preferredContact: (data.preferredContactMethod ? (data.preferredContactMethod.charAt(0).toUpperCase() + data.preferredContactMethod.slice(1)) : 'WhatsApp') as any,
      assignedAdmin: data.ambassadorName ? data.ambassadorName : 'Zachary Buchanan',
      ambassadorCode: data.ambassadorCode,
      specialRequests: data.specialRequests,
      inclusions: 'Flights, Hotel, Airport Transfers, 2 Excursions',
      adminNotes: `Online booking inquiry received on ${now.toLocaleString()}.`,
      lastUpdated: now.toISOString(),
    };
    setAdminOrdersExcel(prev => {
      const updated = [excelOrder, ...prev];
      syncToLiveServer({ adminOrdersExcel: updated });
      return updated;
    });

    // Notify Admin Inbox: Inquiry for BOTH Elvoy Bennett and Zachary Buchanan
    addInboxItem({
      type: 'inquiry',
      title: `New Booking Inquiry: ${data.tripName}`,
      senderName: data.customerName,
      senderEmail: data.email,
      senderPhone: data.phone,
      summary: `Inquiry submitted for ${data.adultsCount} traveler(s). Interest: ${data.travelInterestType === 'ready_to_book' ? 'Ready to Book & Lock In Spot' : 'General Inquiry'}. Routed to Elvoy Bennett & Zachary Buchanan.`,
      details: data.specialRequests || `Travel Date: ${data.preferredTravelDate}. Preferred Contact: ${data.preferredContactMethod}. Total: $${data.totalPrice?.toLocaleString()} JMD.`,
      tripId: data.tripId,
      tripName: data.tripName,
      referenceNumber: ref,
      adminRecipients: ['Elvoy Bennett', 'Zachary Buchanan'],
      recipientEmails: ['zbuchanan.smeltravels@gmail.com', 'smeltravels876@gmail.com'],
      emailStatus: 'Delivered',
    });

    // Automated backend email dispatch to zbuchanan.smeltravels@gmail.com & smeltravels876@gmail.com
    try {
      fetch('/api/trip-inquiry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tripId: data.tripId,
          tripName: data.tripName,
          customerName: data.customerName,
          email: data.email,
          phone: data.phone,
          parish: data.countryOrParish,
          inquiryText: data.specialRequests || `Booking inquiry for ${data.tripName} (${data.adultsCount} travelers).`,
          inquiryType: data.travelInterestType,
          preferredContactMethod: data.preferredContactMethod,
          adultsCount: data.adultsCount,
        }),
      }).catch((e) => console.warn('[createBooking] automated notification', e));

      // Automated Resend Transactional Email Dispatch (bookings@smeltravels876.com)
      // 1. Customer Confirmation
      fetch('/api/resend/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'booking_customer',
          to: data.email,
          sender: 'SMELTRAVELS876 Bookings <bookings@smeltravels876.com>',
          data: {
            referenceNumber: ref,
            customerName: data.customerName,
            email: data.email,
            phone: data.phone,
            tripName: data.tripName,
            preferredTravelDate: data.preferredTravelDate,
            adultsCount: data.adultsCount,
            childrenCount: data.childrenCount,
            totalPrice: data.totalPrice,
            depositPaid: data.depositPaid,
            ambassadorName: data.ambassadorName,
          },
        }),
      }).catch((e) => console.warn('[createBooking Customer Resend Notice]:', e));

      // 2. Admin Alert
      fetch('/api/resend/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'booking_admin',
          to: ['zbuchanan.smeltravels@gmail.com', 'smeltravels876@gmail.com', 'zacpremacc12@gmail.com'],
          sender: 'SMELTRAVELS876 Bookings <bookings@smeltravels876.com>',
          data: {
            referenceNumber: ref,
            customerName: data.customerName,
            email: data.email,
            phone: data.phone,
            countryOrParish: data.countryOrParish,
            tripName: data.tripName,
            totalPrice: data.totalPrice,
            depositPaid: data.depositPaid,
            ambassadorName: data.ambassadorName,
          },
        }),
      }).catch((e) => console.warn('[createBooking Admin Resend Notice]:', e));
    } catch (e) {}

    // Upsert Customer
    setCustomers(prev => {
      const existing = prev.find(c => c.email.toLowerCase() === data.email.toLowerCase());
      let updatedCustomers: CustomerRecord[];
      if (existing) {
        updatedCustomers = prev.map(c =>
          c.id === existing.id
            ? {
                ...c,
                tripsOfInterest: Array.from(new Set([...c.tripsOfInterest, data.tripName])),
                inquiryCount: c.inquiryCount + 1,
                bookingCount: data.travelInterestType === 'ready_to_book' ? c.bookingCount + 1 : c.bookingCount,
              }
            : c
        );
      } else {
        const newCustomer: CustomerRecord = {
          id: `cust-${Date.now()}`,
          name: data.customerName,
          email: data.email,
          phone: data.phone,
          countryOrParish: data.countryOrParish,
          tripsOfInterest: [data.tripName],
          bookingCount: data.travelInterestType === 'ready_to_book' ? 1 : 0,
          inquiryCount: 1,
          totalSpent: 0,
          notes: [`Inquired about ${data.tripName} with reference ${ref}`],
          status: data.travelInterestType === 'ready_to_book' ? 'Active Traveler' : 'Lead',
          communicationPreference: data.preferredContactMethod,
          createdAt: now.toISOString().split('T')[0],
        };
        updatedCustomers = [newCustomer, ...prev];
      }
      syncToLiveServer({ customers: updatedCustomers });
      return updatedCustomers;
    });

    return ref;
  };

  // Complete WiPay booking & payment automatically (or credit installment on existing order)
  const completeWiPayBooking = (bookingData: Partial<BookingSubmission>): BookingSubmission => {
    const now = new Date();
    const yearPrefix = now.getFullYear();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const ref = bookingData.referenceNumber || (bookingData as any).orderRef || `ST-${yearPrefix}-${randomSuffix}`;
    const generatedTxn = (bookingData as any).transactionId || `WP-JM-${Math.floor(100000 + Math.random() * 900000)}`;

    const depositAmount = bookingData.depositPaid || 0;
    const tripTitle = bookingData.tripName || 'Jamaican Tour & Travel';
    const totalPkgPrice = bookingData.totalPrice || depositAmount;
    const remainingBalance = Math.max(0, totalPkgPrice - depositAmount);

    // Check if this payment is for an existing booking / inquiry installment
    const targetRef = bookingData.referenceNumber || (bookingData as any).orderRef;
    const existingBooking = targetRef ? bookings.find(b => b.referenceNumber === targetRef || b.id === targetRef) : null;
    const existingOrder = targetRef ? adminOrdersExcel.find(o => o.orderRef === targetRef || o.id === targetRef) : null;

    if (existingBooking || existingOrder) {
      const currentDepositPaid = (existingBooking?.depositPaid || existingOrder?.depositPaid || 0) + depositAmount;
      const total = existingBooking?.totalPrice || existingOrder?.totalPrice || totalPkgPrice;
      const newRemaining = Math.max(0, total - currentDepositPaid);
      const isNowPaidInFull = total > 0 && currentDepositPaid >= total;

      // Update payment schedule
      let updatedSchedule: PaymentSchedule | undefined = existingOrder?.paymentSchedule || existingBooking?.paymentSchedule;
      if (updatedSchedule && updatedSchedule.installments) {
        let installmentMarked = false;
        const updatedInstallments = updatedSchedule.installments.map(inst => {
          if (!installmentMarked && inst.status !== 'Paid') {
            installmentMarked = true;
            return {
              ...inst,
              status: 'Paid' as const,
              paidAt: now.toISOString(),
              transactionRef: generatedTxn,
              paymentMethod: 'WiPay Jamaica Live',
            };
          }
          return inst;
        });

        updatedSchedule = {
          ...updatedSchedule,
          depositPaid: currentDepositPaid,
          remainingBalance: newRemaining,
          installments: updatedInstallments,
          lastConfiguredAt: now.toISOString(),
        };
      }

      // Update existing booking
      let returnedBooking: BookingSubmission = existingBooking ? {
        ...existingBooking,
        depositPaid: currentDepositPaid,
        status: isNowPaidInFull ? 'Confirmed' : 'Deposit Paid',
        paymentSchedule: updatedSchedule,
        internalNotes: [
          ...(existingBooking.internalNotes || []),
          `WiPay installment payment of $${depositAmount.toLocaleString()} JMD verified on ${now.toLocaleString()}. Txn: ${generatedTxn}. New total paid: $${currentDepositPaid.toLocaleString()} JMD.`,
        ],
        updatedAt: now.toISOString(),
      } : {
        id: `booking-${Date.now()}`,
        referenceNumber: targetRef,
        tripId: existingOrder?.tripOrDestination || 'trip',
        tripName: existingOrder?.tripOrDestination || tripTitle,
        customerName: existingOrder?.customerName || bookingData.customerName || 'Valued Traveler',
        email: existingOrder?.email || bookingData.email || 'traveler@smeltravels876.com',
        phone: existingOrder?.phone || bookingData.phone || '(876) 834-1537',
        countryOrParish: existingOrder?.parishOrCountry || 'Jamaica',
        adultsCount: existingOrder?.adultsCount || 1,
        childrenCount: existingOrder?.childrenCount || 0,
        preferredTravelDate: existingOrder?.travelDates || 'Flexible',
        travelInterestType: 'ready_to_book',
        status: isNowPaidInFull ? 'Confirmed' : 'Deposit Paid',
        depositPaid: currentDepositPaid,
        totalPrice: total,
        currency: 'JMD',
        paymentSchedule: updatedSchedule,
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
      };

      setBookings(prev => {
        const idx = prev.findIndex(b => b.referenceNumber === targetRef || b.id === targetRef);
        const updated = idx >= 0 ? prev.map((b, i) => i === idx ? returnedBooking : b) : [returnedBooking, ...prev];
        syncToLiveServer({ bookings: updated });
        return updated;
      });

      // Update Excel orders
      if (existingOrder) {
        setAdminOrdersExcel(prev => {
          const updated = prev.map(o => o.id === existingOrder.id ? {
            ...o,
            depositPaid: currentDepositPaid,
            paymentStatus: isNowPaidInFull ? 'Paid in Full' : 'Deposit Paid',
            orderStatus: isNowPaidInFull ? 'Confirmed' : o.orderStatus,
            paymentSchedule: updatedSchedule,
            adminNotes: `${o.adminNotes || ''} | Installment of $${depositAmount.toLocaleString()} JMD paid via WiPay on ${now.toLocaleString()} (Txn: ${generatedTxn}).`,
            lastUpdated: now.toISOString(),
          } : o);
          syncToLiveServer({ adminOrdersExcel: updated });
          return updated;
        });
      }

      // Record deposit for traveler
      const depositRecord: TravelerDepositRecord = {
        id: `dep-${Date.now()}`,
        tripId: returnedBooking.tripId,
        tripName: returnedBooking.tripName,
        amount: depositAmount,
        currency: 'JMD',
        date: now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        bookingRef: targetRef,
        paymentMethod: 'WiPay Jamaica Live Gateway',
        transactionId: generatedTxn,
        status: 'Confirmed',
      };
      if (currentUser) {
        recordUserDeposit(depositRecord, currentUser.email);
      } else if (returnedBooking.email) {
        recordUserDeposit(depositRecord, returnedBooking.email);
      }

      // Admin inbox alert
      addInboxItem({
        type: 'deposit',
        title: `🟢 [WiPay Installment Received] $${depositAmount.toLocaleString()} JMD for ${tripTitle}`,
        senderName: returnedBooking.customerName,
        senderEmail: returnedBooking.email,
        senderPhone: returnedBooking.phone,
        summary: `Traveler ${returnedBooking.customerName} paid installment of $${depositAmount.toLocaleString()} JMD via WiPay for ${tripTitle}. Ref: ${targetRef}. Total Paid: $${currentDepositPaid.toLocaleString()} JMD. Txn: ${generatedTxn}.`,
        details: `WIPAY INSTALLMENT DETAILS:\nReference: ${targetRef}\nInstallment Paid: $${depositAmount.toLocaleString()} JMD\nTotal Package: $${total.toLocaleString()} JMD\nTotal Paid to Date: $${currentDepositPaid.toLocaleString()} JMD\nBalance Remaining: $${newRemaining.toLocaleString()} JMD\nStatus: ${isNowPaidInFull ? 'Paid in Full' : 'Deposit Paid'}\nTxn: ${generatedTxn}`,
        tripName: tripTitle,
        referenceNumber: targetRef,
        adminRecipients: ['Elvoy Bennett', 'Zachary Buchanan'],
        recipientEmails: ['zbuchanan.smeltravels@gmail.com', 'smeltravels876@gmail.com'],
        emailStatus: 'Delivered',
      });

      return returnedBooking;
    }

    // Initial Installment Time Frame - created ONLY after the initial deposit is made!
    let initialSchedule: PaymentSchedule | undefined = undefined;
    if (remainingBalance > 0) {
      const dueDate1 = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      const dueDate2 = new Date(now.getTime() + 60 * 24 * 60 * 60 * 1000);
      const part1 = Math.round(remainingBalance / 2);
      const part2 = remainingBalance - part1;

      initialSchedule = {
        totalPrice: totalPkgPrice,
        depositPaid: depositAmount,
        initialDepositDate: now.toISOString(),
        initialTransactionId: generatedTxn,
        remainingBalance,
        currency: 'JMD',
        configuredByAdmin: 'Executive Operations Desk (Pending Admin Deadlines Setup)',
        lastConfiguredAt: now.toISOString(),
        installments: [
          {
            id: `inst-${Date.now()}-1`,
            installmentNumber: 1,
            label: 'Installment #1 (Midway Milestone)',
            amount: part1,
            dueDate: dueDate1.toISOString().split('T')[0],
            status: 'Pending',
          },
          {
            id: `inst-${Date.now()}-2`,
            installmentNumber: 2,
            label: 'Installment #2 (Final Balance Payment)',
            amount: part2,
            dueDate: dueDate2.toISOString().split('T')[0],
            status: 'Pending',
          },
        ],
      };
    }

    const newBooking: BookingSubmission = {
      id: `booking-wipay-${Date.now()}`,
      referenceNumber: ref,
      tripId: bookingData.tripId || `trip-${Date.now()}`,
      tripName: tripTitle,
      customerName: (bookingData.customerName || currentUser?.name || 'Valued Traveler').trim(),
      email: (bookingData.email || currentUser?.email || 'booking@smeltravels876.com').trim(),
      phone: (bookingData.phone || currentUser?.phone || '(876) 834-1537').trim(),
      countryOrParish: bookingData.countryOrParish || 'Jamaica',
      adultsCount: bookingData.adultsCount || 1,
      childrenCount: bookingData.childrenCount || 0,
      preferredTravelDate: bookingData.preferredTravelDate || 'Flexible',
      travelInterestType: 'ready_to_book',
      specialRequests: bookingData.specialRequests || `Live WiPay Deposit of $${depositAmount.toLocaleString()} JMD paid online`,
      preferredContactMethod: bookingData.preferredContactMethod || 'whatsapp',
      status: 'Deposit Paid',
      depositPaid: depositAmount,
      totalPrice: totalPkgPrice,
      currency: 'JMD',
      ambassadorName: bookingData.ambassadorName || 'Executive Operations Desk',
      internalNotes: [`WiPay Jamaica live payment confirmed on ${now.toLocaleString()}. Txn: ${generatedTxn}.`],
      paymentSchedule: initialSchedule,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    setBookings(prev => {
      const updated = [newBooking, ...prev];
      syncToLiveServer({ bookings: updated });
      return updated;
    });

    // Automatically add to Excel database
    const excelOrder: AdminOrderExcelRecord = {
      id: `order-wipay-${Date.now()}`,
      orderRef: ref,
      receivedAt: now.toISOString(),
      orderType: 'Deposit Record',
      customerName: newBooking.customerName,
      email: newBooking.email,
      phone: newBooking.phone || '',
      parishOrCountry: newBooking.countryOrParish || 'Jamaica',
      tripOrDestination: newBooking.tripName,
      travelDates: newBooking.preferredTravelDate || '2026/2027 Season',
      adultsCount: newBooking.adultsCount || 1,
      childrenCount: newBooking.childrenCount || 0,
      budget: `${formatPriceJMD(newBooking.totalPrice)} (Package Total)`,
      totalPrice: newBooking.totalPrice,
      depositPaid: depositAmount,
      currency: 'JMD',
      paymentStatus: 'Deposit Paid',
      orderStatus: 'Confirmed',
      preferredContact: 'WhatsApp',
      assignedAdmin: 'Zachary Buchanan',
      specialRequests: newBooking.specialRequests,
      inclusions: 'Flights, Hotel, Airport Transfers, 2 Excursions',
      adminNotes: `Live WiPay deposit verified on ${now.toLocaleString()}. Txn: ${generatedTxn}.`,
      paymentSchedule: initialSchedule,
      lastUpdated: now.toISOString(),
    };
    setAdminOrdersExcel(prev => {
      const updated = [excelOrder, ...prev];
      syncToLiveServer({ adminOrdersExcel: updated });
      return updated;
    });

    // Create deposit record
    const depositRecord: TravelerDepositRecord = {
      id: `dep-${Date.now()}`,
      tripId: newBooking.tripId,
      tripName: tripTitle,
      amount: depositAmount,
      currency: 'JMD',
      date: now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      bookingRef: ref,
      paymentMethod: 'WiPay Jamaica Live Gateway',
      transactionId: generatedTxn,
      status: 'Confirmed',
    };

    if (currentUser) {
      recordUserDeposit(depositRecord, currentUser.email);
    } else if (newBooking.email) {
      recordUserDeposit(depositRecord, newBooking.email);
    }

    // Add to Admin Inbox for Elvoy & Zachary
    addInboxItem({
      type: 'deposit',
      title: `🟢 [WiPay Deposit Paid] $${depositAmount.toLocaleString()} JMD for ${tripTitle}`,
      senderName: newBooking.customerName,
      senderEmail: newBooking.email,
      senderPhone: newBooking.phone,
      summary: `Traveler ${newBooking.customerName} completed WiPay Jamaica deposit of $${depositAmount.toLocaleString()} JMD for ${tripTitle}. Ref: ${ref}. Txn: ${generatedTxn}.`,
      details: `WIPAY CONFIRMED BOOKING:\nTrip: ${tripTitle}\nDeposit Paid: $${depositAmount.toLocaleString()} JMD\nTotal Package: $${newBooking.totalPrice.toLocaleString()} JMD\nReference: ${ref}\nWiPay Txn: ${generatedTxn}\nTraveler: ${newBooking.customerName}\nEmail: ${newBooking.email}\nPhone: ${newBooking.phone}\nParish: ${newBooking.countryOrParish}\nPreferred Travel Dates: ${newBooking.preferredTravelDate}`,
      tripName: tripTitle,
      referenceNumber: ref,
      adminRecipients: ['Elvoy Bennett', 'Zachary Buchanan'],
      recipientEmails: ['zbuchanan.smeltravels@gmail.com', 'smeltravels876@gmail.com'],
      emailStatus: 'Delivered',
    });

    // Update Customer profile
    setCustomers(prev => {
      const existing = prev.find(c => c.email.toLowerCase() === newBooking.email.toLowerCase());
      let updatedCustomers: CustomerRecord[];
      if (existing) {
        updatedCustomers = prev.map(c =>
          c.id === existing.id
            ? {
                ...c,
                tripsOfInterest: Array.from(new Set([...c.tripsOfInterest, tripTitle])),
                bookingCount: c.bookingCount + 1,
                totalSpent: (c.totalSpent || 0) + depositAmount,
                status: 'Active Traveler',
              }
            : c
        );
      } else {
        const newCustomer: CustomerRecord = {
          id: `cust-${Date.now()}`,
          name: newBooking.customerName,
          email: newBooking.email,
          phone: newBooking.phone,
          countryOrParish: newBooking.countryOrParish,
          tripsOfInterest: [tripTitle],
          bookingCount: 1,
          inquiryCount: 0,
          totalSpent: depositAmount,
          notes: [`WiPay deposit confirmed for ${tripTitle} with reference ${ref}`],
          status: 'Active Traveler',
          communicationPreference: 'whatsapp',
          createdAt: now.toISOString().split('T')[0],
        };
        updatedCustomers = [newCustomer, ...prev];
      }
      syncToLiveServer({ customers: updatedCustomers });
      return updatedCustomers;
    });

    // Set confirmation details for clean confirmation view
    setConfirmedBookingDetails({
      referenceNumber: ref,
      tripTitle,
      depositPaid: depositAmount,
      totalPrice: newBooking.totalPrice,
      currency: 'JMD',
      customerName: newBooking.customerName,
      email: newBooking.email,
      phone: newBooking.phone,
      paymentMethod: 'WiPay Jamaica Verified Checkout',
      transactionId: generatedTxn,
      date: now.toLocaleString(),
    });

    // Automated Resend Transactional Email Dispatch for confirmed WiPay deposit (bookings@smeltravels876.com)
    try {
      // 1. Customer Confirmation with verified deposit receipt
      fetch('/api/resend/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'booking_customer',
          to: newBooking.email,
          sender: 'SMELTRAVELS876 Bookings <bookings@smeltravels876.com>',
          data: {
            referenceNumber: ref,
            customerName: newBooking.customerName,
            email: newBooking.email,
            phone: newBooking.phone,
            tripName: tripTitle,
            preferredTravelDate: newBooking.preferredTravelDate,
            adultsCount: newBooking.adultsCount,
            childrenCount: newBooking.childrenCount,
            totalPrice: newBooking.totalPrice,
            depositPaid: depositAmount,
            paymentMethod: 'WiPay Jamaica Verified Checkout',
            transactionId: generatedTxn,
            ambassadorName: newBooking.ambassadorName,
          },
        }),
      }).catch((e) => console.warn('[WiPay Customer Resend Notice]:', e));

      // 2. Admin Alert for confirmed WiPay deposit
      fetch('/api/resend/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'booking_admin',
          to: ['zbuchanan.smeltravels@gmail.com', 'smeltravels876@gmail.com', 'zacpremacc12@gmail.com'],
          sender: 'SMELTRAVELS876 Bookings <bookings@smeltravels876.com>',
          data: {
            referenceNumber: ref,
            customerName: newBooking.customerName,
            email: newBooking.email,
            phone: newBooking.phone,
            countryOrParish: newBooking.countryOrParish,
            tripName: tripTitle,
            totalPrice: newBooking.totalPrice,
            depositPaid: depositAmount,
            paymentMethod: 'WiPay Jamaica Verified Checkout',
            transactionId: generatedTxn,
            ambassadorName: newBooking.ambassadorName,
          },
        }),
      }).catch((e) => console.warn('[WiPay Admin Resend Notice]:', e));
    } catch (e) {}

    return newBooking;
  };

  const updateBookingStatus = (id: string, status: BookingSubmission['status'], note?: string) => {
    const now = new Date().toISOString();
    setBookings(prev =>
      prev.map(b => {
        if (b.id !== id) return b;
        const newNotes = note
          ? [...b.internalNotes, `[${new Date().toLocaleDateString()}] Status updated to "${status}": ${note}`]
          : [...b.internalNotes, `[${new Date().toLocaleDateString()}] Status updated to "${status}"`];
        return {
          ...b,
          status,
          internalNotes: newNotes,
          updatedAt: now,
        };
      })
    );
    showNotification('Booking Updated', `Reference status updated to "${status}".`);
  };

  const updateBookingPayment = (id: string, depositPaid: number, note?: string) => {
    const now = new Date().toISOString();
    setBookings(prev =>
      prev.map(b => {
        if (b.id !== id) return b;
        const noteText = `Payment record updated: $${depositPaid.toLocaleString()} JMD recorded. ${note || ''}`;
        return {
          ...b,
          depositPaid,
          status: depositPaid >= b.depositPaid && depositPaid > 0 ? 'Deposit Received' : b.status,
          internalNotes: [...b.internalNotes, `[${new Date().toLocaleDateString()}] ${noteText}`],
          updatedAt: now,
        };
      })
    );
    showNotification('Payment Recorded', `Updated deposit payments for booking.`);
  };

  const addBookingNote = (id: string, note: string) => {
    setBookings(prev =>
      prev.map(b => (b.id === id ? { ...b, internalNotes: [...b.internalNotes, note] } : b))
    );
  };

  // Traveler Inquiry Management (Available to both guests and logged-in users)
  const updateUserInquiry = (
    refOrId: string,
    updates: {
      travelDates?: string;
      adultsCount?: number;
      childrenCount?: number;
      specialRequests?: string;
      phone?: string;
      customerMessage?: string;
    }
  ): boolean => {
    const now = new Date().toISOString();
    let found = false;
    let customerName = 'Traveler';
    let reference = refOrId;

    setBookings((prev) => {
      const idx = prev.findIndex(
        (b) => b.referenceNumber?.toLowerCase() === refOrId.toLowerCase() || b.id === refOrId
      );
      if (idx === -1) return prev;
      found = true;
      const b = prev[idx];
      customerName = b.customerName;
      reference = b.referenceNumber;

      const changeSummary: string[] = [];
      if (updates.travelDates && updates.travelDates !== b.preferredTravelDate) {
        changeSummary.push(`Dates -> "${updates.travelDates}"`);
      }
      if (updates.adultsCount !== undefined && updates.adultsCount !== b.adultsCount) {
        changeSummary.push(`Adults -> ${updates.adultsCount}`);
      }
      if (updates.childrenCount !== undefined && updates.childrenCount !== b.childrenCount) {
        changeSummary.push(`Children -> ${updates.childrenCount}`);
      }
      if (updates.phone && updates.phone !== b.phone) {
        changeSummary.push(`Phone -> ${updates.phone}`);
      }
      if (updates.specialRequests && updates.specialRequests !== b.specialRequests) {
        changeSummary.push(`Requests updated: "${updates.specialRequests}"`);
      }
      if (updates.customerMessage) {
        changeSummary.push(`Client Message: "${updates.customerMessage}"`);
      }

      const noteText = `[${new Date().toLocaleDateString()}] Client Modified Inquiry: ${changeSummary.join('; ')}`;
      const updatedItem: BookingSubmission = {
        ...b,
        preferredTravelDate: updates.travelDates || b.preferredTravelDate,
        adultsCount: updates.adultsCount !== undefined ? updates.adultsCount : b.adultsCount,
        childrenCount: updates.childrenCount !== undefined ? updates.childrenCount : b.childrenCount,
        phone: updates.phone || b.phone,
        specialRequests: updates.specialRequests || b.specialRequests,
        internalNotes: [...(b.internalNotes || []), noteText],
        updatedAt: now,
      };

      const updated = [...prev];
      updated[idx] = updatedItem;
      syncToLiveServer({ bookings: updated });
      return updated;
    });

    // Also update in adminOrdersExcel if exists
    setAdminOrdersExcel((prev) => {
      let modified = false;
      const updated = prev.map((o) => {
        if (o.orderRef?.toLowerCase() === refOrId.toLowerCase() || o.id === refOrId) {
          modified = true;
          return {
            ...o,
            travelDates: updates.travelDates || o.travelDates,
            adultsCount: updates.adultsCount !== undefined ? updates.adultsCount : o.adultsCount,
            childrenCount: updates.childrenCount !== undefined ? updates.childrenCount : o.childrenCount,
            phone: updates.phone || o.phone,
            specialRequests: updates.specialRequests || o.specialRequests,
            adminNotes: `${o.adminNotes ? `${o.adminNotes}\n` : ''}[${new Date().toLocaleDateString()}] Client modified inquiry details via tracker.`,
            lastUpdated: now,
          };
        }
        return o;
      });
      if (modified) {
        syncToLiveServer({ adminOrdersExcel: updated });
      }
      return updated;
    });

    // Notify Admin Inbox with an alert so staff know client made changes
    addInboxItem({
      type: 'inquiry',
      title: `Client Modified Inquiry: ${reference} (${customerName})`,
      senderName: customerName,
      senderEmail: 'client-portal@smeltravels876.com',
      senderPhone: updates.phone || '',
      summary: `Traveler updated their inquiry details online. Dates: ${updates.travelDates || 'Unchanged'}, Guests: ${updates.adultsCount || 'N/A'}.`,
      details: `Traveler self-service change for ${reference}:\nDates: ${updates.travelDates || 'Unchanged'}\nAdults: ${updates.adultsCount ?? 'Unchanged'}, Children: ${updates.childrenCount ?? 'Unchanged'}\nPhone: ${updates.phone || 'Unchanged'}\nRequests: ${updates.specialRequests || 'None'}\nMessage from Client: ${updates.customerMessage || 'None'}`,
      referenceNumber: reference,
    });

    showNotification('Inquiry Updated', `Your changes for ${reference} were saved successfully!`, 'success');
    return found;
  };

  const submitInquiryDeposit = (
    refOrId: string,
    amount: number,
    paymentMethod: string,
    transactionRef?: string,
    proofNotes?: string
  ): boolean => {
    const now = new Date().toISOString();
    let found = false;
    let customerName = 'Traveler';
    let customerEmail = '';
    let tripName = 'Travel Experience';
    let reference = refOrId;

    setBookings((prev) => {
      const idx = prev.findIndex(
        (b) => b.referenceNumber?.toLowerCase() === refOrId.toLowerCase() || b.id === refOrId
      );
      if (idx === -1) return prev;
      found = true;
      const b = prev[idx];
      customerName = b.customerName;
      customerEmail = b.email;
      tripName = b.tripName;
      reference = b.referenceNumber;

      const newDepositPaid = (b.depositPaid || 0) + amount;
      const noteText = `[${new Date().toLocaleDateString()}] Online Deposit of $${amount.toLocaleString()} JMD recorded via ${paymentMethod}. Ref: ${transactionRef || 'Direct Transfer'}. Note: ${proofNotes || 'None'}`;
      const updatedItem: BookingSubmission = {
        ...b,
        depositPaid: newDepositPaid,
        status: 'Deposit Received',
        internalNotes: [...(b.internalNotes || []), noteText],
        updatedAt: now,
      };

      const updated = [...prev];
      updated[idx] = updatedItem;
      syncToLiveServer({ bookings: updated });
      return updated;
    });

    // Also update in adminOrdersExcel
    setAdminOrdersExcel((prev) => {
      let modified = false;
      const updated = prev.map((o) => {
        if (o.orderRef?.toLowerCase() === refOrId.toLowerCase() || o.id === refOrId) {
          modified = true;
          const newDeposit = (o.depositPaid || 0) + amount;
          const isPaidInFull = o.totalPrice > 0 && newDeposit >= o.totalPrice;
          return {
            ...o,
            depositPaid: newDeposit,
            paymentStatus: isPaidInFull ? 'Paid in Full' : 'Deposit Paid',
            orderStatus: 'Deposit Received',
            adminNotes: `${o.adminNotes ? `${o.adminNotes}\n` : ''}[${new Date().toLocaleDateString()}] Deposit of $${amount.toLocaleString()} JMD received via ${paymentMethod}.`,
            lastUpdated: now,
          };
        }
        return o;
      });
      if (modified) {
        syncToLiveServer({ adminOrdersExcel: updated });
      }
      return updated;
    });

    // Record user deposit if traveler profile matches
    if (currentUser && customerEmail && currentUser.email?.toLowerCase() === customerEmail.toLowerCase()) {
      recordUserDeposit({
        id: `dep-${Date.now()}`,
        tripId: 'inquiry-trip',
        tripName,
        amount,
        currency: 'JMD',
        date: now,
        bookingRef: reference,
        paymentMethod,
        transactionId: transactionRef || `TXN-${Date.now()}`,
        status: 'Pending Review',
      });
    }

    // Send high-priority Deposit notification to Admin Inbox!
    addInboxItem({
      type: 'deposit',
      title: `Deposit Received: $${amount.toLocaleString()} JMD for ${tripName}`,
      senderName: customerName,
      senderEmail: customerEmail,
      summary: `Traveler deposited $${amount.toLocaleString()} JMD for ${reference} via ${paymentMethod}.`,
      details: `DEPOSIT SUBMISSION:\nReference: ${reference}\nTrip: ${tripName}\nAmount: $${amount.toLocaleString()} JMD\nMethod: ${paymentMethod}\nTransaction Ref: ${transactionRef || 'Direct Transfer'}\nNotes: ${proofNotes || 'None'}\nTimestamp: ${now}`,
      amount,
      currency: 'JMD',
      tripName,
      referenceNumber: reference,
    });

    showNotification(
      'Deposit Confirmed!',
      `Thank you, ${customerName}! Deposit of $${amount.toLocaleString()} JMD received for ${reference}. Spot secured!`,
      'success'
    );
    return true;
  };

  // Contacts
  const submitContactForm = (subData: Omit<ContactSubmission, 'id' | 'referenceNumber' | 'createdAt' | 'status'>): string => {
    const ref = `INQ-${Math.floor(10000 + Math.random() * 90000)}`;
    const newContact: ContactSubmission = {
      ...subData,
      id: `contact-${Date.now()}`,
      referenceNumber: ref,
      status: 'New',
      createdAt: new Date().toISOString(),
    };
    setContactSubmissions(prev => {
      const updated = [newContact, ...prev];
      syncToLiveServer({ contacts: updated });
      return updated;
    });

    // Notify Admin Inbox: Message!
    addInboxItem({
      type: 'message',
      title: `New Contact Message: ${subData.subject || 'Website Inquiry'}`,
      senderName: subData.name,
      senderEmail: subData.email,
      senderPhone: subData.phone,
      summary: `Inquiry from ${subData.name}: "${(subData.message || '').slice(0, 100)}..."`,
      details: subData.message,
      referenceNumber: ref,
    });

    return ref;
  };

  // Customers
  const addCustomerNote = (id: string, note: string) => {
    setCustomers(prev => {
      const updated = prev.map(c => (c.id === id ? { ...c, notes: [...c.notes, note] } : c));
      syncToLiveServer({ customers: updated });
      return updated;
    });
  };

  // Blog
  const addBlogPost = (postData: Omit<BlogPost, 'id'>) => {
    const newPost: BlogPost = { ...postData, id: `blog-${Date.now()}` };
    setBlogPosts(prev => {
      const updated = [newPost, ...prev];
      syncToLiveServer({ blog: updated });
      return updated;
    });
    showNotification('Article Published', `"${newPost.title}" was saved.`);
  };

  const updateBlogPost = (id: string, postData: Partial<BlogPost>) => {
    setBlogPosts(prev => {
      const updated = prev.map(p => (p.id === id ? { ...p, ...postData } : p));
      syncToLiveServer({ blog: updated });
      return updated;
    });
    showNotification('Article Updated', 'Travel guide updated.');
  };

  const deleteBlogPost = (id: string) => {
    setBlogPosts(prev => {
      const updated = prev.filter(p => p.id !== id);
      syncToLiveServer({ blog: updated });
      return updated;
    });
    showNotification('Article Deleted', 'Post removed.', 'warning');
  };

  // Offers
  const addOffer = (offerData: Omit<OfferItem, 'id'>) => {
    const newOffer: OfferItem = { ...offerData, id: `offer-${Date.now()}` };
    setOffers(prev => {
      const updated = [newOffer, ...prev];
      syncToLiveServer({ offers: updated });
      return updated;
    });
    showNotification('Offer Created', 'New promotion was published.');
  };

  const updateOffer = (id: string, offerData: Partial<OfferItem>) => {
    setOffers(prev => {
      const updated = prev.map(o => (o.id === id ? { ...o, ...offerData } : o));
      syncToLiveServer({ offers: updated });
      return updated;
    });
    showNotification('Offer Updated', 'Promotion updated.');
  };

  const deleteOffer = (id: string) => {
    setOffers(prev => {
      const updated = prev.filter(o => o.id !== id);
      syncToLiveServer({ offers: updated });
      return updated;
    });
    showNotification('Offer Deleted', 'Promotion removed.', 'warning');
  };

  // Testimonials
  const addTestimonial = (testData: Omit<TestimonialItem, 'id'>) => {
    const newTest: TestimonialItem = { ...testData, id: `test-${Date.now()}` };
    setTestimonials(prev => {
      const updated = [newTest, ...prev];
      syncToLiveServer({ testimonials: updated });
      return updated;
    });

    // Notify Admin Inbox: Review!
    addInboxItem({
      type: 'review',
      title: `New Review: ${newTest.rating} Stars from ${newTest.customerName}`,
      senderName: newTest.customerName,
      summary: `Traveler rating: ${newTest.rating}★ for ${newTest.tripName}. "${newTest.reviewText.slice(0, 100)}..."`,
      details: newTest.reviewText,
      rating: newTest.rating,
      tripName: newTest.tripName,
    });

    showNotification('Testimonial Added', 'Customer review saved.');
  };

  const updateTestimonial = (id: string, testData: Partial<TestimonialItem>) => {
    if (!isAdminLoggedIn) {
      showNotification('Action Denied', 'Traveler reviews cannot be modified or edited by users.', 'warning');
      return;
    }
    setTestimonials(prev => {
      const updated = prev.map(t => (t.id === id ? { ...t, ...testData } : t));
      syncToLiveServer({ testimonials: updated });
      return updated;
    });
    showNotification('Testimonial Updated', 'Review details updated.');
  };

  const deleteTestimonial = (id: string) => {
    setTestimonials(prev => {
      const updated = prev.filter(t => t.id !== id);
      syncToLiveServer({ testimonials: updated });
      return updated;
    });
    showNotification('Testimonial Deleted', 'Review removed.', 'warning');
  };

  // FAQs
  const addFaq = (faqData: Omit<FAQItem, 'id'>) => {
    const newFaq: FAQItem = { ...faqData, id: `faq-${Date.now()}` };
    setFaqs(prev => {
      const updated = [...prev, newFaq];
      syncToLiveServer({ faqs: updated });
      return updated;
    });
    showNotification('FAQ Added', 'Question and answer published.');
  };

  const updateFaq = (id: string, faqData: Partial<FAQItem>) => {
    setFaqs(prev => {
      const updated = prev.map(f => (f.id === id ? { ...f, ...faqData } : f));
      syncToLiveServer({ faqs: updated });
      return updated;
    });
    showNotification('FAQ Updated', 'FAQ item updated.');
  };

  const deleteFaq = (id: string) => {
    setFaqs(prev => {
      const updated = prev.filter(f => f.id !== id);
      syncToLiveServer({ faqs: updated });
      return updated;
    });
    showNotification('FAQ Deleted', 'FAQ removed.', 'warning');
  };

  // Media
  const addMediaItem = (itemData: Omit<MediaItem, 'id' | 'uploadedAt'>) => {
    const newItem: MediaItem = {
      ...itemData,
      id: `media-${Date.now()}`,
      uploadedAt: new Date().toISOString().split('T')[0],
    };
    setMediaList(prev => {
      const updated = [newItem, ...prev];
      syncToLiveServer({ media: updated });
      return updated;
    });
    showNotification('Media Uploaded', 'Image added to media library.');
  };

  const deleteMediaItem = (id: string) => {
    setMediaList(prev => {
      const updated = prev.filter(m => m.id !== id);
      syncToLiveServer({ media: updated });
      return updated;
    });
  };

  // Newsletter
  const subscribeNewsletter = (firstName: string, email: string): boolean => {
    const existing = subscribers.find(s => s.email.toLowerCase() === email.toLowerCase());
    if (existing) return false;
    const newSub: NewsletterSubscriber = {
      id: `sub-${Date.now()}`,
      firstName,
      email,
      subscribedAt: new Date().toISOString().split('T')[0],
      isActive: true,
      source: 'Website Newsletter Form'
    };
    setSubscribers(prev => [newSub, ...prev]);
    return true;
  };

  const unsubscribeNewsletter = (email: string) => {
    setSubscribers(prev => prev.map(s => (s.email.toLowerCase() === email.toLowerCase() ? { ...s, isActive: false } : s)));
    showNotification('Unsubscribed', `${email} has been unsubscribed from travel updates.`, 'info');
  };

  // Authoritative Administrator Identity Profiles (Passwords are strictly checked and verified on server.ts)
  const REQUIRED_ADMIN_EMAIL = 'smeltravels876@gmail.com';
  const ADMIN_AUTHORIZED_EMAILS = [
    'smeltravels876@gmail.com',
    'zbuchanan.smeltravels@gmail.com',
    'jvirgo.smeltravels@gmail.com',
    'sdavis.smeltravels@gmail.com',
    'zacpremacc12@gmail.com',
  ];

  const ADMIN_PROFILES: Record<string, { name: string; title: string; phone: string; role: AdminRole }> = {
    'smeltravels876@gmail.com': {
      name: 'Elvoy Bennett',
      title: 'CEO | SMELTRAVELS876',
      phone: '(876) 834-1537',
      role: 'Super Admin',
    },
    'zbuchanan.smeltravels@gmail.com': {
      name: 'Zachary Buchanan',
      title: 'Travel Ambassador',
      phone: '(876) 848-9772',
      role: 'Super Admin',
    },
    'jvirgo.smeltravels@gmail.com': {
      name: 'Jada Virgo',
      title: 'Travel Ambassador',
      phone: '(876) 566-6923',
      role: 'Super Admin',
    },
    'sdavis.smeltravels@gmail.com': {
      name: 'Shenoya Davis',
      title: 'Travel Ambassador',
      phone: '(876) 276-1310',
      role: 'Super Admin',
    },
    'zacpremacc12@gmail.com': {
      name: 'Zachary Buchanan',
      title: 'Travel Ambassador / Lead Admin',
      phone: '(876) 848-9772',
      role: 'Super Admin',
    },
  };

  // Keep Admin and User in sync: If admin is logged in, ensure currentUser reflects this
  useEffect(() => {
    if (isAdminLoggedIn) {
      const activeAdminProfile = (adminEmail && ADMIN_PROFILES[adminEmail.toLowerCase()]) || {
        name: adminEmail === 'smeltravels876@gmail.com' ? 'SMEL Travels 876 Admin' : 'Zachary Buchanan',
        title: 'Executive Travel Operations & CMS Director',
        phone: '(876) 848-9772',
        role: (currentAdminRole || 'Super Admin') as AdminRole,
      };

      setCurrentUser(prev => {
        if (!prev) {
          return {
            id: `admin-user-${(adminEmail || REQUIRED_ADMIN_EMAIL).replace(/[^a-z0-9]/gi, '-')}`,
            name: activeAdminProfile.name,
            email: adminEmail || REQUIRED_ADMIN_EMAIL,
            phone: activeAdminProfile.phone,
            homeParishOrCountry: 'Kingston, Jamaica',
            memberSince: '2026',
            isAdmin: true,
            adminRole: currentAdminRole || 'Super Admin',
          };
        } else if (!prev.isAdmin || prev.email !== (adminEmail || REQUIRED_ADMIN_EMAIL)) {
          return {
            ...prev,
            name: activeAdminProfile.name,
            email: adminEmail || REQUIRED_ADMIN_EMAIL,
            isAdmin: true,
            adminRole: currentAdminRole || 'Super Admin',
          };
        }
        return prev;
      });
    }
  }, [isAdminLoggedIn, adminEmail, currentAdminRole]);

  const loginAdmin = (role: AdminRole = 'Super Admin') => {
    const profile = ADMIN_PROFILES[REQUIRED_ADMIN_EMAIL] || {
      name: 'SMEL Travels 876 Admin',
      title: 'Executive Travel Operations',
      phone: '(876) 848-9772',
      role: 'Super Admin',
    };
    setIsAdminLoggedIn(true);
    setAdminEmail(REQUIRED_ADMIN_EMAIL);
    setCurrentAdminRole(role);
    setCurrentUser(prev => ({
      id: prev?.id || 'admin-user-smeltravels876',
      name: profile.name,
      email: REQUIRED_ADMIN_EMAIL,
      phone: profile.phone,
      homeParishOrCountry: prev?.homeParishOrCountry || 'Kingston, Jamaica',
      memberSince: prev?.memberSince || '2026',
      firstDeposit: prev?.firstDeposit,
      deposits: prev?.deposits,
      isAdmin: true,
      adminRole: role,
    }));
    showNotification('Admin Authenticated', `Signed in to SMELTRAVELS876 as ${role}.`);
  };

  const loginAdminWithCredentials = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanPassword = (password || '').trim();

    try {
      let result = await safeFetchJson<{
        success: boolean;
        token?: string;
        admin?: any;
        error?: string;
        isHostingerFallback?: boolean;
      }>('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, password: cleanPassword }),
      });

      // If Hostinger reverse proxy is waking up the Node.js process (cold start 502/503/504), retry once
      if (!result.ok && (result.status === 502 || result.status === 503 || result.status === 504 || result.status === 0)) {
        await new Promise((r) => setTimeout(r, 1200));
        result = await safeFetchJson<{
          success: boolean;
          token?: string;
          admin?: any;
          error?: string;
          isHostingerFallback?: boolean;
        }>('/api/admin/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: cleanEmail, password: cleanPassword }),
        });
      }

      if (!result.ok || !result.data?.success) {
        const errorMsg =
          result.data?.error ||
          result.error ||
          'Invalid administrator email or password. Please verify your credentials.';
        showNotification('Access Denied', errorMsg, 'warning');
        return {
          success: false,
          error: errorMsg,
        };
      }

      const token = result.data.token!;
      const adminInfo = result.data.admin;

      setAdminSessionToken(token);
      try {
        sessionStorage.setItem('smeltravels_admin_token', token);
        localStorage.setItem('smeltravels_admin_token', token);
      } catch {}

      setIsAdminLoggedIn(true);
      setAdminEmail(adminInfo.email);
      setCurrentAdminRole((adminInfo.role || 'Super Admin') as AdminRole);

      setCurrentUser(prev => ({
        id: prev?.id || `admin-user-${adminInfo.email.replace(/[^a-z0-9]/gi, '-')}`,
        name: adminInfo.name,
        email: adminInfo.email,
        phone: adminInfo.phone,
        homeParishOrCountry: prev?.homeParishOrCountry || 'Kingston, Jamaica',
        memberSince: prev?.memberSince || '2026',
        firstDeposit: prev?.firstDeposit,
        deposits: prev?.deposits,
        isAdmin: true,
        adminRole: (adminInfo.role || 'Super Admin') as AdminRole,
      }));

      showNotification('Access Granted', `Welcome back, ${adminInfo.name} (${adminInfo.email}). Super Admin unlocked.`);

      // Immediately fetch authoritative admin records directly from server
      await fetchAdminRecords(token);

      return { success: true };
    } catch (err: any) {
      showNotification('Connection Error', 'Could not reach administration server.', 'warning');
      return { success: false, error: err.message || 'Connection error. Please try again.' };
    }
  };

  const logoutAdmin = async () => {
    try {
      if (adminSessionToken) {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${adminSessionToken}`,
          },
          body: JSON.stringify({ token: adminSessionToken }),
        });
      }
    } catch {}

    setAdminSessionToken(null);
    setIsAdminLoggedIn(false);
    setAdminEmail(null);
    try {
      sessionStorage.removeItem('smeltravels_admin_token');
      localStorage.removeItem('smeltravels_admin_token');
    } catch {}

    setAdminInbox([]);
    setBookings([]);
    setAdminOrdersExcel([]);
    setCustomers([]);

    setCurrentUser(prev => (prev?.isAdmin ? null : prev));
    showNotification('Admin Panel Locked', 'Safely signed out. Admin panel is password protected.', 'info');
  };

  // Traveler Auth & Account Methods
  const openAuthModal = (mode: 'login' | 'signup' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const loginUser = (email: string, name?: string, phone?: string): boolean => {
    const cleanEmail = email.trim().toLowerCase();
    const existingCustomer = customers.find(c => c.email.toLowerCase() === cleanEmail);
    const resolvedName = name?.trim() || (existingCustomer ? existingCustomer.name : cleanEmail.split('@')[0].replace(/[._]/g, ' '));
    const formattedName = resolvedName.charAt(0).toUpperCase() + resolvedName.slice(1);

    const isSpecialAdmin = ADMIN_AUTHORIZED_EMAILS.includes(cleanEmail) ||
      cleanEmail === REQUIRED_ADMIN_EMAIL.toLowerCase() ||
      cleanEmail.includes('smeltravels') ||
      (settings.ambassadors || []).some(a => a.email && a.email.toLowerCase() === cleanEmail);

    const user: TravelerUser = {
      id: existingCustomer ? existingCustomer.id : `traveler-${Date.now()}`,
      name: formattedName,
      email: cleanEmail,
      phone: phone || (existingCustomer ? existingCustomer.phone : ''),
      homeParishOrCountry: existingCustomer ? existingCustomer.countryOrParish : 'Jamaica',
      memberSince: new Date().getFullYear().toString(),
      isAdmin: isSpecialAdmin,
      adminRole: isSpecialAdmin ? 'Super Admin' : undefined,
    };

    if (isSpecialAdmin) {
      setIsAdminLoggedIn(true);
      setAdminEmail(cleanEmail);
      setCurrentAdminRole('Super Admin');
      showNotification('Admin Signed In', `Welcome back, Administrator ${user.name}! Administrative privileges active.`);
    } else {
      showNotification('Welcome Back!', `Signed in as ${user.name}`);
    }

    setCurrentUser(user);
    setIsAuthModalOpen(false);

    // Automated Resend Security Alert (notifications@smeltravels876.com)
    try {
      fetch('/api/resend/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'security_alert',
          to: cleanEmail,
          sender: 'SMELTRAVELS876 Security & Accounts <notifications@smeltravels876.com>',
          data: {
            customerName: user.name,
            email: cleanEmail,
            time: new Date().toLocaleString('en-US', { timeZone: 'America/Jamaica' }),
            device: typeof navigator !== 'undefined' ? `${navigator.userAgent.slice(0, 60)}...` : 'Traveler Portal',
          },
        }),
      }).catch((e) => console.warn('[loginUser Resend Notice]:', e));
    } catch (e) {}

    // If traveler was waiting to secure their spot, open booking modal now!
    if (pendingTripForBooking) {
      const tripToLock = pendingTripForBooking;
      setPendingTripForBooking(null);
      setAuthNotice(null);
      setTimeout(() => {
        setSelectedTripForBooking(tripToLock);
        showNotification('Spot Secured!', `Welcome back, ${user.name}! Finish reserving your spot for ${tripToLock.name}.`);
      }, 300);
    }

    return true;
  };

  const signupUser = (name: string, email: string, phone?: string, homeParishOrCountry?: string): boolean => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();
    const user: TravelerUser = {
      id: `traveler-${Date.now()}`,
      name: cleanName,
      email: cleanEmail,
      phone: phone?.trim() || '',
      homeParishOrCountry: homeParishOrCountry?.trim() || 'Jamaica',
      memberSince: new Date().getFullYear().toString(),
    };

    setCurrentUser(user);
    // Also record traveler in customer leads for agency
    setCustomers(prev => {
      if (prev.some(c => c.email.toLowerCase() === cleanEmail)) return prev;
      const newCustomer: CustomerRecord = {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone || '',
        countryOrParish: user.homeParishOrCountry || 'Jamaica',
        tripsOfInterest: ['Panama 2026', 'Antigua 2027'],
        bookingCount: 0,
        inquiryCount: 0,
        totalSpent: 0,
        notes: ['Registered via Web Portal.'],
        status: 'Active Traveler',
        communicationPreference: 'whatsapp',
        createdAt: new Date().toISOString(),
      };
      const updated = [newCustomer, ...prev];
      syncToLiveServer({ customers: updated });
      return updated;
    });

    // Automated Resend Welcome Email (notifications@smeltravels876.com)
    try {
      fetch('/api/resend/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'welcome_account',
          to: cleanEmail,
          sender: 'SMELTRAVELS876 Security & Accounts <notifications@smeltravels876.com>',
          data: {
            customerName: user.name,
            name: user.name,
            email: cleanEmail,
          },
        }),
      }).catch((e) => console.warn('[signupUser Resend Notice]:', e));
    } catch (e) {}

    setIsAuthModalOpen(false);
    showNotification('Account Created!', `Welcome to SMELTRAVELS876, ${user.name}!`);

    // If traveler was waiting to secure their spot, open booking modal now!
    if (pendingTripForBooking) {
      const tripToLock = pendingTripForBooking;
      setPendingTripForBooking(null);
      setAuthNotice(null);
      setTimeout(() => {
        setSelectedTripForBooking(tripToLock);
        showNotification('Spot Secured!', `Welcome, ${user.name}! Finish reserving your spot for ${tripToLock.name}.`);
      }, 300);
    }

    return true;
  };

  const logoutUser = () => {
    setCurrentUser(null);
    setIsAdminLoggedIn(false);
    setAdminEmail(null);
    showNotification('Signed Out', 'You have been safely signed out.');
  };

  const recordUserDeposit = (deposit: TravelerDepositRecord, userEmail?: string) => {
    const now = new Date();
    setCurrentUser(prev => {
      if (!prev) return null;
      const isFirst = !prev.firstDeposit;
      const prevDeposits = prev.deposits || [];
      const updatedUser: TravelerUser = {
        ...prev,
        firstDeposit: isFirst ? deposit : prev.firstDeposit,
        deposits: [deposit, ...prevDeposits],
      };
      setStoredItem('traveler_user', updatedUser);
      return updatedUser;
    });

    // Notify Admin Inbox: Deposit!
    addInboxItem({
      type: 'deposit',
      title: `Deposit Recorded: ${deposit.tripName} ($${deposit.amount.toLocaleString()} JMD)`,
      senderName: currentUser?.name || 'Verified Traveler',
      senderEmail: currentUser?.email || userEmail,
      senderPhone: currentUser?.phone,
      summary: `Deposit payment of $${deposit.amount.toLocaleString()} JMD recorded for ${deposit.tripName}. Method: ${deposit.paymentMethod}.`,
      details: `Booking Reference: ${deposit.bookingRef}. Status: Verified. Payment receipt verified by traveler.`,
      amount: deposit.amount,
      currency: 'JMD',
      tripName: deposit.tripName,
      referenceNumber: deposit.bookingRef,
    });

    // Also update in customers table
    const targetEmail = (currentUser?.email || userEmail || deposit.bookingRef).toLowerCase();
    setCustomers(prev => {
      const updated = prev.map(c => {
        if (c.email.toLowerCase() === targetEmail) {
          return {
            ...c,
            totalSpent: (c.totalSpent || 0) + deposit.amount,
            notes: [
              ...c.notes,
              `[${now.toLocaleDateString()}] Deposit recorded: $${deposit.amount.toLocaleString()} JMD for ${deposit.tripName} (Ref: ${deposit.bookingRef})`,
            ],
            status: 'Active Traveler',
          };
        }
        return c;
      });
      syncToLiveServer({ customers: updated });
      return updated;
    });

    // Also update or insert in Excel Database
    setAdminOrdersExcel(prev => {
      const matchIdx = prev.findIndex(o => o.orderRef === deposit.bookingRef);
      let updated: AdminOrderExcelRecord[];
      if (matchIdx >= 0) {
        updated = prev.map((item, idx) => {
          if (idx === matchIdx) {
            return {
              ...item,
              depositPaid: (item.depositPaid || 0) + deposit.amount,
              paymentStatus: 'Deposit Paid',
              orderStatus: item.orderStatus === 'New' ? 'Deposit Received' : item.orderStatus,
              adminNotes: `${item.adminNotes ? item.adminNotes + ' | ' : ''}Deposit of $${deposit.amount.toLocaleString()} JMD received via ${deposit.paymentMethod} on ${now.toLocaleDateString()}.`,
              lastUpdated: now.toISOString(),
            };
          }
          return item;
        });
      } else {
        const newRecord: AdminOrderExcelRecord = {
          id: `order-dep-${Date.now()}`,
          orderRef: deposit.bookingRef,
          receivedAt: now.toISOString(),
          orderType: 'Deposit Record',
          customerName: currentUser?.name || 'Verified Traveler',
          email: currentUser?.email || userEmail || '',
          phone: currentUser?.phone || '',
          parishOrCountry: currentUser?.homeParishOrCountry || 'Jamaica',
          tripOrDestination: deposit.tripName,
          travelDates: 'Upcoming 2026/2027',
          adultsCount: 1,
          childrenCount: 0,
          totalPrice: deposit.amount,
          depositPaid: deposit.amount,
          currency: 'JMD',
          paymentStatus: 'Deposit Paid',
          orderStatus: 'Deposit Received',
          preferredContact: 'WhatsApp',
          assignedAdmin: 'Zachary Buchanan',
          specialRequests: `Deposit confirmation receipt #${deposit.id}`,
          adminNotes: `Direct deposit logged: $${deposit.amount.toLocaleString()} JMD via ${deposit.paymentMethod}.`,
          lastUpdated: now.toISOString(),
        };
        updated = [newRecord, ...prev];
      }
      syncToLiveServer({ adminOrdersExcel: updated });
      return updated;
    });
  };

  const deleteBooking = async (id: string) => {
    const targetBooking = bookings.find(b => b.id === id);
    const ref = targetBooking?.referenceNumber;

    // Optimistically purge matching booking and reference across all 3 state arrays
    setBookings(prev => prev.filter(b => b.id !== id && (!ref || b.referenceNumber !== ref)));
    if (ref) {
      setAdminInbox(prev => prev.filter(i => i.referenceNumber !== ref && i.id !== id));
      setAdminOrdersExcel(prev => prev.filter(o => o.orderRef !== ref && o.id !== id));
    }

    try {
      const headers: Record<string, string> = {};
      if (adminSessionToken) {
        headers['Authorization'] = `Bearer ${adminSessionToken}`;
      }
      const purgeKey = ref || id;
      await safeFetchJson(`/api/admin/inquiry/${encodeURIComponent(purgeKey)}`, {
        method: 'DELETE',
        headers,
      });
      await safeFetchJson(`/api/bookings/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers,
      }).catch(() => {});
    } catch (e) {
      console.warn('[deleteBooking purge warning]:', e);
    }

    showNotification('Booking Inquiries Purged', 'Booking inquiry deleted across all database tables.', 'info');
  };

  const saveTrip = (trip: TripPackage) => {
    setTrips(prev => {
      const idx = prev.findIndex(t => t.id === trip.id);
      let updated: TripPackage[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = trip;
      } else {
        updated = [trip, ...prev];
      }
      setStoredItem('trips', updated);
      syncToLiveServer({ trips: updated, packages: updated });
      return updated;
    });
  };

  const saveDestination = (dest: Destination) => {
    setDestinations(prev => {
      const idx = prev.findIndex(d => d.id === dest.id);
      let updated: Destination[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = dest;
      } else {
        updated = [dest, ...prev];
      }
      syncToLiveServer({ destinations: updated });
      return updated;
    });
  };

  const saveBlogPost = (post: BlogPost) => {
    setBlogPosts(prev => {
      const idx = prev.findIndex(p => p.id === post.id);
      let updated: BlogPost[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = post;
      } else {
        updated = [post, ...prev];
      }
      syncToLiveServer({ blog: updated });
      return updated;
    });
  };

  const saveFaq = (faq: FAQItem) => {
    setFaqs(prev => {
      const idx = prev.findIndex(f => f.id === faq.id);
      let updated: FAQItem[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = faq;
      } else {
        updated = [...prev, faq];
      }
      syncToLiveServer({ faqs: updated });
      return updated;
    });
  };

  const saveOffer = (offer: OfferItem) => {
    setOffers(prev => {
      const idx = prev.findIndex(o => o.id === offer.id);
      let updated: OfferItem[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = offer;
      } else {
        updated = [...prev, offer];
      }
      syncToLiveServer({ offers: updated });
      return updated;
    });
  };

  const saveTestimonial = (test: TestimonialItem) => {
    setTestimonials(prev => {
      const idx = prev.findIndex(t => t.id === test.id);
      let updated: TestimonialItem[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = test;
      } else {
        updated = [test, ...prev];
      }
      syncToLiveServer({ testimonials: updated });
      return updated;
    });
  };

  // Departure Airports CRUD
  const addDepartureAirport = (airport: Omit<AirportRecord, 'id'>) => {
    const newAirport: AirportRecord = { ...airport, id: `air-${Date.now()}` };
    setDepartureAirports(prev => {
      const updated = [...prev, newAirport];
      setStoredItem('departure_airports', updated);
      syncToLiveServer({ departureAirports: updated });
      return updated;
    });
    showNotification('Airport Added', `${newAirport.city} (${newAirport.code}) added to departure hubs.`, 'success');
  };

  const updateDepartureAirport = (id: string, updates: Partial<AirportRecord>) => {
    setDepartureAirports(prev => {
      const updated = prev.map(a => a.id === id ? { ...a, ...updates } : a);
      setStoredItem('departure_airports', updated);
      syncToLiveServer({ departureAirports: updated });
      return updated;
    });
    showNotification('Airport Updated', 'Departure location updated.', 'info');
  };

  const deleteDepartureAirport = (id: string) => {
    setDepartureAirports(prev => {
      const updated = prev.filter(a => a.id !== id);
      setStoredItem('departure_airports', updated);
      syncToLiveServer({ departureAirports: updated });
      return updated;
    });
    showNotification('Airport Removed', 'Departure location removed.', 'warning');
  };

  // Origin Pricing Routes CRUD
  const addOriginPricingRoute = (route: Omit<OriginPricingRoute, 'id'>) => {
    const newRoute: OriginPricingRoute = { ...route, id: `route-${Date.now()}` };
    setOriginPricingRoutes(prev => {
      const updated = [newRoute, ...prev];
      setStoredItem('origin_pricing_routes', updated);
      syncToLiveServer({ originPricingRoutes: updated });
      return updated;
    });
    showNotification('Route Configured', `Flight pricing set for ${newRoute.originAirportCode} → ${newRoute.destinationCountry}.`, 'success');
  };

  const updateOriginPricingRoute = (id: string, updates: Partial<OriginPricingRoute>) => {
    setOriginPricingRoutes(prev => {
      const updated = prev.map(r => r.id === id ? { ...r, ...updates } : r);
      setStoredItem('origin_pricing_routes', updated);
      syncToLiveServer({ originPricingRoutes: updated });
      return updated;
    });
    showNotification('Route Updated', 'Route flight pricing updated.', 'info');
  };

  const deleteOriginPricingRoute = (id: string) => {
    setOriginPricingRoutes(prev => {
      const updated = prev.filter(r => r.id !== id);
      setStoredItem('origin_pricing_routes', updated);
      syncToLiveServer({ originPricingRoutes: updated });
      return updated;
    });
    showNotification('Route Deleted', 'Route pricing deleted.', 'warning');
  };

  // Land Service Cost Rules
  const updateServiceCostRules = (rules: Partial<ServiceCostRules>) => {
    setServiceCostRules(prev => {
      const updated: ServiceCostRules = {
        ...prev,
        ...rules,
        accommodationPerNight: { ...prev.accommodationPerNight, ...(rules.accommodationPerNight || {}) },
        mealsPerPersonPerDay: { ...prev.mealsPerPersonPerDay, ...(rules.mealsPerPersonPerDay || {}) },
        excursionsAllowancePerPerson: { ...prev.excursionsAllowancePerPerson, ...(rules.excursionsAllowancePerPerson || {}) },
      };
      setStoredItem('service_cost_rules', updated);
      syncToLiveServer({ serviceCostRules: updated });
      return updated;
    });
    showNotification('Service Rules Updated', 'Accommodation, transfers, and activity pricing rules updated.', 'success');
  };

  const resetServiceCostRules = () => {
    setServiceCostRules(INITIAL_SERVICE_COST_RULES);
    setStoredItem('service_cost_rules', INITIAL_SERVICE_COST_RULES);
    syncToLiveServer({ serviceCostRules: INITIAL_SERVICE_COST_RULES });
    showNotification('Cost Rules Reset', 'Standard service cost baselines restored.', 'info');
  };

  // Supported Currencies CRUD
  const addSupportedCurrency = (curr: CurrencyRecord) => {
    setSupportedCurrencies(prev => {
      const existing = prev.find(c => c.code.toUpperCase() === curr.code.toUpperCase());
      let updated: CurrencyRecord[];
      if (existing) {
        updated = prev.map(c => c.code.toUpperCase() === curr.code.toUpperCase() ? { ...c, ...curr } : c);
      } else {
        updated = [...prev, curr];
      }
      setStoredItem('supported_currencies', updated);
      syncToLiveServer({ supportedCurrencies: updated });
      return updated;
    });
    showNotification('Currency Added', `${curr.code} (${curr.symbol}) currency rate saved.`, 'success');
  };

  const updateSupportedCurrency = (code: string, updates: Partial<CurrencyRecord>) => {
    setSupportedCurrencies(prev => {
      const updated = prev.map(c => c.code.toUpperCase() === code.toUpperCase() ? { ...c, ...updates } : c);
      setStoredItem('supported_currencies', updated);
      syncToLiveServer({ supportedCurrencies: updated });
      return updated;
    });
    showNotification('Exchange Rate Updated', `Updated currency rate for ${code}.`, 'info');
  };

  const deleteSupportedCurrency = (code: string) => {
    if (code === 'USD') {
      showNotification('Protected Currency', 'USD is the base currency and cannot be removed.', 'warning');
      return;
    }
    setSupportedCurrencies(prev => {
      const updated = prev.filter(c => c.code.toUpperCase() !== code.toUpperCase());
      setStoredItem('supported_currencies', updated);
      syncToLiveServer({ supportedCurrencies: updated });
      return updated;
    });
    showNotification('Currency Removed', `${code} removed from supported currencies.`, 'info');
  };

  const resetOriginPricingData = () => {
    setDepartureAirports(INITIAL_DEPARTURE_AIRPORTS);
    setOriginPricingRoutes(INITIAL_ORIGIN_PRICING_ROUTES);
    setServiceCostRules(INITIAL_SERVICE_COST_RULES);
    setSupportedCurrencies(INITIAL_SUPPORTED_CURRENCIES);
    setStoredItem('departure_airports', INITIAL_DEPARTURE_AIRPORTS);
    setStoredItem('origin_pricing_routes', INITIAL_ORIGIN_PRICING_ROUTES);
    setStoredItem('service_cost_rules', INITIAL_SERVICE_COST_RULES);
    setStoredItem('supported_currencies', INITIAL_SUPPORTED_CURRENCIES);
    syncToLiveServer({
      departureAirports: INITIAL_DEPARTURE_AIRPORTS,
      originPricingRoutes: INITIAL_ORIGIN_PRICING_ROUTES,
      serviceCostRules: INITIAL_SERVICE_COST_RULES,
      supportedCurrencies: INITIAL_SUPPORTED_CURRENCIES,
    });
    showNotification('Pricing Data Reset', 'Initial departure airports and route pricing tables restored.', 'info');
  };

  const saveAllChangesToLive = async (customPayload?: Record<string, any>): Promise<boolean> => {
    try {
      const activeSettings = customPayload?.settings || settings;
      const fullPayload = {
        settings: activeSettings,
        trips: customPayload?.trips || trips,
        packages: customPayload?.trips || trips,
        destinations: customPayload?.destinations || destinations,
        blog: customPayload?.blog || blogPosts,
        faqs: customPayload?.faqs || faqs,
        offers: customPayload?.offers || offers,
        testimonials: customPayload?.testimonials || testimonials,
        localTrips: customPayload?.localTrips || localTrips,
        localTripsPageSettings: customPayload?.localTripsPageSettings || localTripsPageSettings,
        wingoRoutes: customPayload?.wingoRoutes || wingoRoutes,
        departureAirports: customPayload?.departureAirports || departureAirports,
        originPricingRoutes: customPayload?.originPricingRoutes || originPricingRoutes,
        serviceCostRules: customPayload?.serviceCostRules || serviceCostRules,
        supportedCurrencies: customPayload?.supportedCurrencies || supportedCurrencies,
        adminInbox: customPayload?.adminInbox || adminInbox,
        adminOrdersExcel: customPayload?.adminOrdersExcel || adminOrdersExcel,
        ambassadors: activeSettings?.ambassadors || [],
        customTripDestinations: activeSettings?.customTripDestinations || WORLD_DESTINATIONS,
        ...(customPayload || {}),
        updatedAt: new Date().toISOString(),
      };

      // Store in localStorage for rapid browser reload recovery
      setStoredItem('settings', fullPayload.settings);
      setStoredItem('trips', fullPayload.trips);
      setStoredItem('local_trips', fullPayload.localTrips);
      setStoredItem('local_trips_settings', fullPayload.localTripsPageSettings);
      setStoredItem('wingo_rates_database', fullPayload.wingoRoutes);
      setStoredItem('departure_airports', fullPayload.departureAirports);
      setStoredItem('origin_pricing_routes', fullPayload.originPricingRoutes);

      // Also persist Wingo rates endpoint
      fetch('/api/wingo/rates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ routes: fullPayload.wingoRoutes }),
      }).catch(() => {});

      // Synchronize across all backends: BroadcastChannel + Realtime DB + Server file store + SSE
      const ok = await syncToLiveServer(fullPayload);
      return ok;
    } catch (e: any) {
      console.error('[saveAllChangesToLive Error]:', e);
      return false;
    }
  };

  const resetToInitialData = () => {
    localStorage.clear();
    setSettings(INITIAL_SETTINGS);
    setTrips(INITIAL_TRIPS);
    setDestinations(INITIAL_DESTINATIONS);
    setBookings(INITIAL_BOOKINGS);
    setBlogPosts(INITIAL_BLOG_POSTS);
    setOffers(INITIAL_OFFERS);
    setTestimonials(INITIAL_TESTIMONIALS);
    setFaqs(INITIAL_FAQS);
    setAdminInbox(INITIAL_ADMIN_INBOX);
    syncToLiveServer({
      settings: INITIAL_SETTINGS,
      trips: INITIAL_TRIPS,
      destinations: INITIAL_DESTINATIONS,
      bookings: INITIAL_BOOKINGS,
      blog: INITIAL_BLOG_POSTS,
      offers: INITIAL_OFFERS,
      testimonials: INITIAL_TESTIMONIALS,
      faqs: INITIAL_FAQS,
      adminInbox: INITIAL_ADMIN_INBOX,
    });
    showNotification('System Reset', 'All demo data has been restored.');
  };

  return (
    <AppContext.Provider
      value={{
        settings,
        updateSettings,
        resetSettings,
        saveAllChangesToLive,
        trips,
        addTrip,
        updateTrip,
        deleteTrip,
        duplicateTrip,
        saveTrip,
        destinations,
        addDestination,
        updateDestination,
        deleteDestination,
        saveDestination,
        bookings,
        createBooking,
        updateBookingStatus,
        updateBookingPayment,
        addBookingNote,
        deleteBooking,
        contactSubmissions,
        submitContactForm,
        customers,
        addCustomerNote,
        blogPosts,
        addBlogPost,
        updateBlogPost,
        deleteBlogPost,
        saveBlogPost,
        offers,
        addOffer,
        updateOffer,
        deleteOffer,
        saveOffer,
        testimonials,
        addTestimonial,
        updateTestimonial,
        deleteTestimonial,
        saveTestimonial,
        faqs,
        addFaq,
        updateFaq,
        deleteFaq,
        saveFaq,
        mediaList,
        addMediaItem,
        deleteMediaItem,
        subscribers,
        subscribeNewsletter,
        unsubscribeNewsletter,
        isAdminLoggedIn,
        adminEmail,
        adminSessionToken,
        currentAdminRole,
        loginAdmin,
        loginAdminWithCredentials,
        logoutAdmin,
        currentUser,
        loginUser,
        signupUser,
        logoutUser,
        recordUserDeposit,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authModalMode,
        setAuthModalMode,
        openAuthModal,
        activeNotification,
        notification: activeNotification,
        showNotification,
        clearNotification,
        isSearchOpen,
        setIsSearchOpen,
        isReviewModalOpen,
        setIsReviewModalOpen,
        openReviewModal,
        // WiPay Jamaica Live Gateway Integration
        isWiPayCheckoutOpen,
        wiPayCheckoutPayload,
        confirmedBookingDetails,
        openWiPayCheckout,
        closeWiPayCheckout,
        completeWiPayBooking,
        closeConfirmationModal,
        selectedTripForBooking,
        setSelectedTripForBooking,
        selectedTripForInquiry,
        setSelectedTripForInquiry,
        selectedTripDetail,
        setSelectedTripDetail,
        isInquiryTrackerOpen,
        setIsInquiryTrackerOpen,
        openInquiryTracker,
        closeInquiryTracker,
        inquiryTrackerInitialQuery,
        updateUserInquiry,
        submitInquiryDeposit,
        activePage,
        navigateTo,
        pageParam,
        resetToInitialData,
        applyFirestoreContent,
        adminInbox,
        addInboxItem,
        markInboxItemAsRead,
        markAllInboxAsRead,
        deleteInboxItem,
        unreadInboxCount,
        adminOrdersExcel,
        addAdminOrderExcel,
        updateAdminOrderExcel,
        updateBookingPaymentSchedule,
        deleteAdminOrderExcel,
        batchUpdateAdminOrdersExcel,
        sendInboxItemToExcel,
        sendBookingToExcel,
        isOrderInExcel,
        syncAllInboxOrdersToExcel,
        savedTripIds,
        savedTrips,
        toggleSaveTrip,
        clearAllSavedTrips,
        isTripSaved,
        isSavedTripsDrawerOpen,
        setIsSavedTripsDrawerOpen,
        openSavedTripsDrawer,
        closeSavedTripsDrawer,
        isCustomTripModalOpen,
        setIsCustomTripModalOpen,
        selectedDestinationForCustomTrip,
        openCustomTripModal,
        closeCustomTripModal,
        submitCustomTripRequest,
        secureSpotForTrip,
        pendingTripForBooking,
        setPendingTripForBooking,
        authNotice,
        setAuthNotice,
        verifyAmbassadorCode,
        refreshSiteData,
        departureAirports,
        addDepartureAirport,
        updateDepartureAirport,
        deleteDepartureAirport,
        originPricingRoutes,
        addOriginPricingRoute,
        updateOriginPricingRoute,
        deleteOriginPricingRoute,
        serviceCostRules,
        updateServiceCostRules,
        resetServiceCostRules,
        supportedCurrencies,
        addSupportedCurrency,
        updateSupportedCurrency,
        deleteSupportedCurrency,
        resetOriginPricingData,
        localTrips,
        localTripsPageSettings,
        addLocalTrip,
        updateLocalTrip,
        deleteLocalTrip,
        reorderLocalTrips,
        updateLocalTripsPageSettings,
        saveLocalTripsToLive,
        selectedLocalTripDetail,
        setSelectedLocalTripDetail,
        openLocalTripDetail,
        closeLocalTripDetail,
        selectedLocalTripForInquiry,
        setSelectedLocalTripForInquiry,
        openLocalTripInquiry,
        closeLocalTripInquiry,
        wingoRoutes,
        addWingoRoute,
        updateWingoRoute,
        deleteWingoRoute,
        batchUpdateWingoRoutes,
        saveWingoRoutesToLive,
        resetWingoRoutesToDefault,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

// Formatting helpers
export const formatPriceJMD = (amount: number): string => {
  return `$${amount.toLocaleString()} JMD`;
};
