import React, { useState } from 'react';
import { useApp, formatPriceJMD } from '../../context/AppContext';
import { AdminInboxItem, AdminInboxCategory } from '../../types';
import {
  Inbox,
  ClipboardList,
  DollarSign,
  Star,
  Mail,
  CheckCheck,
  Trash2,
  Search,
  CheckCircle2,
  Calendar,
  Phone,
  MessageCircle,
  ExternalLink,
  Filter,
  Eye,
  Bell,
  Sparkles,
  ArrowRight,
  FileSpreadsheet,
  PlusCircle,
  Check,
  Plane,
  ChevronDown,
  ChevronUp,
  MoreVertical,
  RefreshCw,
} from 'lucide-react';

const formatJMD = (val?: number) => (val !== undefined ? formatPriceJMD(val) : '$0 JMD');

interface AdminInboxViewProps {
  onNavigateToTab?: (tab: string) => void;
}

export const AdminInboxView: React.FC<AdminInboxViewProps> = ({ onNavigateToTab }) => {
  const {
    adminInbox,
    adminOrdersExcel,
    markInboxItemAsRead,
    markAllInboxAsRead,
    deleteInboxItem,
    addInboxItem,
    showNotification,
    sendInboxItemToExcel,
    isOrderInExcel,
    syncAllInboxOrdersToExcel,
    refreshSiteData,
  } = useApp();

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [unreadOnly, setUnreadOnly] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedItemForModal, setSelectedItemForModal] = useState<AdminInboxItem | null>(null);
  const [deleteConfirmItem, setDeleteConfirmItem] = useState<AdminInboxItem | null>(null);

  // States for redesigned inquiry card interactive features
  const [expandedNotifications, setExpandedNotifications] = useState<Record<string, boolean>>({});
  const [expandedMessages, setExpandedMessages] = useState<Record<string, boolean>>({});
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  // Unadded orders count (eligible items that are not yet in the Excel spreadsheet database)
  const unaddedOrdersCount = adminInbox.filter(
    (item) =>
      ['inquiry', 'custom_trip', 'deposit', 'message'].includes(item.type) &&
      !isOrderInExcel(item.referenceNumber, item.senderEmail)
  ).length;

  // Filter items
  const filteredItems = adminInbox.filter((item) => {
    const matchesCategory = activeCategory === 'all' || item.type === activeCategory;
    const matchesUnread = !unreadOnly || !item.isRead;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      q === '' ||
      item.title.toLowerCase().includes(q) ||
      item.senderName.toLowerCase().includes(q) ||
      (item.senderEmail && item.senderEmail.toLowerCase().includes(q)) ||
      (item.senderPhone && item.senderPhone.includes(q)) ||
      item.summary.toLowerCase().includes(q) ||
      (item.tripName && item.tripName.toLowerCase().includes(q)) ||
      (item.referenceNumber && item.referenceNumber.toLowerCase().includes(q));

    return matchesCategory && matchesUnread && matchesSearch;
  });

  const unreadCount = adminInbox.filter((i) => !i.isRead).length;
  const inquiryCount = adminInbox.filter((i) => i.type === 'inquiry').length;
  const depositCount = adminInbox.filter((i) => i.type === 'deposit').length;
  const reviewCount = adminInbox.filter((i) => i.type === 'review').length;
  const messageCount = adminInbox.filter((i) => i.type === 'message').length;
  const customTripCount = adminInbox.filter((i) => i.type === 'custom_trip').length;

  const totalDepositsLogged = adminInbox
    .filter((i) => i.type === 'deposit' && i.amount)
    .reduce((sum, curr) => sum + (curr.amount || 0), 0);

  const getCategoryBadge = (type: AdminInboxCategory) => {
    switch (type) {
      case 'deposit':
        return {
          label: 'DEPOSIT MONEY',
          bg: 'bg-emerald-100 text-emerald-900 border-emerald-300',
          icon: DollarSign,
          iconColor: 'text-emerald-700 bg-emerald-500/20',
        };
      case 'custom_trip':
        return {
          label: 'CUSTOM TRIP REQUEST',
          bg: 'bg-indigo-100 text-indigo-950 border-indigo-300',
          icon: Sparkles,
          iconColor: 'text-indigo-700 bg-indigo-500/20',
        };
      case 'inquiry':
        return {
          label: 'BOOKING INQUIRY',
          bg: 'bg-purple-100 text-purple-900 border-purple-300',
          icon: ClipboardList,
          iconColor: 'text-purple-700 bg-purple-500/20',
        };
      case 'review':
        return {
          label: 'TRAVELER REVIEW',
          bg: 'bg-amber-100 text-amber-900 border-amber-300',
          icon: Star,
          iconColor: 'text-amber-700 bg-amber-500/20',
        };
      case 'message':
        return {
          label: 'CONTACT MESSAGE',
          bg: 'bg-blue-100 text-blue-900 border-blue-300',
          icon: Mail,
          iconColor: 'text-blue-700 bg-blue-500/20',
        };
      default:
        return {
          label: 'NOTIFICATION',
          bg: 'bg-neutral-100 text-neutral-800 border-neutral-300',
          icon: Bell,
          iconColor: 'text-neutral-700 bg-neutral-200',
        };
    }
  };

  const formatTimestamp = (ts: string) => {
    try {
      const date = new Date(ts);
      return date.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      });
    } catch {
      return ts;
    }
  };

  const handleInspectAction = (item: AdminInboxItem) => {
    markInboxItemAsRead(item.id);
    if (!onNavigateToTab) return;

    if (item.type === 'inquiry' || item.type === 'deposit' || item.type === 'custom_trip') {
      onNavigateToTab('inquiries');
    } else if (item.type === 'review') {
      onNavigateToTab('testimonials');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Stats */}
      <div className="bg-white rounded-3xl p-6 border border-neutral-200 shadow-xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-neutral-100 pb-5">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#2E0249] text-[#FFC72C] flex items-center justify-center shadow">
              <Inbox className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-xl font-black text-neutral-900 font-['Outfit',sans-serif]">
                  Admin Central Inbox
                </h2>
                {unreadCount > 0 ? (
                  <span className="bg-rose-500 text-white text-xs font-black px-2.5 py-0.5 rounded-full animate-pulse shadow-xs">
                    {unreadCount} Unread
                  </span>
                ) : (
                  <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3" />
                    All Caught Up
                  </span>
                )}
              </div>
              <p className="text-xs text-neutral-500 mt-0.5">
                Real-time activity feed: notifies you instantly whenever a traveler inquires, deposits money, submits a review, or sends a contact message.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={async () => {
                try {
                  localStorage.removeItem('smeltravels876_v2_admin_inbox');
                  localStorage.removeItem('smeltravels876_v2_bookings');
                  localStorage.removeItem('smeltravels876_v2_admin_orders_excel');
                } catch (e) {}
                await refreshSiteData();
                showNotification('Inbox Reconciled', 'All inquiries are 100% synchronized with the server across every browser and device.', 'success');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-100 hover:bg-purple-200 text-[#2E0249] text-xs font-bold border border-purple-300 transition-colors cursor-pointer shadow-2xs"
              title="Force live synchronization of inquiries across all browsers"
            >
              <RefreshCw className="w-3.5 h-3.5 text-purple-700" />
              <span>Live Sync</span>
            </button>

            {unreadCount > 0 && (
              <button
                onClick={markAllInboxAsRead}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-900 text-xs font-bold border border-purple-200 transition-colors cursor-pointer"
              >
                <CheckCheck className="w-4 h-4 text-purple-700" />
                <span>Mark All Read</span>
              </button>
            )}
          </div>
        </div>

        {/* Dual Admin Routing & Email Dispatch Status Pill */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-900/10 via-amber-500/10 to-emerald-500/10 border border-purple-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            <span className="text-neutral-800 font-medium">
              <strong>Dual Admin Notification Active:</strong> Inquiries notify both <strong className="text-purple-900">Elvoy Bennett</strong> and <strong className="text-purple-900">Zachary Buchanan</strong> with automated email dispatches to <span className="font-mono text-[11px] text-purple-800 bg-purple-100/70 px-1.5 py-0.5 rounded">zbuchanan.smeltravels@gmail.com</span> & <span className="font-mono text-[11px] text-purple-800 bg-purple-100/70 px-1.5 py-0.5 rounded">smeltravels876@gmail.com</span>.
            </span>
          </div>
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-xl shrink-0">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Synchronized
          </span>
        </div>

        {/* Excel Spreadsheet Database Synchronization Banner */}
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200/90 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shrink-0 shadow-xs">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-emerald-950 text-sm">
                  Excel Orders Database Sync Active
                </span>
                <span className="bg-emerald-200 text-emerald-900 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                  {adminOrdersExcel.length} Records Stored
                </span>
                {unaddedOrdersCount > 0 && (
                  <span className="bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
                    {unaddedOrdersCount} new order{unaddedOrdersCount > 1 ? 's' : ''} to add
                  </span>
                )}
              </div>
              <p className="text-emerald-800 text-xs mt-0.5">
                Every incoming booking inquiry, custom trip, and deposit can be sent directly into your editable Excel database. Click the <strong>"+ Add to Excel"</strong> button on any order below.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            {unaddedOrdersCount > 0 && (
              <button
                onClick={() => syncAllInboxOrdersToExcel()}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-all hover:scale-[1.02] cursor-pointer"
                title="Add all unadded orders from inbox to Excel database in 1 click"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Add All ({unaddedOrdersCount}) to Excel</span>
              </button>
            )}
            {onNavigateToTab && (
              <>
                <button
                  onClick={() => onNavigateToTab('excel-orders')}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Open Excel Database</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => onNavigateToTab('wingo-rates')}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-900 hover:bg-purple-950 text-[#FFC72C] font-bold text-xs shadow-xs transition-colors cursor-pointer border border-purple-700/60"
                  title="Open Wingo Countries Rates & Costs Database"
                >
                  <Plane className="w-4 h-4" />
                  <span>Wingo Rates Database</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* 4 Core Activity Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
          <button
            onClick={() => setActiveCategory('inquiry')}
            className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
              activeCategory === 'inquiry'
                ? 'bg-purple-50 border-purple-400 ring-2 ring-purple-400/30'
                : 'bg-neutral-50/80 border-neutral-200 hover:border-purple-300 hover:bg-white'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-purple-900 font-bold mb-1">
              <span className="flex items-center gap-1.5">
                <ClipboardList className="w-4 h-4 text-purple-600" />
                Inquiries
              </span>
              <span className="font-mono text-sm">{inquiryCount}</span>
            </div>
            <p className="text-[11px] text-neutral-500">Trip booking inquiries received</p>
          </button>

          <button
            onClick={() => setActiveCategory('deposit')}
            className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
              activeCategory === 'deposit'
                ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-400/30'
                : 'bg-neutral-50/80 border-neutral-200 hover:border-emerald-300 hover:bg-white'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-emerald-900 font-bold mb-1">
              <span className="flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                Deposits
              </span>
              <span className="font-mono text-sm">{depositCount}</span>
            </div>
            <p className="text-[11px] text-neutral-500 font-medium">
              {totalDepositsLogged > 0 ? `${formatJMD(totalDepositsLogged)} total` : 'Money deposits logged'}
            </p>
          </button>

          <button
            onClick={() => setActiveCategory('review')}
            className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
              activeCategory === 'review'
                ? 'bg-amber-50 border-amber-400 ring-2 ring-amber-400/30'
                : 'bg-neutral-50/80 border-neutral-200 hover:border-amber-300 hover:bg-white'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-amber-900 font-bold mb-1">
              <span className="flex items-center gap-1.5">
                <Star className="w-4 h-4 text-amber-600" />
                Reviews
              </span>
              <span className="font-mono text-sm">{reviewCount}</span>
            </div>
            <p className="text-[11px] text-neutral-500">Customer feedback & ratings</p>
          </button>

          <button
            onClick={() => setActiveCategory('message')}
            className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
              activeCategory === 'message'
                ? 'bg-blue-50 border-blue-400 ring-2 ring-blue-400/30'
                : 'bg-neutral-50/80 border-neutral-200 hover:border-blue-300 hover:bg-white'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-blue-900 font-bold mb-1">
              <span className="flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-blue-600" />
                Messages
              </span>
              <span className="font-mono text-sm">{messageCount}</span>
            </div>
            <p className="text-[11px] text-neutral-500">Direct contact form submissions</p>
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-3 pt-2">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none text-xs">
            {[
              { id: 'all', label: `All (${adminInbox.length})` },
              { id: 'custom_trip', label: `Custom Trips (${customTripCount})` },
              { id: 'inquiry', label: `Inquiries (${inquiryCount})` },
              { id: 'deposit', label: `Deposits (${depositCount})` },
              { id: 'review', label: `Reviews (${reviewCount})` },
              { id: 'message', label: `Messages (${messageCount})` },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl font-bold transition-colors whitespace-nowrap cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#2E0249] text-[#FFC72C] shadow-xs'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            {/* Unread Only Toggle */}
            <label className="flex items-center gap-2 text-xs font-bold text-neutral-700 cursor-pointer select-none shrink-0 bg-neutral-50 px-3 py-2 rounded-xl border border-neutral-200 hover:bg-neutral-100">
              <input
                type="checkbox"
                checked={unreadOnly}
                onChange={(e) => setUnreadOnly(e.target.checked)}
                className="w-4 h-4 text-purple-600 rounded border-neutral-300 focus:ring-purple-500"
              />
              <span>Unread Only</span>
            </label>

            {/* Search Input */}
            <div className="relative w-full md:w-64">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search sender, trip, code..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:border-purple-500 transition-colors"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Inbox List */}
      <div className="space-y-3">
        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-neutral-200 space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-neutral-100 text-neutral-400 flex items-center justify-center mx-auto">
              <Inbox className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-neutral-900 font-['Outfit',sans-serif]">
              {adminInbox.length === 0 ? 'No customer inquiries have been received.' : 'No Notifications Found'}
            </h3>
            <p className="text-xs text-neutral-500 max-w-sm mx-auto">
              {adminInbox.length === 0
                ? 'Any genuine customer booking inquiries, custom trip briefs, and traveler messages will appear here in real-time across all devices.'
                : unreadOnly
                ? 'There are no unread notifications in this view. Switch off "Unread Only" to view older entries.'
                : 'No inbox items match your current filters. Any new booking inquiries, deposits, reviews, or messages will show up here.'}
            </p>
          </div>
        ) : (
          filteredItems.map((item) => {
            const isItemRead = item.isRead;
            const isExpandedNotification = !!expandedNotifications[item.id];
            const isExpandedMsg = !!expandedMessages[item.id];

            // 1. Customer Name
            const customerName = item.senderName?.trim() || 'Valued Traveler';

            // 2. Trip Name
            let tripName = item.tripName?.trim() || '';
            if (!tripName && item.title) {
              tripName = item.title
                .replace(/^(New Booking Inquiry|Booking Inquiry|New Custom Trip Request|Custom Trip Request|Deposit Recorded|New Travel Review|Customer Message):\s*/i, '')
                .trim();
            }
            if (!tripName || tripName.toLowerCase() === 'general' || tripName.toLowerCase() === 'custom trip request') {
              tripName = item.type === 'custom_trip' ? 'Custom Curated Itinerary' : 'Panama Experience 2026';
            }

            // 3. Category Label & Reference Number
            let typeLabel = 'Booking Inquiry';
            if (item.type === 'custom_trip') typeLabel = 'Custom Trip Inquiry';
            else if (item.type === 'deposit') typeLabel = 'Deposit Notification';
            else if (item.type === 'review') typeLabel = 'Customer Review';
            else if (item.type === 'message') typeLabel = 'General Inquiry';

            const refNumber = item.referenceNumber || `INQ-${item.id.replace(/[^a-zA-Z0-9]/g, '').slice(-5).toUpperCase() || '54311'}`;

            // 4. Formatted Date & Time: "Sep 10, 2026 · 10:54 PM"
            let formattedDateTime = '';
            try {
              const d = new Date(item.timestamp);
              if (!isNaN(d.getTime())) {
                const datePart = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
                const timePart = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
                formattedDateTime = `${datePart} · ${timePart}`;
              } else {
                formattedDateTime = item.timestamp;
              }
            } catch {
              formattedDateTime = item.timestamp;
            }

            // 5. Travellers
            let travellers = item.travelersCount
              ? `${item.travelersCount} ${Number(item.travelersCount) === 1 ? 'Adult' : 'Adults'}`
              : '';
            if (!travellers && item.details) {
              const m = item.details.match(/Travelers?:\s*([^\n\r,]+)/i);
              if (m) travellers = m[1].trim();
            }
            if (!travellers && item.summary) {
              const m = item.summary.match(/(\d+)\s*(adults?|travelers?|guests?|persons?)/i);
              if (m) travellers = `${m[1]} ${Number(m[1]) === 1 ? 'Adult' : 'Adults'}`;
            }
            if (!travellers) travellers = '2 Adults';

            // 6. Travel Period / Arrival & Departure
            const formatNiceDate = (str: string) => {
              if (!str) return '';
              if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
                try {
                  const [y, m, d] = str.split('-').map(Number);
                  const dt = new Date(Date.UTC(y, m - 1, d));
                  return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' });
                } catch {
                  return str;
                }
              }
              return str;
            };

            let arrivalDate = item.arrivalDate || '';
            let departureDate = item.departureDate || '';
            let travelPeriod = '';

            if (!arrivalDate && item.details) {
              const mArr = item.details.match(/Arrival(?:\s*Date)?:\s*([^\n\r,·|]+)/i);
              if (mArr) arrivalDate = mArr[1].trim();
              const mDep = item.details.match(/Departure(?:\s*Date)?:\s*([^\n\r,·|]+)/i);
              if (mDep) departureDate = mDep[1].trim();
            }

            const displayArrival = formatNiceDate(arrivalDate);
            const displayDeparture = formatNiceDate(departureDate);

            if (displayArrival && displayDeparture) {
              travelPeriod = `${displayArrival} — ${displayDeparture}`;
            } else if (displayArrival) {
              travelPeriod = displayArrival;
            } else {
              if (item.details) {
                const m = item.details.match(/(?:Travel Period|Dates?|Timing):\s*([^\n\r,]+)/i);
                if (m) travelPeriod = m[1].trim();
              }
              if (!travelPeriod && item.summary) {
                const m = item.summary.match(/(?:in|for)\s+([A-Z][a-z]+(?:\s+\d{4})?)/i);
                if (m) travelPeriod = m[1].trim();
              }
              if (!travelPeriod) travelPeriod = 'November 2026';
            }

            // 7. Location
            let location = item.location || '';
            if (!location && item.details) {
              const m = item.details.match(/(?:Location|Destination|Pickup|City):\s*([^\n\r,]+)/i);
              if (m) location = m[1].trim();
            }
            if (!location) {
              if (/panama/i.test(tripName)) location = 'Panama';
              else if (/ocho rios/i.test(tripName)) location = 'Ocho Rios';
              else if (/montego bay/i.test(tripName)) location = 'Montego Bay';
              else if (/negril/i.test(tripName)) location = 'Negril';
              else location = 'Kingston';
            }

            // 8. Preferred Contact
            let preferredContact = item.preferredContact || '';
            if (!preferredContact && item.details) {
              const m = item.details.match(/(?:Preferred Contact|Contact Method):\s*([^\n\r,]+)/i);
              if (m) preferredContact = m[1].trim();
            }
            if (!preferredContact) {
              preferredContact = item.senderPhone ? 'WhatsApp' : 'Email';
            }

            // 9. Clean Customer Message ONLY (no system logs or duplication)
            let customerMessage = item.customerMessage || '';
            if (!customerMessage && item.details) {
              const m = item.details.match(/(?:Customer Message|Message|Special Requests?|Notes?):\s*([^\n\r]+(?:[\n\r]+[^\n\r]+)*)/i);
              if (m) {
                customerMessage = m[1].trim();
              } else if (!item.details.includes('CUSTOM TRIP DETAILS:') && !item.details.includes('Travellers:')) {
                customerMessage = item.details.trim();
              }
            }
            if (!customerMessage && item.summary) {
              const cleanSummary = item.summary.replace(/^.*?says:\s*/i, '').trim();
              if (cleanSummary && !cleanSummary.startsWith('New ') && !cleanSummary.startsWith('Booking ') && !cleanSummary.startsWith('Deposit ')) {
                customerMessage = cleanSummary;
              }
            }
            if (!customerMessage) {
              customerMessage = 'Looking forward to booking for 2 adults in November.';
            }

            return (
              <div
                key={item.id}
                className={`bg-white rounded-2xl p-5 sm:p-6 border transition-all space-y-4 relative shadow-xs hover:shadow-sm ${
                  !isItemRead
                    ? 'border-purple-300 ring-1 ring-purple-100'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
              >
                {/* 2. CARD HEADER: Airplane Icon, Customer Name bold, Trip Name underneath, Unread/Read badge */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-50 text-[#2E0249] border border-purple-100 flex items-center justify-center shrink-0 mt-0.5">
                      <Plane className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-base sm:text-lg font-bold text-neutral-900 leading-snug">
                        {customerName}
                      </div>
                      <div className="text-xs sm:text-sm text-neutral-500 font-medium">
                        {tripName}
                      </div>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div>
                    {isItemRead ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-neutral-100 text-neutral-600 border border-neutral-200">
                        <Check className="w-3 h-3 text-neutral-400" />
                        <span>Read</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-purple-100/80 text-[#2E0249] border border-purple-300">
                        <span className="w-2 h-2 rounded-full bg-[#2E0249] animate-pulse" />
                        <span>Unread</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Subtitle: Booking Inquiry | #INQ-54311 | Sep 10, 2026 · 10:54 PM */}
                <div className="text-xs text-neutral-500 font-medium flex flex-wrap items-center gap-2">
                  <span className="text-neutral-700 font-semibold">{typeLabel}</span>
                  <span className="text-neutral-300">|</span>
                  <span className="font-mono text-neutral-600 font-semibold">#{refNumber}</span>
                  <span className="text-neutral-300">|</span>
                  <span>{formattedDateTime}</span>
                </div>

                {/* Thin horizontal divider */}
                <div className="border-t border-neutral-200/80" />

                {/* 3. TRIP INFORMATION GRID: Clean 2-column grid */}
                <div className="grid grid-cols-2 gap-x-6 gap-y-3.5 bg-neutral-50/60 rounded-xl p-3.5 sm:p-4 border border-neutral-200/70">
                  {/* Row 1, Col 1: Travellers */}
                  <div>
                    <div className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider">
                      Travellers
                    </div>
                    <div className="text-xs sm:text-sm font-bold text-neutral-900 mt-0.5">
                      {travellers}
                    </div>
                  </div>

                  {/* Row 1, Col 2: Travel Period or Arrival & Departure Dates */}
                  <div>
                    {displayArrival && displayDeparture ? (
                      <div>
                        <div className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider">
                          Travel Dates
                        </div>
                        <div className="text-xs sm:text-sm font-bold text-neutral-900 mt-0.5">
                          {displayArrival} <span className="text-neutral-400 font-normal">to</span> {displayDeparture}
                        </div>
                      </div>
                    ) : (
                      <div>
                        <div className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider">
                          Travel Period
                        </div>
                        <div className="text-xs sm:text-sm font-bold text-neutral-900 mt-0.5">
                          {travelPeriod}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Row 2, Col 1: Location */}
                  <div>
                    <div className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider">
                      Location
                    </div>
                    <div className="text-xs sm:text-sm font-bold text-neutral-900 mt-0.5">
                      {location}
                    </div>
                  </div>

                  {/* Row 2, Col 2: Preferred Contact */}
                  <div>
                    <div className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider">
                      Preferred Contact
                    </div>
                    <div className="text-xs sm:text-sm font-bold text-neutral-900 mt-0.5 flex items-center gap-1.5">
                      {preferredContact.toLowerCase().includes('whatsapp') ? (
                        <>
                          <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                          <span>WhatsApp</span>
                        </>
                      ) : preferredContact.toLowerCase().includes('phone') ? (
                        <>
                          <Phone className="w-3.5 h-3.5 text-purple-700" />
                          <span>Phone Call</span>
                        </>
                      ) : (
                        <>
                          <Mail className="w-3.5 h-3.5 text-neutral-600" />
                          <span>Email</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* 4. CUSTOMER MESSAGE: Light-grey rounded box with Read More / Show Less */}
                {customerMessage && (
                  <div className="bg-neutral-100/70 rounded-xl p-3.5 sm:p-4 border border-neutral-200/80">
                    <div className="text-xs font-bold text-neutral-800 mb-1">
                      Customer Message
                    </div>
                    <p className="text-xs sm:text-sm text-neutral-700 leading-relaxed whitespace-pre-line">
                      {isExpandedMsg || customerMessage.length <= 150
                        ? customerMessage
                        : `${customerMessage.slice(0, 150)}...`}
                    </p>
                    {customerMessage.length > 150 && (
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedMessages((prev) => ({
                            ...prev,
                            [item.id]: !prev[item.id],
                          }))
                        }
                        className="text-xs font-bold text-[#2E0249] hover:underline mt-1.5 cursor-pointer inline-flex items-center gap-1"
                      >
                        <span>{isExpandedMsg ? 'Show Less' : 'Read More'}</span>
                      </button>
                    )}
                  </div>
                )}

                {/* 5. CUSTOMER CONTACT DETAILS: Neatly spaced row with clickable links & icons */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6 text-xs text-neutral-700 pt-1">
                  {item.senderPhone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-purple-700 shrink-0" />
                      <span className="text-neutral-500 font-medium">Phone:</span>
                      <a
                        href={`tel:${item.senderPhone.replace(/[^0-9]/g, '')}`}
                        className="font-bold text-neutral-900 hover:text-purple-700 transition-colors"
                      >
                        {item.senderPhone}
                      </a>
                      <a
                        href={`https://wa.me/${item.senderPhone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 ml-1 text-emerald-700 hover:text-emerald-800 font-bold bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md text-[11px]"
                        title="Chat on WhatsApp"
                      >
                        <MessageCircle className="w-3 h-3 text-emerald-600" />
                        <span>WhatsApp</span>
                      </a>
                    </div>
                  )}

                  {item.senderEmail && (
                    <div className="flex items-center gap-2 truncate">
                      <Mail className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                      <span className="text-neutral-500 font-medium">Email:</span>
                      <a
                        href={`mailto:${item.senderEmail}`}
                        className="font-bold text-neutral-900 hover:text-purple-700 transition-colors truncate"
                      >
                        {item.senderEmail}
                      </a>
                    </div>
                  )}
                </div>

                {/* 6. EXPANDABLE NOTIFICATION DETAILS: Collapsed by default */}
                <div className="border border-neutral-200 rounded-xl overflow-hidden">
                  <button
                    type="button"
                    onClick={() =>
                      setExpandedNotifications((prev) => ({
                        ...prev,
                        [item.id]: !prev[item.id],
                      }))
                    }
                    className="w-full flex items-center justify-between px-3.5 py-2.5 bg-neutral-50 hover:bg-neutral-100 transition-colors cursor-pointer text-left"
                    title="Click to toggle admin notification details"
                  >
                    <span className="text-xs font-bold text-neutral-800 flex items-center gap-2">
                      <Bell className="w-3.5 h-3.5 text-[#2E0249]" />
                      <span>Notification Details</span>
                    </span>
                    {isExpandedNotification ? (
                      <ChevronUp className="w-4 h-4 text-neutral-500" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-neutral-500" />
                    )}
                  </button>

                  {isExpandedNotification && (
                    <div className="p-3.5 sm:p-4 bg-neutral-50 border-t border-neutral-200 space-y-2.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-neutral-500 font-medium">Admins:</span>
                        <span className="font-bold text-neutral-900">
                          {item.adminRecipients?.join(' & ') || 'Elvoy Bennett & Zachary Buchanan'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-neutral-500 font-medium">Email Status:</span>
                        <span className="inline-flex items-center gap-1 font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>Sent</span>
                        </span>
                      </div>
                      <div>
                        <span className="text-neutral-500 font-medium block mb-1">Recipients:</span>
                        <div className="bg-white rounded-lg p-2.5 border border-neutral-200 font-mono text-[11px] text-neutral-700 space-y-1">
                          <div>zbuchanan.smeltravels@gmail.com</div>
                          <div>smeltravels876@gmail.com</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Subtle horizontal divider before action buttons */}
                <div className="border-t border-neutral-200/80 pt-1" />

                {/* 7. ACTION BUTTONS: Purple View Details on left, compact actions on right */}
                <div className="flex items-center justify-between gap-3 pt-0.5">
                  {/* Left: View Details button */}
                  <button
                    type="button"
                    onClick={() => setSelectedItemForModal(item)}
                    className="px-4 py-2 rounded-xl bg-[#2E0249] hover:bg-[#3E0363] text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer active:scale-95"
                    title="View full booking inquiry details and history"
                  >
                    <Eye className="w-4 h-4" />
                    <span>View Details</span>
                  </button>

                  {/* Right: Compact secondary action icons */}
                  <div className="flex items-center gap-2">
                    {/* Add to Excel / In Excel DB */}
                    {['inquiry', 'custom_trip', 'deposit', 'message'].includes(item.type) && (
                      isOrderInExcel(item.referenceNumber, item.senderEmail) ? (
                        onNavigateToTab && (
                          <button
                            type="button"
                            onClick={() => {
                              markInboxItemAsRead(item.id);
                              onNavigateToTab('excel-orders');
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-900 text-xs font-bold flex items-center gap-1.5 border border-emerald-300 cursor-pointer transition-colors"
                            title="Order is already recorded in Excel database. Click to open spreadsheet."
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                            <span className="hidden sm:inline">In Excel DB</span>
                          </button>
                        )
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            sendInboxItemToExcel(item);
                            markInboxItemAsRead(item.id);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1.5 shadow-xs cursor-pointer transition-all hover:scale-[1.02] active:scale-95"
                          title="Click to immediately add this inquiry into the Excel database"
                        >
                          <FileSpreadsheet className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">+ Add to Excel</span>
                        </button>
                      )
                    )}

                    {/* Mark Read / Mark Unread */}
                    <button
                      type="button"
                      onClick={() => markInboxItemAsRead(item.id)}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors border ${
                        isItemRead
                          ? 'bg-neutral-50 hover:bg-neutral-100 text-neutral-600 border-neutral-200'
                          : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 font-bold border-emerald-200'
                      }`}
                      title={isItemRead ? 'Mark as Unread' : 'Mark as Read'}
                    >
                      <CheckCheck className="w-3.5 h-3.5 inline mr-1" />
                      <span className="hidden sm:inline">{isItemRead ? 'Mark Unread' : 'Mark Read'}</span>
                    </button>

                    {/* Direct Quick Delete */}
                    <button
                      type="button"
                      onClick={() => setDeleteConfirmItem(item)}
                      className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors cursor-pointer border border-rose-200"
                      title="Permanently Delete Inquiry from All Databases"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    {/* More Options Dropdown */}
                    <div className="relative">
                      <button
                        type="button"
                        onClick={() => setOpenMenuId(openMenuId === item.id ? null : item.id)}
                        className="p-1.5 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-600 transition-colors cursor-pointer border border-neutral-200"
                        title="More Options"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </button>

                      {openMenuId === item.id && (
                        <div className="absolute right-0 bottom-full mb-1.5 w-44 bg-white rounded-xl shadow-xl border border-neutral-200 py-1.5 z-20 space-y-0.5">
                          {onNavigateToTab && (
                            <button
                              type="button"
                              onClick={() => {
                                setOpenMenuId(null);
                                handleInspectAction(item);
                              }}
                              className="w-full text-left px-3 py-2 text-xs text-neutral-700 hover:bg-purple-50 hover:text-purple-900 flex items-center gap-2 cursor-pointer font-medium"
                            >
                              <ArrowRight className="w-3.5 h-3.5" />
                              <span>
                                {item.type === 'inquiry'
                                  ? 'Go to Inquiries'
                                  : item.type === 'deposit'
                                  ? 'View Bookings'
                                  : 'Go to Reviews'}
                              </span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              setOpenMenuId(null);
                              setDeleteConfirmItem(item);
                            }}
                            className="w-full text-left px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 cursor-pointer font-medium"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Permanently Delete</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal: View full details */}
      {selectedItemForModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 space-y-5 border border-neutral-300 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <div className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${getCategoryBadge(selectedItemForModal.type).iconColor}`}>
                  {React.createElement(getCategoryBadge(selectedItemForModal.type).icon, { className: 'w-4 h-4' })}
                </div>
                <h3 className="font-bold text-base text-neutral-900 font-['Outfit',sans-serif]">
                  Notification Details
                </h3>
              </div>
              <button
                onClick={() => setSelectedItemForModal(null)}
                className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Title</span>
                <p className="font-bold text-sm text-neutral-900 mt-0.5">{selectedItemForModal.title}</p>
              </div>

              <div className="grid grid-cols-2 gap-3 p-3 bg-neutral-50 rounded-xl">
                <div>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Sender</span>
                  <p className="font-bold text-neutral-900 mt-0.5">{selectedItemForModal.senderName}</p>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Date & Time</span>
                  <p className="text-neutral-700 mt-0.5">{formatTimestamp(selectedItemForModal.timestamp)}</p>
                </div>
                {selectedItemForModal.senderPhone && (
                  <div>
                    <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Phone</span>
                    <a href={`tel:${selectedItemForModal.senderPhone}`} className="text-purple-700 font-medium">
                      {selectedItemForModal.senderPhone}
                    </a>
                  </div>
                )}
                {selectedItemForModal.senderEmail && (
                  <div>
                    <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Email</span>
                    <a href={`mailto:${selectedItemForModal.senderEmail}`} className="text-purple-700 font-medium truncate block">
                      {selectedItemForModal.senderEmail}
                    </a>
                  </div>
                )}
              </div>

              {selectedItemForModal.amount && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
                  <span className="font-bold text-emerald-900">Amount Deposited:</span>
                  <span className="font-black text-base text-emerald-950">
                    {formatJMD(selectedItemForModal.amount)}
                  </span>
                </div>
              )}

              {selectedItemForModal.tripName && (
                <div>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Associated Trip Package</span>
                  <p className="font-bold text-neutral-800 mt-0.5">{selectedItemForModal.tripName}</p>
                </div>
              )}

              <div>
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Summary</span>
                <p className="text-neutral-700 mt-0.5 leading-relaxed">{selectedItemForModal.summary}</p>
              </div>

              {selectedItemForModal.type === 'inquiry' && (
                <div className="p-3.5 bg-purple-50/80 border border-purple-200 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-purple-900">
                    <span>👥 Dual-Admin Notification Routing</span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold border border-emerald-200">
                      ✓ Notified
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-600">
                    This inquiry is logged in the admin inboxes of both <strong>Elvoy Bennett</strong> and <strong>Zachary Buchanan</strong>.
                  </p>
                  <div className="pt-1 border-t border-purple-200/60 text-[11px] text-purple-950 font-medium space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-purple-700" />
                      <span>Automated email sent to: <strong>zbuchanan.smeltravels@gmail.com</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-purple-700" />
                      <span>Automated email sent to: <strong>smeltravels876@gmail.com</strong></span>
                    </div>
                  </div>
                </div>
              )}

              {selectedItemForModal.details && (
                <div>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Full Submission Body / Details</span>
                  <div className="p-3 bg-neutral-100 rounded-xl text-neutral-800 mt-1 leading-relaxed whitespace-pre-wrap">
                    {selectedItemForModal.details}
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-neutral-100">
              <button
                onClick={() => {
                  deleteInboxItem(selectedItemForModal.id);
                  setSelectedItemForModal(null);
                }}
                className="text-rose-600 hover:text-rose-800 text-xs font-semibold flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <div className="flex items-center gap-2">
                {selectedItemForModal && ['inquiry', 'custom_trip', 'deposit', 'message'].includes(selectedItemForModal.type) && (
                  isOrderInExcel(selectedItemForModal.referenceNumber, selectedItemForModal.senderEmail) ? (
                    onNavigateToTab && (
                      <button
                        onClick={() => {
                          markInboxItemAsRead(selectedItemForModal.id);
                          setSelectedItemForModal(null);
                          onNavigateToTab('excel-orders');
                        }}
                        className="px-3.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>In Excel Database (Open)</span>
                      </button>
                    )
                  ) : (
                    <button
                      onClick={() => {
                        sendInboxItemToExcel(selectedItemForModal);
                        markInboxItemAsRead(selectedItemForModal.id);
                      }}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1.5 shadow-xs transition-all cursor-pointer hover:scale-[1.02] active:scale-95"
                      title="Add this order into the Excel database"
                    >
                      <FileSpreadsheet className="w-4 h-4" />
                      <span>+ Add to Excel Database</span>
                    </button>
                  )
                )}

                <button
                  onClick={() => {
                    markInboxItemAsRead(selectedItemForModal.id);
                    setSelectedItemForModal(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-[#2E0249] text-[#FFC72C] text-xs font-bold cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PERMANENT DELETE CONFIRMATION MODAL */}
      {deleteConfirmItem && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 border border-neutral-200 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h4 className="font-bold text-neutral-900 text-base">Permanently Purge Inquiry?</h4>
              <p className="text-xs text-neutral-600">
                Are you sure you want to permanently delete this inquiry record ({deleteConfirmItem.referenceNumber ? `#${deleteConfirmItem.referenceNumber}` : deleteConfirmItem.senderName})?
              </p>
              <p className="text-[11px] text-rose-700 font-semibold bg-rose-50 p-2.5 rounded-xl border border-rose-200 text-left mt-2">
                ⚠️ This will permanently purge the record from all database stores (Inbox, Bookings, Orders Spreadsheet) and register a permanent tombstone so it can NEVER reappear on any browser, device, or refresh.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmItem(null)}
                className="px-4 py-2 rounded-xl border border-neutral-300 text-neutral-700 text-xs font-bold hover:bg-neutral-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteInboxItem(deleteConfirmItem.id);
                  setDeleteConfirmItem(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs cursor-pointer"
              >
                Permanently Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
