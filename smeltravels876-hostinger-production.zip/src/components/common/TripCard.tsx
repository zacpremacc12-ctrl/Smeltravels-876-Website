import React from 'react';
import {
  Calendar,
  Hotel,
  Check,
  ArrowRight,
  Sparkles,
  Plane,
  ShieldAlert,
  CreditCard,
  Camera,
  Bookmark,
  Lock,
} from 'lucide-react';
import { TripPackage } from '../../types';
import { formatPriceJMD, useApp } from '../../context/AppContext';
import { getSafeTripImageUrl, handleTripImageError } from '../../lib/imageUtils';

interface TripCardProps {
  trip: TripPackage;
  highlight2026?: boolean;
}

export const TripCard: React.FC<TripCardProps> = ({ trip, highlight2026 }) => {
  const {
    navigateTo,
    setSelectedTripForBooking,
    savedTripIds,
    toggleSaveTrip,
    secureSpotForTrip,
    openWiPayCheckout,
  } = useApp();

  const isSaved = savedTripIds.includes(trip.id);

  const getStatusBadge = (status: TripPackage['status']) => {
    switch (status) {
      case 'Available':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Limited Availability':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Coming Soon':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'Sold Out':
        return 'bg-rose-100 text-rose-800 border-rose-300';
      case 'Closed':
        return 'bg-neutral-200 text-neutral-700 border-neutral-300';
      case 'Past Trip':
        return 'bg-purple-900 text-[#FFC72C] border-purple-800 font-black';
      default:
        return 'bg-neutral-100 text-neutral-800 border-neutral-300';
    }
  };

  return (
    <div
      className={`group relative bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border flex flex-col h-full ${
        highlight2026 || trip.is2026Featured
          ? 'border-purple-300 ring-2 ring-purple-600/20'
          : 'border-neutral-200'
      }`}
      id={`trip-card-${trip.id}`}
    >
      {/* Top Media Banner */}
      <div
        onClick={() => navigateTo('trip-detail', trip.slug)}
        className="relative h-56 w-full overflow-hidden bg-neutral-900 cursor-pointer"
        title={`View full package details for ${trip.name}`}
      >
        <img
          src={getSafeTripImageUrl(trip.featuredImage, `${trip.destination} ${trip.country}`)}
          alt={`${trip.name} - ${trip.destination}`}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={(e) => handleTripImageError(e, `${trip.destination} ${trip.country}`)}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

        {/* Badges on image */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 items-start">
          {trip.countryAcronym && (
            <span className="bg-white/95 backdrop-blur-md text-[#2E0249] text-[11px] font-black uppercase px-2 py-0.5 rounded-md shadow border border-purple-200/80 tracking-wider flex items-center gap-1">
              <span>{trip.countryFlag}</span>
              <span>{trip.countryAcronym}</span>
            </span>
          )}
          {trip.is2026Featured && (
            <span className="bg-[#FFC72C] text-[#2E0249] text-[11px] font-extrabold uppercase px-2.5 py-1 rounded-md shadow">
              2026 Featured Trip
            </span>
          )}
          {trip.is2027Collection && (
            <span className="bg-[#2E0249] text-[#FFC72C] text-[11px] font-extrabold uppercase px-2.5 py-1 rounded-md border border-[#FFC72C]/40 shadow">
              2027 Collection
            </span>
          )}
          <span
            className={`text-[11px] font-bold px-2.5 py-0.5 rounded-md border shadow-sm ${getStatusBadge(
              trip.status
            )}`}
          >
            {trip.status === 'Past Trip' ? '📸 Past Trip' : trip.status}
          </span>
          {(trip.isPastTrip || trip.status === 'Past Trip') && trip.pastTripMedia && trip.pastTripMedia.length > 0 && (
            <span className="bg-black/80 backdrop-blur-md text-[#FFC72C] text-[10px] font-black uppercase px-2 py-0.5 rounded-md shadow border border-[#FFC72C]/40 flex items-center gap-1">
              <Camera className="w-3 h-3" />
              <span>
                {trip.pastTripMedia.filter((m) => m.type === 'image').length} Photos
                {trip.pastTripMedia.some((m) => m.type === 'video')
                  ? ` • ${trip.pastTripMedia.filter((m) => m.type === 'video').length} Videos`
                  : ''}
              </span>
            </span>
          )}
          {trip.availabilityNote && trip.status !== 'Past Trip' && (
            <span className="bg-amber-500 text-neutral-950 text-[10px] font-extrabold px-2 py-0.5 rounded-md shadow">
              {trip.availabilityNote}
            </span>
          )}
          {trip.isAdultsOnly && (
            <span className="bg-rose-600 text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded-md shadow flex items-center gap-1 border border-rose-400">
              <span>🔞</span>
              <span>Adults Only (18+)</span>
            </span>
          )}
        </div>

        {/* Top Right Controls: Dates & Bookmark */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5 z-10">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleSaveTrip(trip.id);
            }}
            className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center transition-all shadow-md backdrop-blur-md cursor-pointer ${
              isSaved
                ? 'bg-[#FFC72C] text-[#2E0249] ring-2 ring-white scale-105'
                : 'bg-black/60 text-white hover:bg-black/80 hover:text-[#FFC72C]'
            }`}
            title={isSaved ? 'Remove from bookmarked trips' : 'Save trip bookmark for later'}
            aria-label="Bookmark trip"
            id={`bookmark-btn-${trip.id}`}
          >
            <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-current' : ''}`} />
          </button>

          {trip.tripLogo && (
            <div className="w-8 h-8 rounded-lg bg-white/95 backdrop-blur-md p-1 border border-white/60 shadow-md flex items-center justify-center overflow-hidden">
              <img
                src={trip.tripLogo}
                alt={`${trip.name} emblem`}
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
          )}
          <div className="bg-black/70 backdrop-blur-sm text-white px-2 py-1 rounded-md text-[11px] font-semibold flex items-center gap-1 border border-white/15">
            <Calendar className="w-3 h-3 text-[#FFC72C]" />
            <span>{trip.dates}</span>
          </div>
        </div>

        {/* Gallery Photos Counter Badge on Bottom Right */}
        {trip.gallery && trip.gallery.length > 0 && (
          <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-sm text-white text-[10px] font-semibold px-2 py-0.5 rounded-md flex items-center gap-1 border border-white/20">
            <Camera className="w-3 h-3 text-[#FFC72C]" />
            <span>+{trip.gallery.length} photos</span>
          </div>
        )}

        {/* Destination & Country at Bottom of Image */}
        <div className="absolute bottom-3 left-4 right-4 text-white">
          <div className="flex items-center gap-2 text-xs font-medium text-neutral-300 flex-wrap">
            <span className="text-base">{trip.countryFlag}</span>
            <span>{trip.country}</span>
            {trip.countryAcronym && (
              <span className="bg-[#FFC72C] text-[#2E0249] font-black text-[10px] px-1.5 py-0.5 rounded uppercase tracking-wider shadow-xs">
                {trip.countryAcronym}
              </span>
            )}
            {trip.requiresSchengenVisa && (
              <span className="bg-purple-900/80 text-[#FFC72C] text-[10px] px-1.5 py-0.5 rounded font-semibold border border-[#FFC72C]/30">
                Schengen Visa Required
              </span>
            )}
          </div>
          <h3 className="text-xl font-bold font-['Outfit',sans-serif] text-white tracking-tight mt-0.5 leading-snug hover:text-[#FFC72C] transition-colors">
            {trip.name}
          </h3>
        </div>
      </div>

      {/* Card Content Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        {/* Hotel / Accommodation */}
        <div className="flex items-start gap-2 text-xs text-neutral-700 bg-neutral-50 p-2.5 rounded-xl border border-neutral-200">
          <Hotel className="w-4 h-4 text-[#2E0249] shrink-0 mt-0.5" />
          <div className="truncate">
            <span className="font-semibold text-neutral-900 block">Hotel Accommodation:</span>
            <span className="text-neutral-600 truncate block">{trip.hotel}</span>
          </div>
        </div>

        {/* Short Description */}
        <p className="text-xs text-neutral-600 line-clamp-2 leading-relaxed">
          {trip.shortDescription}
        </p>

        {/* Included Services Preview */}
        <div className="space-y-1.5 border-t border-neutral-100 pt-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block">
              What is Included ({trip.packageInclusions?.length || 0}):
            </span>
            {trip.packageInclusions && trip.packageInclusions.length > 3 && (
              <span className="text-[10px] text-purple-800 font-bold bg-purple-50 px-1.5 py-0.5 rounded">
                +{trip.packageInclusions.length - 3} more
              </span>
            )}
          </div>
          <div className="grid grid-cols-1 gap-1 text-xs text-neutral-700">
            {(trip.packageInclusions || []).slice(0, 3).map((inc, idx) => (
              <div key={idx} className="flex items-center gap-1.5 truncate">
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 stroke-[2.5]" />
                <span className="truncate">{inc}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Price & Deposit Area */}
        <div className="pt-3 border-t border-neutral-200 flex items-end justify-between">
          <div>
            <span className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wider block">
              Package Rate
            </span>
            <div className="text-2xl font-black text-[#2E0249] font-['Outfit',sans-serif] leading-none">
              {formatPriceJMD(trip.price)}
            </div>
            <div className="flex items-center gap-1 mt-0.5">
              <span className="text-[11px] text-neutral-500 font-medium">per person</span>
              {trip.isAdultsOnly ? (
                <span className="text-[10px] text-rose-700 font-bold bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                  18+ Only
                </span>
              ) : (
                <span className="text-[10px] text-emerald-800 font-semibold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200" title="Child rate for age 2-11">
                  Child: {formatPriceJMD(trip.childPrice ?? Math.round(trip.price * 0.7))}
                </span>
              )}
            </div>
          </div>

          <div className="text-right">
            <span className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wider block">
              Deposit
            </span>
            <span className="text-base font-bold text-amber-700 block leading-none">
              {formatPriceJMD(trip.deposit)}
            </span>
            <span className="text-[10px] text-neutral-500">Locks in your spot</span>
          </div>
        </div>

        {/* Action CTAs */}
        {trip.status === 'Past Trip' || trip.isPastTrip ? (
          <div className="pt-2 grid grid-cols-2 gap-2">
            <button
              onClick={() => navigateTo('trip-detail', trip.slug)}
              className="w-full bg-[#2E0249] hover:bg-[#3B185F] text-white font-bold text-xs py-2.5 px-3 rounded-xl transition-colors flex items-center justify-center gap-1 cursor-pointer"
              id={`view-trip-${trip.id}`}
              title={`View photos, videos & traveler memories for ${trip.name}`}
            >
              <span>View Recap</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => navigateTo('trip-detail', trip.slug)}
              className="w-full font-bold text-xs py-2.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1 shadow-sm bg-gradient-to-r from-amber-400 to-[#FFC72C] hover:brightness-105 text-[#2E0249] cursor-pointer"
              id={`memories-trip-${trip.id}`}
              title="View photos and video highlights"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Photos & Videos</span>
            </button>
          </div>
        ) : trip.status === 'Closed' ? (
          <div className="pt-2 grid grid-cols-2 gap-2">
            <button
              onClick={() => navigateTo('trip-detail', trip.slug)}
              className="w-full bg-[#2E0249] hover:bg-[#3B185F] text-white font-bold text-xs py-2.5 px-3 rounded-xl transition-colors flex items-center justify-center gap-1 cursor-pointer"
              id={`view-trip-${trip.id}`}
              title={`View package details for ${trip.name}`}
            >
              <span>View Package</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              disabled={true}
              className="w-full font-bold text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 bg-neutral-200 text-neutral-500 cursor-not-allowed border border-neutral-300 shadow-none opacity-85 select-none"
              title="Bookings for this tour package are officially closed"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Bookings Closed</span>
            </button>
          </div>
        ) : (
          <div className="pt-2 grid grid-cols-2 gap-2">
            <button
              onClick={() => navigateTo('trip-detail', trip.slug)}
              className="w-full bg-[#2E0249] hover:bg-[#3B185F] text-white font-bold text-xs py-2.5 px-3 rounded-xl transition-colors flex items-center justify-center gap-1 cursor-pointer"
              id={`view-trip-${trip.id}`}
              title={`View full details & package inclusions for ${trip.name}`}
            >
              <span>View Package</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() =>
                openWiPayCheckout({
                  tripId: trip.id,
                  title: trip.name,
                  deposit: trip.deposit,
                  totalPrice: trip.price,
                  dates: trip.dates,
                  location: `${trip.destination}, ${trip.country}`,
                })
              }
              disabled={trip.status === 'Sold Out'}
              className={`w-full font-bold text-xs py-2.5 px-3 rounded-xl transition-colors flex items-center justify-center gap-1 shadow-sm cursor-pointer ${
                trip.status === 'Sold Out'
                  ? 'bg-neutral-200 text-neutral-400 cursor-not-allowed'
                  : 'bg-[#FFC72C] hover:bg-[#FACC15] text-[#2E0249]'
              }`}
              id={`book-trip-${trip.id}`}
              title="Book Now (Pay Deposit) with secure WiPay Jamaica checkout"
            >
              <Sparkles className="w-3.5 h-3.5 fill-current" />
              <span>{trip.status === 'Sold Out' ? 'Sold Out' : 'Book Now (Pay Deposit)'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
